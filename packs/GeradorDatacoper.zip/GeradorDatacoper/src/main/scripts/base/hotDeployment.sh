#!/bin/bash

source generateInclude.sh "$@"
STARTTIME=$(date +%s)

source base.sh
echo '--> '
echo '--> Iniciando Hot Deployment...'
echo '--> '

RESOURCE_CLASSES=$RESOURCE_PROJECT/target/classes
CORE_CLASSES=$CORE_PROJECT/target/classes
CORE_PERSISTENCE=$CORE_PROJECT/src/main/resources/META-INF/persistence.xml
BUSINESS_CLASSES=$BUSINESS_PROJECT/target/classes


if [[ "$syncBackEnd" = true && -d "$SERVER_DEPLOYMENT/WEB-INF/" ]]; then
   rsync -hravW --delete $RESOURCE_CLASSES/* $BUSINESS_CLASSES/* $CORE_CLASSES/* $SERVER_DEPLOYMENT/WEB-INF/classes/
   rsync -havW $CORE_PERSISTENCE $SERVER_DEPLOYMENT/WEB-INF/classes/META-INF/persistence.xml
   rsync -havW $CORE_PERSISTENCE $CORE_CLASSES/META-INF/persistence.xml
   #rsync -hravW --delete $BUSINESS_CLASSES/* $SERVER_DEPLOYMENT/WEB-INF/classes/
   #rsync -hravW --delete $RESOURCE_CLASSES/* $SERVER_DEPLOYMENT/WEB-INF/classes/
fi

ENDTIME=$(date +%s)
echo '--> '
echo "--> Hot Deployment executado em $(($ENDTIME - $STARTTIME)) segundos."
echo '--> '
