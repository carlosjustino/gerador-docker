#!/bin/bash

GEN_VERSION='3.1.5'

# ABORT EXECUTION WITH CTRL + C
trap ctrl_c INT

function ctrl_c() {
   echo '--> '
   echo "--> A Execução do GeradorDatacoper foi abortada pelo usuário."
   echo '--> '
   exit 1
}

if [ $# -eq 1 ] && [ $1 = "--info" ]; then
   echo '------------------------------------------------------------------------------------------'
   echo "-                      GeradorDatacoper v${GEN_VERSION} - DATACOPER SOFTWARE                      -"
   echo '------------------------------------------------------------------------------------------'
   echo 'Informações do sistema: '
   echo 'SISTEMA OPERACIONAL: '$OS '-' `uname`
   echo 'MY_WORKSPACE.......: '$MY_WORKSPACE
   echo 'PROJECT_NAME.......: '$PROJECT_NAME
   echo 'ACTIVATE_BLOCKUI...: '$ACTIVATE_BLOCKUI
   echo 'SAXONEXEC..........: '$SAXONEXEC
   echo 'WORKSPACE..........: '$WORKSPACE
   echo 'WSO2_DEPLOY........: '$WSO2_DEPLOY
   echo 'HOME_FREEMIND_SRC..: '$HOME_FREEMIND_SRC
   echo 'HOME_FREEMIND_ICONS: '$HOME_FREEMIND_ICONS
   echo '*GERADOR DATACOPER* '
   svn info $HOME_GEN | grep 'Last Changed'
   echo '*MAPAS* '
   svn info $HOME_MINDMAPS | grep 'Last Changed'
   #$HOME_DOMAIN $HOME_JNG   
   exit 0
fi

# HELP DOCUMENT
if [ $# -eq 0 ] || [ $1 = "--help" ] || [ $1 = "-h" ]; then
   echo '------------------------------------------------------------------------------------------'
   echo "-                      GeradorDatacoper ${GEN_VERSION} - DATACOPER SOFTWARE              -"
   echo '------------------------------------------------------------------------------------------'
   echo "Uso: $(basename "$0") [parametros]"
   echo ' '
   echo ' Comandos globais:'
   echo '   -A,   --all                        Geração completa (Realiza Clean/Update/Compile/Sync)'
   echo '   -F,   --front-end                  Gerar Front-End (Telas)'
   echo '   -B,   --back-end                   Gerar Back-End (Classes Domain, DS e APIs)'
   echo '   -R,   --reports                    Gerar Relatórios (Telas de Relatórios e RPTDesign)'
   echo '   -T,   --tests                      Gerar Artefatos de Testes (Selenium)'
   echo '   -U,   --unit                       Gerar Artefatos de Testes Unitários (JUnit)'
   echo ' '
   echo ' Comandos de dicionários de dados:'
   echo '   -a,   --class                      Criar dicionário de classes'
   echo '   -i,   --interface [nome]           Gerar dicionário de interfaces'
   echo '   -p,   --report [nome]              Gerar dicionário de relatórios'
   echo '   -ut,  --unit-test                  Criar dicionário de testes unitários (Java)'
   echo '   -va,  --validateClassDictionary    Faz a validação do dicionário de classes'
   echo '         --test                       Gerar dicionário de testes (Selenium)'
   echo ' '
   echo ' Comandos específicos de Back-End:'
   echo '   [Projeto core | business]'
   echo '   -n,   --domain                     Gerar classes do pacote domain'
   echo '   -u,   --utility                    Gerar classes do pacote utility'
   echo '   -sp,  --storedProcedure            Gerar classes refrentes as Procedures BD'
   echo '   -qu,  --queue                      Gerar classes e projeto consumidor de filas'
   echo '   -q,   --query                      Gerar classes do pacote queries'
   echo '   -re,  --referrer                   Gerar classes do pacote referrer'
   echo '   -co,  --container                  Gerar classes do pacote container'
   echo '   -ns,  --constructor                Gerar classes do pacote constructor'
   echo '   -li,  --listener                   Gerar classes do pacote listener'
   echo '   -ci,  --containerIntegration       Gerar classes do pacote integration'
   echo '         --persistenceXml             Gera arquivo persistence.xml'
   echo '   -cw,  --containerDW                Gerar classes do pacote DW'
   echo ' '
   echo '   [Projeto resource]'
   echo '   -t,   --rest                       Gerar classes do pacote data'
   echo '   -tc,  --rest-container             Gerar classes do pacote container'
   echo '         --indentJava                 Indenta o código Java'
   echo ' '
   echo '   [Api Manger]'
   echo '   --restApiManager                   Gerar XML para deploy da API'
   echo ' '
   echo ' Comandos específicos de Front-End:'
   echo ' '
   echo '   [Projeto JNG]'
   echo '   -m,   --menu                       Criar arquivos de menu (Horizontal/Lateral/SQL)'
   echo '   -r,   --routes                     Criar rotas de API JaggeryJS'
   echo '   -f,   --factory                    Gerar JavaScripts do pacote factory'
   echo '   -s,   --states                     Gerar JavaScripts do pacote states (ngRoute)'
   echo '   -l,   --list                       Montar HTML das Interfaces de Lista'
   echo '   -o,   --editor                     Montar HTML das Interfaces de Edição'
   echo '   -v,   --view                       Montar HTML das Interfaces de Vizualização'
   echo '   -c,   --controller                 Gerar JavaScripts do pacote ctrl'
   echo '   -ev,  --events                     Gerar JavaScripts do pacote events'
   echo '   -fn,  --functions                  Gerar JavaScripts do pacote functions'
   echo '   -vr,  --validators                 Gerar JavaScripts do pacote validators'
   echo '         --indent                     Indenta o código HTML e JavaScript'
   echo ' '
   echo ' Comandos específicos de Relatórios:'
   echo '   [Projeto JNG]'
   echo '   -ro,  --report-editor              Gerar HTML das telas de parâmetrização'
   echo '   -rv,  --report-view                Gerar HTML das telas de vizualização'
   echo '   -rc,  --report-controller          Gerar JavaScripts do pacote ctrl'
   echo '   -rn,  --report-events              Criar JavaScripts do pacote events'
   echo '   -rr,  --report-validators          Criar JavaScripts do pacote validators'
   echo '   -rf,  --report-functions           Criar JavaScripts do pacote functions'
   echo '   -rs,  --report-state               Criar JavaScripts do pacote states'
   echo ' '
   echo '   [BIRT]'
   echo '   -rd,  --report-design              Criar RPTDesign dos relatórios'
   echo '   -rj,  --report-javascript          Criar JavaScripts para importação no RPTDesign'
   echo ' '
   echo ' Comandos específicos de Testes:'
   echo '   -uc,   --unit-classes              Criar classes JUnit'
   echo '   -up,   --unit-properties           Criar arquivo .properties dos testes unitários'
   echo '   -eu,   --exec-unit [class]         Executa os testes unitários'
   echo '   -ep,   --exec-properties [url]     Define a URL do arquivos .properties'
   echo '   -th,   --test-host [host]          Configuração de host de teste'
   echo '   -tp,   --test-port [port]          Configuração de porta de teste'
   echo '   -ta,   --test-app [app]            Configuração de app de teste'
   echo '   -tu,   --test-user [user]          Configuração de usuário de teste'
   echo '   -lpo,  --po-list                   Criar PageObjects (Listar)'
   echo '   -mpo,  --po-maintain               Criar PageObjects (Manter)'
   echo '   -vpo,  --po-view                   Criar PageObjects (Visualizar)'
   echo '   -crt,  --runCucumber               Criar classe RunCucumberTest'
   echo ' '
   echo ' Comandos de deployment:'
   echo '   -cp,   --compile                   Compila projeto DS e faz o deployment no SERVER'
   echo '   -cc,   --compile-changes           Compila apenas as alteracoes'
   echo '   -cjms, --compile-jms               Compila projetos consumidores JMS'   
   echo '   -syb,  --sync-back-end             Deploy das alterações no SERVER Back-End'
   echo '   -sy,   --sync [i/r]                Deploy de (i)nterface, (r)elatório, (ambos) *default'
   echo ' '
   echo ' Comandos especiais:'
   echo '   -g,   --graph [true/false]         Criar dicionário com grafo (default true)'
   echo '   -cl   --clean                      Limpa todas as pastas de códigos gerados'
   echo '         --no-clean                   Nao executa o clean'
   echo '   -upd, --update                     Atualiza as pastas do SVN'
   echo '         --no-update                  Nao executa o update'
   echo '         --target [nome]              Gerar somente a classe referenciada'
   echo '   -hd,  --hot-deploy                 Realiza o hot deployment do Back-End'
   echo '         --ddl                        Gera o SQL com o DDL do banco(PostgreSQL)'
   echo '           |   --opcao                  ADD, DROP ou QUERY, obrigatório'
   echo '           |   --attr                   atributos, opcional'
   echo '           |   --consulta               nome da consulta, obrigatório para QUERY'
   echo '         --info                       Apresenta informações sobre as variáveis de ambiente'
   echo '         --templatesMap               Gera mapa com o Template aplicado para Visualização'
   echo '         --usingMap                   Gera mapa com as utilizações'
   echo '         --validateCode               Valida codigo gerado - Consultas'
   echo '         --createIndex                Gera SQL para criação de index'
   echo '         --appRun                     Inicia o Gretty -- NAO USAR POR ENQUANTO'
   echo '         --queriesMap                 Gera mapa chamando todas as consultas do sistema'
   echo '         --snitchMap                  Gera mapa apresentando o que não esta sendo usado'
   echo '         --mapas [nomeArquivos]       Gerar as classes de dentro do mapa'
   echo ' '
   exit 0
fi

# MACRO VARS
export all=false
export frontEnd=false
export backEnd=false
export templatesMap=false

export reports=false
export syncBoth=false
export syncFrontEnd=false
export syncReports=false
export clean=false
export compile=false
export compileConsumer=false
export hotDeploy=false
export tests=false
export unitTests=false

# BACK-END VARS
export classDictionary=false
export utility=false
export queue=false
export referrer=false
export container=false
export query=false
export domainbackend=false
export constructor=false
export restContainer=false
export rest=false
export listener=false
export syncBackEnd=false
export compileChanges=false
export containerIntegration=false
export persistenceXml=false
export containerDW=false
export identJava=false
export validateClassDictionary=false
export storedProcedure=false
export ddl=false
export atributosDDL=ND
export tipoGeracaoDDL=ND
export queryDDL=ND
export restApiManager=false

# FRONT-END VARS
export interface=false
export menu=false
export routes=false
export factory=false
export states=false
export list=false
export editor=false
export view=false
export controller=false
export events=false
export functions=false
export validators=false

# REPORTS VARS
export report=false
export reportEditor=false
export reportView=false
export reportDesign=false
export reportController=false
export reportEvents=false
export reportFunctions=false
export reportValidators=false
export reportJavascript=false
export reportState=false

# TESTS VARS
export executeTests=false
export unitTest=false
export unitClass=false
export unitProperties=false
export test=false
export poList=false
export poMantain=false
export poView=false
export runCucumberTest=false

#Diferenciado
export createIndex=false
export validateCode=false
export usingMap=false
export queriesMap=false
export snitchMap=false
export appRunGretty=false

# SHELL OPTIONS
for c in $*
do
   if [ "$c" = "--all" ] || [ "$c" = "-A" ]; then
      export all=true
      export syncBoth=true
      export clean=true
      export update=true
      export compile=true
      export persistenceXml=true
   elif [ "$c" = "--validateClassDictionary" ] || [ "$c" = "-va" ]; then
      export validateClassDictionary=true
   elif [ "$c" = "--front-end" ] || [ "$c" = "-F" ]; then
      export frontEnd=true
   elif [ "$c" = "--back-end" ] || [ "$c" = "-B" ]; then
      export backEnd=true
      export persistenceXml=true
	  export identJava=true
   elif [ "$c" = "--identJava" ]; then
      export identJava=true
   elif [ "$c" = "--reports" ] || [ "$c" = "-R" ]; then
      export reports=true
   elif [ "$c" = "--tests" ] || [ "$c" = "-T" ]; then
      export tests=true
      export interface=true
      export classDictionary=true
      export report=true
      export menu=true
   elif [ "$c" = "--unit" ] || [ "$c" = "-U" ]; then
      export unitTests=true
      export classDictionary=true
   elif [ "$c" = "--compile" ] || [ "$c" = "-cp" ]; then
      export compile=true
   elif [ "$c" = "--compile-jms" ] || [ "$c" = "-cjms" ]; then
	  export compileConsumer=true
   elif [ "$c" = "--appRun" ]; then
	  export appRunGretty=true
   elif [ "$c" = "--clean" ] || [ "$c" = "-cl" ]; then
      export clean=true
   elif [ "$c" = "--no-clean" ]; then
      export clean=false
   elif [ "$c" = "--validateCode" ]; then
		export validateCode=true
   elif [ "$c" = "--update" ] || [ "$c" = "-upd" ]; then
      export update=true
   elif [ "$c" = "--no-update" ]; then
      export update=false
   elif [ "$c" = "--class" ] || [ "$c" = "-a" ]; then
      export classDictionary=true
   elif [ "$c" = "--utility" ] || [ "$c" = "-u" ]; then
      export utility=true
   elif [ "$c" = "--storedProcedure" ] || [ "$c" = "-sp" ]; then
      export storedProcedure=true
   elif [ "$c" = "--queue" ] || [ "$c" = "-qu" ]; then
	  export queue=true
   elif [ "$c" = "--referrer" ] || [ "$c" = "-re" ]; then
      export referrer=true
   elif [ "$c" = "--container" ] || [ "$c" = "-co" ]; then
      export container=true
   elif [ "$c" = "--containerIntegration" ] || [ "$c" = "-ci" ]; then
      export containerIntegration=true
   elif [ "$c" = "--containerDW" ] || [ "$c" = "-cw" ]; then
      export containerDW=true
   elif [ "$c" = "--persistenceXml" ]; then
      export persistenceXml=true
   elif [ "$c" = "--query" ] || [ "$c" = "-q" ]; then
      export query=true
   elif [ "$c" = "--domain" ] || [ "$c" = "-n" ]; then
      export domainbackend=true
   elif [ "$c" = "--constructor" ] || [ "$c" = "-ns" ]; then
      export constructor=true
   elif [ "$c" = "--rest" ] || [ "$c" = "-t" ]; then
      export rest=true
   elif [ "$c" = "--restApiManager" ]; then
      export restApiManager=true
   elif [ "$c" = "--rest-container" ] || [ "$c" = "-tc" ]; then
      export restContainer=true
   elif [ "$c" = "--createIndex" ]; then
		createIndex=true
   elif [ "$c" = "--listener" ] || [ "$c" = "-li" ]; then
      export listener=true
   elif [ "$c" = "--interface" ] || [ "$c" = "-i" ]; then
      export interface=true
      STACK="--interface"
   elif [ "$STACK" = "--interface" ]; then
      unset STACK
      continue
   elif [ "$c" = "--indent" ] || [ "$c" = "-i" ]; then
      continue
   elif [ "$c" = "--graph" ] || [ "$c" = "-g" ]; then
      STACK="--graph"
   elif [ "$STACK" = "--graph" ]; then
      unset STACK
      continue
   elif [ "$c" = "--menu" ] || [ "$c" = "-m" ]; then
      export menu=true
   elif [ "$c" = "--routes" ] || [ "$c" = "-r" ]; then
      export routes=true
   elif [ "$c" = "--factory" ] || [ "$c" = "-f" ]; then
      export factory=true
   elif [ "$c" = "--states" ] || [ "$c" = "-s" ]; then
      export states=true
   elif [ "$c" = "--editor" ] || [ "$c" = "-o" ]; then
      export editor=true
   elif [ "$c" = "--list" ] || [ "$c" = "-l" ]; then
      export list=true
   elif [ "$c" = "--view" ] || [ "$c" = "-v" ]; then
      export view=true
   elif [ "$c" = "--controller" ] || [ "$c" = "-c" ]; then
      export controller=true
   elif [ "$c" = "--events" ] || [ "$c" = "-ev" ]; then
      export events=true
   elif [ "$c" = "--functions" ] || [ "$c" = "-fn" ]; then
      export functions=true
   elif [ "$c" = "--validators" ] || [ "$c" = "-vr" ]; then
      export validators=true
   elif [ "$c" = "--ddl" ]; then
         export ddl=true
   elif [ "$c" = "--opcao"  ] && [ "$ddl" = "true" ]; then
         STACK="tipoGeracaoDDL"
         continue
   elif [ "$c" = "--attr"  ] && [ "$ddl" = "true" ]; then
         STACK="atributosDDL"
         continue
   elif [ "$c" = "--consulta"  ] && [ "$ddl" = "true" ]; then
         STACK="queryDDL"
         continue
    elif [ "$STACK" = "tipoGeracaoDDL" ]; then
            unset STACK
            export tipoGeracaoDDL="${c}"
            continue
   elif [ "$STACK" = "atributosDDL" ]; then
            unset STACK
            export atributosDDL="${c}"
            continue
    elif [ "$STACK" = "queryDDL" ]; then
            unset STACK
            export queryDDL="${c}"
            continue
   elif [ "$c" = "--mapas" ]; then
       STACK="--mapas"
       export persistenceXml=false
   elif [ "$c" = "--target" ]; then
      STACK="--target"
	  export persistenceXml=false
   elif [ "$STACK" = "--mapas" ]; then
            unset STACK
            export execMapTarget="${c}"
            continue
   elif [ "$STACK" = "--target" ]; then
      unset STACK
      export execTarget="${c}_*"
      continue
   elif [ "$c" = "--report" ] || [ "$c" = "-p" ]; then
      export report=true
      STACK="--report"
   elif [ "$STACK" = "--report" ]; then
      unset STACK
      continue
  elif [ "$c" = "--report-view" ] || [ "$c" = "-rv" ]; then
      export reportView=true
      #export reportState=true
  elif [ "$c" = "--report-events" ] || [ "$c" = "-rn" ]; then
      export reportEvents=true
  elif [ "$c" = "--report-validators" ] || [ "$c" = "-rr" ]; then
      export reportValidators=true
  elif [ "$c" = "--report-functions" ] || [ "$c" = "-rf" ]; then
      export reportFunctions=true
  elif [ "$c" = "--report-editor" ] || [ "$c" = "-ro" ]; then
      export reportEditor=true
  elif [ "$c" = "--report-controller" ] || [ "$c" = "-rc" ]; then
      export reportController=true
  elif [ "$c" = "--report-state" ] || [ "$c" = "-rs" ]; then
      export reportState=true
  elif [ "$c" = "--report-javascript" ] || [ "$c" = "-rj" ]; then
      export reportJavascript=true
  elif [ "$c" = "--report-design" ] || [ "$c" = "-rd" ]; then
      export reportDesign=true
  elif [ "$c" = "--unit-test" ] || [ "$c" = "-ut" ]; then
      export unitTest=true
  elif [ "$c" = "--unit-class" ] || [ "$c" = "-uc" ]; then
      export unitClass=true
  elif [ "$c" = "--unit-properties" ] || [ "$c" = "-up" ]; then
      export unitProperties=true
  elif [ "$c" = "--exec-unit" ] || [ "$c" = "-eu" ]; then
      export executeTests=true
  elif [ "$c" = "--exec-properties" ] || [ "$c" = "-ep" ]; then
      STACK="--exec-properties"
      continue
  elif [ "$STACK" = "--exec-properties" ]; then
      unset STACK
      export execProperties="${c}"
  elif [ "$c" = "--test-host" ] || [ "$c" = "-th" ]; then
      STACK="--test-host"
      continue
  elif [ "$STACK" = "--test-host" ]; then
      unset STACK
  elif [ "$c" = "--test-port" ] || [ "$c" = "-tp" ]; then
      STACK="--test-port"
      continue
  elif [ "$STACK" = "--test-port" ]; then
      unset STACK
  elif [ "$c" = "--test-app" ] || [ "$c" = "-ta" ]; then
      STACK="--test-app"
      continue
  elif [ "$STACK" = "--test-app" ]; then
      unset STACK
  elif [ "$c" = "--test-user" ] || [ "$c" = "-tu" ]; then
      STACK="--test-user"
      continue
  elif [ "$STACK" = "--test-user" ]; then
      unset STACK
  elif [ "$c" = "--test" ]; then
      export test=true
  elif [ "$c" = "--po-list" ] || [ "$c" = "-lpo" ]; then
      export poList=true
  elif [ "$c" = "--po-maintain" ] || [ "$c" = "-mpo" ]; then
      export poMantain=true
  elif [ "$c" = "--po-view" ] || [ "$c" = "-vpo" ]; then
      export poView=true
  elif [ "$c" = "-crt" ] || [ "$c" = "--runCucumber" ]; then
      export runCucumberTest=true
   elif [ "$c" = "--hot-deploy" ] || [ "$c" = "-hd" ]; then
      export compile=false
      export hotDeploy=true
      export syncBackEnd=true
  elif [ "$c" = "--compile-changes" ] || [ "$c" = "-cc" ]; then
      export compileChanges=true
  elif [ "$c" = "--sync-back-end" ] || [ "$c" = "-syb" ]; then
      export syncBackEnd=true
  elif [ "$c" = "--templatesMap" ]; then
      export templatesMap=true
  elif [ "$c" = "--usingMap" ]; then
      export usingMap=true
  elif [ "$c" = "--queriesMap" ]; then
            export queriesMap=true
  elif [ "$c" = "--snitchMap" ]; then
            export snitchMap=true
  elif [ "$c" = "--sync" ] || [ "$c" = "-sy" ]; then
      export syncBoth=true
      STACK="--sync"
      continue
  elif [ "$STACK" = "--sync" ]; then
      unset STACK
      if [ "$c" = "i" ]; then
         export syncFrontEnd=true
         export syncBoth=false
      elif [ "$c" = "r" ]; then
         export syncReports=true
         export syncBoth=false
      fi
  else
        echo '--> '
        echo "--> Parâmetro ${c} não encontrado. Digite --help para imprimir os comando válidos."
        echo '--> '
        exit 1
  fi
done
