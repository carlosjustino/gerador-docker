#!/bin/bash

# ABORT EXECUTION WITH CTRL + C
trap ctrl_c INT

function ctrl_c() {
	echo '--> '
	echo "--> Encerrando processo..."
	echo '--> '
	exit 1
}

source base.sh

# SHELL OPTIONS
for c in $*
do
    if [ "$c" = "--identJava" ] || [ "$c" = "-B" ]; then
		if [[ "$HOME_ECLIPSE" != "" ]]; then
			export identJava=true
		else
			echo '--> FAVOR DEFINIR A VARIAVEL DE AMBIENTE "HOME_ECLIPSE"'
		fi 
	fi
done


STARTTIME=$(date +%s)
SISTEMAOPERACIONAL="${SISTEMAOPERACIONAL:=LINUX}"

if [[ "$JAVAEXEC" == "" ]]; then 
   JAVAEXEC="java -Xms256m -Xmx2G "
fi

if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
   CAMINHOJAVA=$JAVA_HOME/bin/javaw
else 
   CAMINHOJAVA=$JAVA_HOME/bin/java
fi



if [ "$identJava" = true ]; then
    echo '--> '
	echo '--> Identando arquivos java'
	echo '--> '

	$HOME_ECLIPSE/eclipse -vm "$CAMINHOJAVA" -application org.eclipse.jdt.core.JavaCodeFormatter -quiet -nosplash -config $HOME_GEN/AgroRevendas.prefs $HOME_CORE/src/main/java $HOME_BUSINESS/src/main/java $HOME_REST_API/src/main/java

	ENDTIME=$(date +%s)
	echo '--> '
	echo "--> Identar arquivos java executou em $(($ENDTIME - $STARTTIME)) segundos..."
	echo '--> '

fi