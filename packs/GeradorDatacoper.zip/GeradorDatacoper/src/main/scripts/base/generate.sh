#!/bin/bash
cd $MY_WORKSPACE/../base/
source base.sh

#Carrega Variaveis, Desta forma pode ser utilizado em outros sh sem precisar escrever o "for"
source generateInclude.sh "$@"

STARTTIME=$(date +%s)
echo '--> '
echo '--> Inicializando GeradorDatacoper...'
echo '--> '

export JAR_GERADOR=$HOME_GEN/target/$GEN-$GEN_VERSION-jar-with-dependencies.jar

if [ "$all" = true ]; then
    echo 'PROJECT_NAME.......: '$PROJECT_NAME
    echo 'MY_WORKSPACE.......: '$MY_WORKSPACE
    read -p "--> ATENÇÃO! Voce está prestes a regerar todo o sistema. Deseja continuar? [S/n] " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Ss]$ ]]; then
        echo "-->"
        echo "--> Continuando com generate -A/--all..."
    else
        echo "-->"
        echo "--> Operacao cancelada pelo usuario."
        exit 1
    fi
fi

# CLEAN ENVIROMENT
if [ "$clean" = true ]; then
	./clean.sh "$@"
	if [ $? -ne 0 ]; then
	   exit 1
	fi
fi

# UPDATE SVN
if [ "$update" = true ]; then
	./updateSvn.sh "$@"
	if [ $? -ne 0 ]; then
	   exit 1
	fi
fi

if [ ! -f  $JAR_GERADOR ]; then
    export PASTA_ATUAL=`pwd`
    cd $HOME_GEN
    mvn install
    cd $PASTA_ATUAL
fi
## mm2Dicionario
export mountGraph=true
for c in $*
do
  if [ "$c" = "--graph" ] || [ "$c" = "-g" ]; then
    CMD="--graph"
    continue
  elif [ "$CMD" = "--graph" ]; then
    unset CMD
    export mountGraph=$c
  elif [ "$c" = "--target" ]; then
    CMD="--target"
    continue
  elif [ "$CMD" = "--target" ]; then
    unset CMD
    export target=$c
  fi
done
## DicionarioTelas
export deleteXmlFiles=true
for c in $*
do
  if [ "$c" = "--interface" ] || [ "$c" = "-i" ]; then
    CMD="--interface"
    continue
  elif [ "$CMD" = "--interface" ]; then
    unset CMD
		if [[ $c != -* ]]; then
			export interfaceName=$c
			export deleteXmlFiles=false
		fi
  fi
done

## GENERATE REPORT / XML DICTIONARY
export eraseFiles=true
export deleteXmlFilesReport=true
for c in $*
do
	if [ "$c" = "--front-end" ] || [ "$c" = "-F" ] || [ "$c" = "--interface" ] || [ "$c" = "-i" ] || [ "$c" = "--all" ] || [ "$c" = "-A" ]; then
			export eraseFiles=false
  elif [ "$c" = "--report" ] || [ "$c" = "-p" ]; then
    CMD="--report"
    continue
  elif [ "$CMD" = "--report" ]; then
    unset CMD
		if [[ $c != -* ]]; then
			export reportName=$c
			export deleteXmlFilesReport=false
		fi
  fi
done

# Erro ao excutar pelo Maven Invoker do java #14660
# https://maven.apache.org/shared/maven-invoker/usage.html
# EXECUTE UNIT TESTS
#export params=""
#for c in $*
#do
#    if [ "$c" = "--test-host" ] || [ "$c" = "-th" ]; then
#		STACK="--test-host"
#        continue
#    elif [ "$STACK" = "--test-host" ]; then
#        export params="${params} -Dserver.host=${c}"
#        unset STACK
#    elif [ "$c" = "--test-port" ] || [ "$c" = "-tp" ]; then
#        STACK="--test-port"
#        continue
#    elif [ "$STACK" = "--test-port" ]; then
#        export params="${params} -Dserver.port=${c}"
#        unset STACK
#    elif [ "$c" = "--test-app" ] || [ "$c" = "-ta" ]; then
#        STACK="--test-app"
#        continue
#    elif [ "$STACK" = "--test-app" ]; then
#        export params="${params} -Dserver.app=${c}"
#        unset STACK
#    elif [ "$c" = "--test-user" ] || [ "$c" = "-tu" ]; then
#        STACK="--test-user"
#        continue
#    elif [ "$STACK" = "--test-user" ]; then
#        export params="${params} -Duser.login=${c}"
#        unset STACK
#    fi
#done

# GENERATE UNIT TESTS / DICTIONARY
if [ "$unitTests" = true ] || [ "$unitTest" = true ]; then
	./generateUnitTestsDictionary.sh "$@"
	if [ $? -ne 0 ]; then
	   exit 1
	fi
fi

# GENERATE UNIT TESTS / CLASSES
if [ "$unitTests" = true ] || [ "$unitClass" = true ]; then
	./generateUnitTestsClasses.sh "$@"
	if [ $? -ne 0 ]; then
	   exit 1
	fi
fi

# GENERATE UNIT TESTS / PROPERTIES
if [ "$unitTests" = true ] || [ "$unitProperties" = true ]; then
	./generateUnitTestsProperties.sh "$@"
	if [ $? -ne 0 ]; then
	   exit 1
	fi
fi

# EXECUTE UNIT TESTS
if [ "$executeTests" = true ]; then
	./test.sh "$@"
	if [ $? -ne 0 ]; then
	   exit 1
	fi
fi

$JAVAEXEC -XX:+TieredCompilation -XX:TieredStopAtLevel=1 -jar $JAR_GERADOR
if [ $? -ne 0 ]; then
   exit 1
fi

# COMPILE CONSUMER
if [ "$appRunGretty" = true ]; then
	echo "--> `date`"
    cd $WORKSPACE
    gradle --stop
    gradle --status

    echo 'ERRO -- UTILIZE O WSO2'

    #gradle install appRun
	#if [ $? -ne 0 ]; then
	   exit 1
	#fi

fi

# createIndex
if [ "$createIndex" = true ]; then
    ./generateDDLIndex.sh "$@"
    if [ $? -ne 0 ]; then
       exit 1
    fi
fi
# COMPILE CONSUMER
if [ "$compileConsumer" = true ]; then
	echo "--> `date`"
   ./compileConsumer.sh "$@"
	if [ $? -ne 0 ]; then
	   exit 1
	fi
fi

# IDENTA CODIGO JAVA
if [ "$identJava" = true ] && [ -z $target ]; then
    ./identBackEnd.sh "$@"
	if [ $? -ne 0 ]; then
	   exit 1
	fi
fi

# SYNC FRONT-END TO WSO2
if [ "$syncBoth" = true ] || [ "$syncFrontEnd" = true ]; then

    ./identFrontEnd.sh "$@"
	if [ $? -ne 0 ]; then
	   exit 1
	fi

	echo '--> '
	echo "--> Sincronizando dos arquivos de INTERFACE..."
	echo '--> '
	rsync -avW -e --delete-before --exclude=.svn $SVN_JNG/ $FRONTEND_DEPLOY/$PROJECT_NAME$JNG$JNG_VERSION_PREFIX$JNG_VERSION/
fi

# SYNC REPORTS TO WSO2
if [ "$syncBoth" = true ] || [ "$syncReports" = true ]; then
	echo '--> '
	echo "--> Sincronizando dos arquivos de RELATÓRIOS..."
	echo '--> '
	rsync -vaiO --include='*.rptdesign' --include='*.rptlibrary' --include='project.properties' --include='*/' --include='*.js' --exclude='*' $SVN_RPTDESIGN $REPORTS_DEPLOY
fi

# HOT-DEPLOY
if [ "$hotDeploy" = true ] || [ "$syncBackEnd" = true ] || [ "$compileChanges" = true ]; then
	./hotDeployment.sh "$@"
	if [ $? -ne 0 ]; then
	   exit 1
	fi
fi

ENDTIME=$(date +%s)
echo '--> '
echo "--> GeradorDatacoper executou em $(($ENDTIME - $STARTTIME)) segundos."
echo '--> '
