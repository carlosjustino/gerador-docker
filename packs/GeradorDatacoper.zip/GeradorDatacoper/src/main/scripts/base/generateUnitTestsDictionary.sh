#!/bin/bash

# ABORT EXECUTION WITH CTRL + C
trap ctrl_c INT

function ctrl_c() {
	echo '--> '
	echo "--> Encerrando processo..."
	echo '--> '
	exit 1
}

source base.sh

STARTTIME=$(date +%s)

echo '--> '
echo '--> Gera XML de Testes Unitarios - mm2testeUnitario.xsl'
echo '--> '

xslFile=$HOME_GEN/src/main/java/v2/mm2testeUnitario.xsl
xmlFile=$HOME_GEN/target/classes$PROJECT_NAME.xml
outFile=$HOME_GEN/target/testeUnitario.xml
xmlClasses=$HOME_GEN/target/classes$PROJECT_NAME.xml
testesSourcePath=$HOME_GEN_URL/target/testes
mapasSourcePath=$HOME_MINDMAPS

$EXEC_XSL_SAXON -xsl:$xslFile -s:$xmlFile -o:$outFile testesSourcePath=$testesSourcePath mapasSourcePath=$mapasSourcePath xmlClasses=$xmlClasses

ENDTIME=$(date +%s)
echo '--> '
echo "--> mm2testeUnitario.xsl executou em $(($ENDTIME - $STARTTIME)) segundos..."
echo '--> '
