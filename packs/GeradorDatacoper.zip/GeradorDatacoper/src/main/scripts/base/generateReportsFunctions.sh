#!/bin/bash

# ABORT EXECUTION WITH CTRL + C
trap ctrl_c INT

function ctrl_c() {
	echo '--> '
	echo "--> Encerrando processo..."
	echo '--> '
	exit 1
}

source base.sh

# SHELL OPTIONS
for c in $*
do
  if [ "$c" = "--indent" ] || [ "$c" = "-i" ]; then
		if command -v js-beautify >/dev/null 2>&1 2>/dev/null; then
			indent=true
		fi
	fi
done

STARTTIME=$(date +%s)
echo '--> '
echo '--> Converte o XML de relatorio para JavaScript Functions - telaComplexa2Functions.xsl'
echo '--> '
xslFile=$HOME_GEN/src/main/java/v2/telaComplexa2Functions.xsl
xmlFile=$HOME_GEN/target/xmlListRelatorio_sync.xml
outFile=$HOME_GEN/target/fnRelatorio.lst
functionsSourcePath=$HOME_JNG_URL/app/functions
xmlClasses=$HOME_GEN/target/classes$PROJECT_NAME.xml

$EXEC_XSL_SAXON -xsl:$xslFile -s:$xmlFile -o:$outFile functionsSourcePath=$functionsSourcePath xmlClasses=$xmlClasses sistemaOperacional=$OS ativarBlockUI=$ACTIVATE_BLOCKUI

if [ ! -z "$indent" ]; then
  echo '--> '
  echo '--> Identando arquivos JavaScripts'
  echo '--> '

  listaArq=''
  for arquivo in `cat $HOME_GEN/target/fnRelatorio.lst`;
  do
     listaArq="$listaArq $arquivo"
  done
  js-beautify -q -f $listaArq -r
fi

ENDTIME=$(date +%s)
echo '--> '
echo "--> telaComplexa2Functions.xsl executou em $(($ENDTIME - $STARTTIME)) segundos..."
echo '--> '
