#!/bin/bash

# ABORT EXECUTION WITH CTRL + C
trap ctrl_c INT

function ctrl_c() {
	echo '--> '
	echo "--> Encerrando processo..."
	echo '--> '
	exit 1
}

source base.sh

# SHELL OPTIONS
for c in $*
do
  if [ "$c" = "--indent" ] || [ "$c" = "-i" ]; then
		if command -v js-beautify >/dev/null 2>&1 2>/dev/null; then
			indent=true
		fi
	fi
done

STARTTIME4=$(date +%s)
echo '--> '
echo '--> Converte o XML de tela complexa para HTML, relatorio editor - relatorio2Editor.xsl'
echo '--> '

xslFile=$HOME_GEN/src/main/java/v2/relatorio2Editor.xsl
xmlFile=$HOME_GEN/target/xmlListRelatorio.xml
outFile=$HOME_GEN/target/htmlRelatorio.lst
xmlClasses=$HOME_GEN/target/classes$PROJECT_NAME.xml
htmlSourcePath=$HOME_JNG_URL/app/tpls

$EXEC_XSL_SAXON -xsl:$xslFile -s:$xmlFile -o:$outFile htmlSourcePath=$htmlSourcePath xmlClasses=$xmlClasses sistemaOperacional=$OS

if [ ! -z "$indent" ]; then
  echo '--> '
  echo '--> Identando arquivos HTML Relatorio - Editor'
  echo '--> '

  listaArq=''
  for arquivo in `cat $HOME_GEN/target/htmlRelatorio.lst`;
  do
     listaArq="$listaArq $arquivo"
     # echo $listaArq
  done
  js-beautify -q --type html -r -m 0 -f $listaArq
fi

ENDTIME4=$(date +%s)
echo '--> '
echo "--> relatorio2Editor.xsl executou em $(($ENDTIME4 - $STARTTIME4)) segundos..."
echo '--> '
