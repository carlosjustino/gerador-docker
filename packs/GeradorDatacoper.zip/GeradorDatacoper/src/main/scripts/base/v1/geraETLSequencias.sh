#!/bin/bash
echo '--> '
echo '--> Gera as transformações ETL - Sequencia...'
echo '--> '
STARTTIME=$(date +%s)
if [ -z $SISTEMAOPERACIONAL ]; then
   SISTEMAOPERACIONAL="LINUX"
   export SISTEMAOPERACIONAL
fi

echo '--> '
echo '--> Configurando variaveis locais...'
echo '--> '
HOME_MAPAS=$1
HOME_GERADOR=$2
HOME_XALAN=$3
HOME_SAXON=$4
bancoDados=$5
JAVAEXEC=$6

if [[ "$JAVAEXEC" == "" ]]; then 
   JAVAEXEC="java -Xms256m -Xmx1024m "
fi
echo 'HOME_MAPAS='$HOME_MAPAS
echo 'HOME_GERADOR='$HOME_GERADOR
echo 'HOME_XALAN='$HOME_XALAN
echo 'HOME_SAXON='$HOME_SAXON
echo 'bancoDados='$bancoDados
echo 'JAVAEXEC='$JAVAEXEC


echo '--> '
echo '--> Converte Dicionario para ReconstroiControleSequencia.ktr - ControleSequencial - dicionario2sqlControleSequencia.xsl'
echo '--> '
#---------------------- converte o dicionario para sql - Campos Sequenciais ------------------------------------
xslFile=$HOME_GERADOR/src/main/java/v2/dicionario2sqlControleSequencia.xsl
xmlFile=$HOME_GERADOR/target/classesAgroRevenda.xml
outFile=$HOME_GERADOR/target/ReconstroiControleSequencia.ktr
if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
   #$JAVAEXEC -Dline.separator=$'\n' -cp "$HOME_XALAN/lib/*" org.apache.xalan.xslt.Process -XSL $xslFile -IN $xmlFile -OUT $outFile -PARAM bancoDados $bancoDados
   $JAVAEXEC -jar -Dline.separator=$'\n' $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile bancoDados=$bancoDados
else
   #$JAVAEXEC -cp "$HOME_XALAN/lib/*" org.apache.xalan.xslt.Process -XSL $xslFile -IN $xmlFile -OUT $outFile -PARAM bancoDados $bancoDados
   $JAVAEXEC -jar $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile bancoDados=$bancoDados
fi

ENDTIME=$(date +%s)
echo '--> '
echo "--> geraETLSequencias.sh executou em $(($ENDTIME - $STARTTIME)) segundos."
echo '--> '
