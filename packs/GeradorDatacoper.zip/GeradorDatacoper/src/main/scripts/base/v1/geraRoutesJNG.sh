#!/bin/bash
STARTTIME=$(date +%s)
SISTEMAOPERACIONAL="${SISTEMAOPERACIONAL:=LINUX}"

echo '--> '
echo '--> Gera Routes JNG'
echo '--> '
fazUpdate=true
geraDicionario=true
if [ $# -ge 1 ]; then
   if [ !$1 ]; then
      geraDicionario=$1
   fi
   fazUpdate=false
   if [ $# -ge 2 ]; then
      fazUpdate=$2
   fi
fi

if [ ! $# -ge 1 ]; then
   echo '--> '
   echo '--> Configurando variaveis locais...'
   echo '--> '
fi
PASTASCRIPTS=$3
HOME_GERADOR=$4
HOME_JNG=$5
HOME_JNG_URL=$6
HOME_XALAN=$7
HOME_SAXON=$8
HOME_TEMP=$9
if [[ "$JAVAEXEC" == "" ]]; then 
   JAVAEXEC="java -Xms256m -Xmx2G "
fi


if [ $geraDicionario = true ]; then
   $PASTASCRIPTS/geraDicionarioXML.sh $fazUpdate
   if [ $? -ne 0 ]; then
      exit 1
   fi
fi

echo '--> '
echo '--> Converte o dicionario de classes para route.jag - dicionario2routeJaggery.xsl'
echo '--> '
#---------------------- Routes Jaggery ------------------------------------
jngPath=$HOME_JNG_URL
xslFile=$HOME_GERADOR/src/main/java/v2/dicionario2routeJaggery.xsl
xmlFile=$HOME_GERADOR/target/classesAgroRevenda.xml
outFile=$HOME_JNG/jaggery.conf
cd $HOME_TEMP
echo '--> SAXON Home Edition v9.6.0.7 (Executando)'
if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
   #$JAVAEXEC -Dline.separator=$'\n' -cp "$HOME_XALAN/lib/*" org.apache.xalan.xslt.Process -XSL $xslFile -IN $xmlFile -OUT $outFile  -PARAM jngPath $jngPath
   $JAVAEXEC -jar -Dline.separator=$'\n' $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile jngPath=$jngPath
else
   #$JAVAEXEC -cp "$HOME_XALAN/lib/*" org.apache.xalan.xslt.Process -XSL $xslFile -IN $xmlFile -OUT $outFile  -PARAM jngPath $jngPath
   $JAVAEXEC -jar $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile jngPath=$jngPath
fi

ENDTIME=$(date +%s)
echo '--> '
echo "--> dicionario2routeJaggery.xsl executou em $(($ENDTIME - $STARTTIME)) segundos..."
echo '--> '
