#!/bin/bash
STARTTIME=$(date +%s)
SISTEMAOPERACIONAL="${SISTEMAOPERACIONAL:=LINUX}"
echo '--> '
echo '--> Gera XML Telas'
echo '--> '
fazUpdate=true
geraDicionario=true
if [ $# -ge 1 ]; then
   if [ !$1 ]; then
      geraDicionario=$1
   fi
   fazUpdate=false
   if [ $# -ge 2 ]; then
      fazUpdate=$2
   fi
fi

if [ ! $# -ge 1 ]; then
   echo '--> '
   echo '--> Configurando variaveis locais...'
   echo '--> '
fi
PASTASCRIPTS=$3
HOME_GERADOR=$4
HOME_MAPAS=$5
HOME_JNG=$6
HOME_JNG_URL=$7
HOME_XALAN=$8
HOME_SAXON=$9
HOME_TEMP=${10}
if [[ "$JAVAEXEC" == "" ]]; then 
   JAVAEXEC="java -Xms256m -Xmx2G "
fi

if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
   if [[ "$HOME_GERADOR_URL" == "" ]]; then
      export HOME_GERADOR_URL="file:///"$HOME_GERADOR
   fi
else
   if [[ "$HOME_GERADOR_URL" == "" ]]; then
      export HOME_GERADOR_URL="file://"$HOME_GERADOR
   fi
fi

if [ $geraDicionario = true ]; then
   $PASTASCRIPTS/geraDicionarioXML.sh $fazUpdate
   if [ $? -ne 0 ]; then
      exit 1
   fi
fi

# .. Incluido para evitar erros em telas renomeadas
echo '--> '
echo '--> Apagando arquivos XML de telas'
echo '--> '
rm -rf $HOME_GERADOR/target/telas/*
# ..


STARTTIME1=$(date +%s)
echo '--> '
echo '--> Converte o mapa para XML Tela Simples Customizada - mm2telaSimplesCustomizada.xsl'
echo '--> '
#---------------------- converte o mapa para XML Tela Simples Customizada ------------------------------------
xslFile=$HOME_GERADOR/src/main/java/v2/mm2telaSimplesCustomizada.xsl
xmlFile=$HOME_MAPAS/AgroRevenda.mm
outFile=$HOME_GERADOR/target/xmlListTelaSimplesCustomizada.xml
telaSimplesCustomizadaSourcePath=$HOME_GERADOR_URL/target/telas
classesAgroRevenda=$HOME_GERADOR/target/classesAgroRevenda.xml
padroesFileName=$HOME_GERADOR/target/padroesAgroRevenda.xml
echo '--> SAXON Home Edition v9.6.0.7 (Executando)'
if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
   #$JAVAEXEC -Dline.separator=$'\n' -cp "$HOME_XALAN/lib/*" org.apache.xalan.xslt.Process -XSL $xslFile -IN $xmlFile -OUT $outFile -PARAM telaSimplesCustomizadaSourcePath $telaSimplesCustomizadaSourcePath -PARAM classesAgroRevenda $classesAgroRevenda -PARAM padroesFileName $padroesFileName
   $JAVAEXEC -jar -Dline.separator=$'\n' $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile telaSimplesCustomizadaSourcePath=$telaSimplesCustomizadaSourcePath classesAgroRevenda=$classesAgroRevenda padroesFileName=$padroesFileName sistemaOperacional=$SISTEMAOPERACIONAL
else
   #$JAVAEXEC -cp "$HOME_XALAN/lib/*" org.apache.xalan.xslt.Process -XSL $xslFile -IN $xmlFile -OUT $outFile -PARAM telaSimplesCustomizadaSourcePath $telaSimplesCustomizadaSourcePath -PARAM classesAgroRevenda $classesAgroRevenda -PARAM padroesFileName $padroesFileName
   $JAVAEXEC -jar $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile telaSimplesCustomizadaSourcePath=$telaSimplesCustomizadaSourcePath classesAgroRevenda=$classesAgroRevenda padroesFileName=$padroesFileName sistemaOperacional=$SISTEMAOPERACIONAL
fi
ENDTIME1=$(date +%s)
echo '--> '
echo "--> mm2telaSimplesCustomizada.xsl executou em $(($ENDTIME1 - $STARTTIME1)) segundos..."
echo '--> '

STARTTIME2=$(date +%s)
echo '--> '
echo '--> Converte o mapa para XML de lista Tela Complexa - mm2listaTelaComplexa.xsl'
echo '--> '
#---------------------- converte o mapa para XML de lista Tela Complexa ------------------------------------
xslFile=$HOME_GERADOR/src/main/java/v2/mm2listaTelaComplexa.xsl
xmlFile=$HOME_MAPAS/AgroRevenda.mm
outFile=$HOME_GERADOR/target/listaTelaComplexa.xml
echo '--> SAXON Home Edition v9.6.0.7 (Executando)'
if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
   #$JAVAEXEC -Dline.separator=$'\n' -cp "$HOME_XALAN/lib/*" org.apache.xalan.xslt.Process -XSL $xslFile -IN $xmlFile -OUT $outFile
   $JAVAEXEC -jar -Dline.separator=$'\n' $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile
else
   #$JAVAEXEC -cp "$HOME_XALAN/lib/*" org.apache.xalan.xslt.Process -XSL $xslFile -IN $xmlFile -OUT $outFile
   $JAVAEXEC -jar -Dline.separator=$'\n' $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile
fi
if [ $? -ne 0 ]; then
   exit 1
fi
ENDTIME2=$(date +%s)
echo '--> '
echo "--> mm2listaTelaComplexa.xsl executou em $(($ENDTIME2 - $STARTTIME2)) segundos..."
echo '--> '

STARTTIME3=$(date +%s)
echo '--> '
echo '--> Converte o mapa para o XML de Tela Complexa - mm2telaComplexa.xsl'
echo '--> '
#---------------------- converte o mapa para XML de Tela Complexa ------------------------------------
xslFile=$HOME_GERADOR/src/main/java/v2/mm2telaComplexa.xsl
xmlFile=$HOME_GERADOR/target/listaTelaComplexa.xml
outFile=$HOME_GERADOR/target/xmlListTelaComplexa.xml
telaComplexaSourcePath=$HOME_GERADOR_URL/target/telas
xmlClasses=$HOME_GERADOR/target/classesAgroRevenda.xml
mapasSourcePath=$HOME_MAPAS
padroesFileName=$HOME_GERADOR/target/padroesAgroRevenda.xml
echo '--> SAXON Home Edition v9.6.0.7 (Executando)'
if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
   #$JAVAEXEC -Dline.separator=$'\n' -cp "$HOME_XALAN/lib/*" org.apache.xalan.xslt.Process -XSL $xslFile -IN $xmlFile -OUT $outFile -PARAM telaComplexaSourcePath $telaComplexaSourcePath -PARAM xmlClasses $xmlClasses -PARAM mapasSourcePath $mapasSourcePath -PARAM padroesFileName $padroesFileName
   $JAVAEXEC -jar -Dline.separator=$'\n' $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile telaComplexaSourcePath=$telaComplexaSourcePath xmlClasses=$xmlClasses mapasSourcePath=$mapasSourcePath padroesFileName=$padroesFileName
else
   #$JAVAEXEC -cp "$HOME_XALAN/lib/*" org.apache.xalan.xslt.Process -XSL $xslFile -IN $xmlFile -OUT $outFile -PARAM telaComplexaSourcePath $telaComplexaSourcePath -PARAM xmlClasses $xmlClasses -PARAM mapasSourcePath $mapasSourcePath -PARAM padroesFileName $padroesFileName
   $JAVAEXEC -jar $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile telaComplexaSourcePath=$telaComplexaSourcePath xmlClasses=$xmlClasses mapasSourcePath=$mapasSourcePath padroesFileName=$padroesFileName
fi
if [ $? -ne 0 ]; then
   exit 1
fi
ENDTIME3=$(date +%s)
echo '--> '
echo "--> mm2telaComplexa.xsl executou em $(($ENDTIME3 - $STARTTIME3)) segundos..."
echo '--> '

STARTTIME4=$(date +%s)
echo '--> '
echo '--> Converte o mapa para XML de lista Relatorio - mm2listaRelatorio.xsl'
echo '--> '

xslFile=$HOME_GERADOR/src/main/java/v2/mm2listaRelatorio.xsl
xmlFile=$HOME_MAPAS/MenuPrincipalSistema.mm
outFile=$HOME_GERADOR/target/listaRelatorio.xml
echo '--> SAXON Home Edition v9.6.0.7 (Executando)'
if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
   $JAVAEXEC -jar -Dline.separator=$'\n' $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile
else
   $JAVAEXEC -jar $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile
fi
if [ $? -ne 0 ]; then
   exit 1
fi
ENDTIME4=$(date +%s)
echo '--> '
echo "--> mm2listaRelatorio.xsl executou em $(($ENDTIME4 - $STARTTIME4)) segundos..."
echo '--> '

STARTTIME5=$(date +%s)
echo '--> '
echo '--> Converte o mapa para o XML de Relatorio - mm2relatorio.xsl'
echo '--> '

xslFile=$HOME_GERADOR/src/main/java/v2/mm2relatorio.xsl
xmlFile=$HOME_GERADOR/target/listaRelatorio.xml
outFile=$HOME_GERADOR/target/xmlListRelatorio.xml
relatorioSourcePath=$HOME_GERADOR_URL/target
xmlClasses=$HOME_GERADOR/target/classesAgroRevenda.xml
mapasSourcePath=$HOME_MAPAS
padroesFileName=$HOME_GERADOR/target/padroesAgroRevenda.xml
   
echo '--> SAXON Home Edition v9.6.0.7 (Executando)'
$JAVAEXEC -jar -Dline.separator=$'\n' $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile relatorioSourcePath=$relatorioSourcePath xmlClasses=$xmlClasses mapasSourcePath=$mapasSourcePath padroesFileName=$padroesFileName

ENDTIME5=$(date +%s)
echo '--> '
echo "--> mm2relatorio.xsl executou em $(($ENDTIME5 - $STARTTIME5)) segundos..."
echo '--> '

ENDTIME=$(date +%s)
echo '--> '
echo "--> geraXmlTelas.sh executou em $(($ENDTIME - $STARTTIME)) segundos."
echo '--> '
