#!/bin/bash
echo '--> '
echo '--> Identa codigo Java...'
echo '--> '
source variaveisLocais.sh

STARTTIME=$(date +%s)
SISTEMAOPERACIONAL="${SISTEMAOPERACIONAL:=LINUX}"

if [[ "$JAVAEXEC" == "" ]]; then 
   JAVAEXEC="java -Xms256m -Xmx2G "
fi

if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
   CAMINHOJAVA=$JAVA_HOME/bin/javaw
else 
   CAMINHOJAVA=$JAVA_HOME/bin/java
fi


if [[ "$REVISAOARQUITETURA" == "" ]]; then 
   echo '--> '
   echo '--> Formatando codigo java - ECLIPSE FORMATTER'
   echo '--> '   
#   if [[ "$HOME_ECLIPSE" != "" ]]; then 
#      $HOME_ECLIPSE/eclipse -vm "$CAMINHOJAVA" -application org.eclipse.jdt.core.JavaCodeFormatter -quiet -nosplash -config $HOME_GERADOR/AgroRevendas.prefs $HOME_DOMAIN/src/main/java $HOME_REST_API/src/main/java
#   else
#      echo '--> FAVOR DEFINIR A VARIAVEL DE AMBIENTE "HOME_ECLIPSE"'
#   fi   
fi


ENDTIME=$(date +%s)
echo '--> '
echo "--> identaCodigoJava.sh executou em $(($ENDTIME - $STARTTIME)) segundos..."
echo '--> '
