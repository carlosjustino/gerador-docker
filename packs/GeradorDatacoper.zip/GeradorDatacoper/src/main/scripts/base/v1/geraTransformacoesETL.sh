#!/bin/bash
echo '--> '
echo '--> Gera as transformações ETL...'
echo '--> '

STARTTIME=$(date +%s)
if [ -z $SISTEMAOPERACIONAL ]; then
   SISTEMAOPERACIONAL="LINUX"
   export SISTEMAOPERACIONAL
fi

echo '--> '
echo '--> Configurando variaveis locais...'
echo '--> '

HOME_MAPAS=$1
HOME_GERADOR=$2
HOME_XALAN=$3
HOME_SAXON=$4
bancoDados=$5
JAVAEXEC=$6
TENANT=$7
if [[ "$JAVAEXEC" == "" ]]; then 
   JAVAEXEC="java -Xms256m -Xmx2G "
fi
echo 'HOME_MAPAS='$HOME_MAPAS
echo 'HOME_GERADOR='$HOME_GERADOR
echo 'HOME_XALAN='$HOME_XALAN
echo 'HOME_SAXON='$HOME_SAXON
echo 'bancoDados='$bancoDados
echo 'JAVAEXEC='$JAVAEXEC
echo 'TENANT='$TENANT
PASTASCRIPTS=$HOME_GERADOR/src/main/scripts/base
STARTTIME1=$(date +%s)
echo '--> '
echo '--> Converte o dicionario de classes para Kettle Transformations - dicionario2etl.xsl'
echo '--> '
##converte o dicionario de classes para Kettle Transformations
etlSourcePath=$HOME_MAPAS/etl
xslFile=$HOME_GERADOR/src/main/java/v2/dicionario2etl.xsl
xmlFile=$HOME_GERADOR/target/classesAgroRevenda.xml
outFile=$HOME_GERADOR/target/ktrAgroRevendaGerados.xml
echo '--> SAXON Home Edition v9.6.0.7 (Executando)'
if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
   #$JAVAEXEC -Dline.separator=$'\n' -cp "$HOME_XALAN/lib/*" org.apache.xalan.xslt.Process -XSL $xslFile -IN $xmlFile  -OUT $outFile -PARAM etlSourcePath $etlSourcePath
   $JAVAEXEC -jar -Dline.separator=$'\n' $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile  etlSourcePath=$etlSourcePath tenant=$TENANT
else
   #$JAVAEXEC -cp "$HOME_XALAN/lib/*" org.apache.xalan.xslt.Process -XSL $xslFile -IN $xmlFile  -OUT $outFile -PARAM etlSourcePath $etlSourcePath
   $JAVAEXEC -jar $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile  etlSourcePath=$etlSourcePath tenant=$TENANT
fi
ENDTIME1=$(date +%s)
echo '--> '
echo "--> dicionario2etl.xsl executou em $(($ENDTIME1 - $STARTTIME1)) segundos..."
echo '--> '

$PASTASCRIPTS/geraETLSequencias.sh $HOME_MAPAS $HOME_GERADOR $HOME_XALAN $HOME_SAXON $bancoDados "$JAVAEXEC"
if [ $? -ne 0 ]; then
   exit 1
fi

STARTTIME3=$(date +%s)
echo '--> '
echo '--> Converte o dicionario de classes para XML Carga de dados fixa ETL - dicionario2cargaDadosFixosETL.xsl'
echo '--> '
#converte o dicionario de classes para XML Carga de dados fixa ETL
cargaDadosSourcePath=$HOME_MAPAS/cargaDados
xslFile=$HOME_GERADOR/src/main/java/v2/dicionario2cargaDadosFixosETL.xsl
xmlFile=$HOME_GERADOR/target/classesAgroRevenda.xml
outFile=$HOME_GERADOR/target/xmlInstanciasAgroRevendaGerados.xml

echo '--> SAXON Home Edition v9.6.0.7 (Executando)'
if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
   #$JAVAEXEC -Dline.separator=$'\n' -cp "$HOME_XALAN/lib/*" org.apache.xalan.xslt.Process -XSL $xslFile -IN $xmlFile  -OUT $outFile -PARAM etlSourcePath $etlSourcePath
   $JAVAEXEC -jar -Dline.separator=$'\n' $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile cargaDadosSourcePath=$cargaDadosSourcePath tenant=$TENANT
else
   #$JAVAEXEC -cp "$HOME_XALAN/lib/*" org.apache.xalan.xslt.Process -XSL $xslFile -IN $xmlFile  -OUT $outFile -PARAM etlSourcePath $etlSourcePath
   $JAVAEXEC -jar $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile cargaDadosSourcePath=$cargaDadosSourcePath tenant=$TENANT
fi

ENDTIME3=$(date +%s)
echo '--> '
echo "--> dicionario2cargaDadosFixosETL.xsl executou em $(($ENDTIME3 - $STARTTIME3)) segundos..."
echo '--> '

STARTTIME4=$(date +%s)
echo '--> '
echo '--> Converte o dicionario de classes para Kettle Transformations Instancias - dicionario2etlDadosFixos.xsl'
echo '--> '
##converte o dicionario de classes para Kettle Transformations Instancias
etlSourcePath=$HOME_MAPAS/etl
xslFile=$HOME_GERADOR/src/main/java/v2/dicionario2etlDadosFixos.xsl
xmlFile=$HOME_GERADOR/target/classesAgroRevenda.xml
outFile=$HOME_GERADOR/target/ktrInstanciasAgroRevendaGerados.xml

echo '--> SAXON Home Edition v9.6.0.7 (Executando)'
if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
   #$JAVAEXEC -Dline.separator=$'\n' -cp "$HOME_XALAN/lib/*" org.apache.xalan.xslt.Process -XSL $xslFile -IN $xmlFile  -OUT $outFile -PARAM etlSourcePath $etlSourcePath
   $JAVAEXEC -jar -Dline.separator=$'\n' $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile  etlSourcePath=$etlSourcePath tenant=$TENANT
else
   #$JAVAEXEC -cp "$HOME_XALAN/lib/*" org.apache.xalan.xslt.Process -XSL $xslFile -IN $xmlFile  -OUT $outFile -PARAM etlSourcePath $etlSourcePath
   $JAVAEXEC -jar $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile  etlSourcePath=$etlSourcePath tenant=$TENANT
fi

ENDTIME4=$(date +%s)
echo '--> '
echo "--> dicionario2etlDadosFixos.xsl executou em $(($ENDTIME4 - $STARTTIME4)) segundos..."
echo '--> '

ENDTIME=$(date +%s)
echo '--> '
echo "--> geraTransformacoesETL.sh executou em $(($ENDTIME - $STARTTIME)) segundos."
echo '--> '
