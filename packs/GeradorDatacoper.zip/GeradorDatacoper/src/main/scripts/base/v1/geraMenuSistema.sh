#!/bin/bash
STARTTIME=$(date +%s)
SISTEMAOPERACIONAL="${SISTEMAOPERACIONAL:=LINUX}"
TIPO_EXECUCAO="${TIPO_EXECUCAO:=LOCAL}"

echo '--> '
echo '--> Gera Menu do Sistema'
echo '--> '
fazUpdate=true
geraDicionario=true
if [ $# -ge 1 ]; then
   if [ !$1 ]; then
      geraDicionario=$1
   fi
   fazUpdate=false
   if [ $# -ge 2 ]; then
      fazUpdate=$2
   fi
fi

if [ ! $# -ge 1 ]; then
   echo '--> '
   echo '--> Configurando variaveis locais...'
   echo '--> '
fi
PASTASCRIPTS=$3
HOME_GERADOR=$4
HOME_MAPAS=$5
HOME_JNG=$6
HOME_JNG_URL=$7
HOME_XALAN=$8
HOME_SAXON=$9
HOME_TEMP=${10}
if [[ "$JAVAEXEC" == "" ]]; then 
   JAVAEXEC="java -Xms256m -Xmx2G "
fi


if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
   if [[ "$HOME_GERADOR_URL" == "" ]]; then
      export HOME_GERADOR_URL="file:///"$HOME_GERADOR
   fi
else
   if [[ "$HOME_GERADOR_URL" == "" ]]; then
      export HOME_GERADOR_URL="file://"$HOME_GERADOR
   fi
fi


if [ $geraDicionario = true ]; then
   $PASTASCRIPTS/geraDicionarioXML.sh $fazUpdate
   if [ $? -ne 0 ]; then
      exit 1
   fi
fi

STARTTIME2=$(date +%s)
echo '--> '
echo '--> Converte o mapa de menu para o XML - mm2menuXml.xsl'
echo '--> '
#---------------------- gerador XML Menu Principal ------------------------------------
classesXMLFile=$HOME_GERADOR_URL/target/classesAgroRevenda.xml
xmlTelaSourcePath=$HOME_GERADOR/target
xslFile=$HOME_GERADOR/src/main/java/v2/mm2menuXml.xsl
xmlFile=$HOME_MAPAS/MenuPrincipalSistema.mm
outFile=$HOME_GERADOR/target/menuPrincipalSistema.xml
echo '--> SAXON Home Edition v9.6.0.7 (Executando)'
if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
   #$JAVAEXEC -Dline.separator=$'\n' -cp "$HOME_XALAN/lib/*" org.apache.xalan.xslt.Process -XSL $xslFile -IN $xmlFile -OUT $outFile -PARAM classesXMLFile $classesXMLFile
   $JAVAEXEC -jar -Dline.separator=$'\n' $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile classesXMLFile=$classesXMLFile xmlTelaSourcePath=$xmlTelaSourcePath
else
   #$JAVAEXEC -cp "$HOME_XALAN/lib/*" org.apache.xalan.xslt.Process -XSL $xslFile -IN $xmlFile -OUT $outFile -PARAM classesXMLFile $classesXMLFile
   $JAVAEXEC -jar $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile classesXMLFile=$classesXMLFile xmlTelaSourcePath=$xmlTelaSourcePath
fi
ENDTIME2=$(date +%s)
echo '--> '
echo "--> mm2menuXml.xsl executou em $(($ENDTIME2 - $STARTTIME2)) segundos..."
echo '--> '

STARTTIME1=$(date +%s)
echo '--> '
echo '--> Converte o mapa de menu para o Json(menu Lateral) - mm2menuJson.xsl'
echo '--> '
#---------------------- gerador JSON Menu Principal ------------------------------------
classesXMLFile=$HOME_GERADOR_URL/target/classesAgroRevenda.xml
mapasSourcePath=$HOME_MAPAS
xslFile=$HOME_GERADOR/src/main/java/v2/mm2menuJson.xsl
xmlFile=$HOME_GERADOR/target/menuPrincipalSistema.xml
outFile=$HOME_JNG/app/menu/menuPrincipalSistema.json
if [ ! -d "$HOME_JNG/app/menu" ]; then
mkdir $HOME_JNG/app/menu
chmod 777 $HOME_JNG/app/menu
fi
echo '--> SAXON Home Edition v9.6.0.7 (Executando)'
if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
   #$JAVAEXEC -Dline.separator=$'\n' -cp "$HOME_XALAN/lib/*" org.apache.xalan.xslt.Process -XSL $xslFile -IN $xmlFile -OUT $outFile -PARAM classesXMLFile $classesXMLFile
   $JAVAEXEC -jar -Dline.separator=$'\n' $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile classesXMLFile=$classesXMLFile mapasSourcePath=$mapasSourcePath sistemaOperacional=$SISTEMAOPERACIONAL
else
   #$JAVAEXEC -cp "$HOME_XALAN/lib/*" org.apache.xalan.xslt.Process -XSL $xslFile -IN $xmlFile -OUT $outFile -PARAM classesXMLFile $classesXMLFile
   $JAVAEXEC -jar $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile classesXMLFile=$classesXMLFile mapasSourcePath=$mapasSourcePath sistemaOperacional=$SISTEMAOPERACIONAL
fi
ENDTIME1=$(date +%s)
echo '--> '
echo "--> mm2menuJson.xsl executou em $(($ENDTIME1 - $STARTTIME1)) segundos..."
echo '--> '

STARTTIME3=$(date +%s)
echo '--> '
echo '--> Converte o xml do menu para o Json(menu Horizontal) - menuXml2menuHorizontalJson.xsl'
echo '--> '
#---------------------- gerador JSON Menu Horizontal ------------------------------------
xslFile=$HOME_GERADOR/src/main/java/v2/menuXml2menuHorizontalJson.xsl
xmlFile=$HOME_GERADOR/target/menuPrincipalSistema.xml
outFile=$HOME_JNG/app/menu/menuHorizontalSistema.json
if [ ! -d "$HOME_JNG/app/menu" ]; then
mkdir $HOME_JNG/app/menu
chmod 777 $HOME_JNG/app/menu
fi
echo '--> SAXON Home Edition v9.6.0.7 (Executando)'
if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
   #$JAVAEXEC -Dline.separator=$'\n' -cp "$HOME_XALAN/lib/*" org.apache.xalan.xslt.Process -XSL $xslFile -IN $xmlFile -OUT $outFile
   $JAVAEXEC -jar -Dline.separator=$'\n' $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile
else
   #$JAVAEXEC -cp "$HOME_XALAN/lib/*" org.apache.xalan.xslt.Process -XSL $xslFile -IN $xmlFile -OUT $outFile
   $JAVAEXEC -jar -Dline.separator=$'\n' $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile
fi
ENDTIME3=$(date +%s)
echo '--> '
echo "--> menuXml2menuHorizontalJson.xsl executou em $(($ENDTIME3 - $STARTTIME3)) segundos..."
echo '--> '

echo '--> '
echo '--> Converte o menuPrincipalSistema.xml para rotinaMenu.sql - menuPrincipalSistema2db.xsl'
echo '--> '

xslFile=$HOME_GERADOR/src/main/java/v2/menuPrincipalSistema2db.xsl
xmlFile=$HOME_GERADOR/target/menuPrincipalSistema.xml
outFile=$HOME_GERADOR/target/rotinaMenu.sql

if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
   $JAVAEXEC -jar -Dline.separator=$'\n' $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile
else
   $JAVAEXEC -jar $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile
fi

echo '--> '
echo "--> Movendo script RotinaMenu.sql para /GeradorDatacoper/src/main/scripts/banco"
echo '--> '
rm -rf $HOME_GERADOR/src/main/scripts/banco/rotinaMenu*.sql
mv $HOME_GERADOR/target/rotinaMenu.sql $HOME_GERADOR/src/main/scripts/banco/rotinaMenu-$(date +%F-%H-%M).sql

ENDTIME=$(date +%s)
echo '--> '
echo "--> geraMenuSistema.sh executou em $(($ENDTIME - $STARTTIME)) segundos."
echo '--> '
