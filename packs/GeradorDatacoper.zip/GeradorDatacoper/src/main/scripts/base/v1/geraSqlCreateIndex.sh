#!/bin/bash

STARTTIME=$(date +%s)

SISTEMAOPERACIONAL="${SISTEMAOPERACIONAL:=LINUX}"

echo 'HOME_GERADOR='$1
echo 'HOME_SAXON='$2
echo '--> '
HOME_GERADOR=$1
HOME_SAXON=$2
export classeAlvo='ND'
if [ $# -ge 3 ]; then
   classeAlvo=$3
fi 

if [[ $JAVAEXEC == "" ]]; then
   JAVAEXEC="java -Xms256m -Xmx1024m "
fi

echo '--> '
echo '--> geraSqlCreateIndex'
echo '--> '
xslFile=$HOME_GERADOR/src/main/java/v2/createIndex.xsl
xmlFile=$HOME_GERADOR/target/classesAgroRevenda.xml
outFile=$HOME_GERADOR/target/sqlCreateIndex.sql
echo '--> SAXON Home Edition v9.6.0.7 (Executando)'
if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
   #$JAVAEXEC -Dline.separator=$'\n' -cp "$HOME_XALAN/lib/*" org.apache.xalan.xslt.Process -XSL $xslFile -IN $xmlFile  -OUT $outFile
   $JAVAEXEC -jar -Dline.separator=$'\n' $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile classeAlvo=$classeAlvo
else
   #$JAVAEXEC -cp "$HOME_XALAN/lib/*" org.apache.xalan.xslt.Process -XSL $xslFile -IN $xmlFile  -OUT $outFile
   $JAVAEXEC -jar $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile classeAlvo=$classeAlvo
fi


ENDTIME=$(date +%s)
echo '--> '
echo "--> geraSqlCreateIndex.sh executou em $(($ENDTIME - $STARTTIME)) segundos."
echo '--> '
