#!/bin/bash
STARTTIME=$(date +%s)
#PASTASCRIPTS=/cygdrive/c/Carlosj/AgroRevendas/SVN/GeradorDatacoper/trunk/GeradorDatacoper/src/main/scripts/CarlosJ
SISTEMAOPERACIONAL="${SISTEMAOPERACIONAL:=LINUX}"
echo '--> '
echo '--> Configurando variaveis locais...'
echo '--> '
HOME_GERADOR=$1
HOME_SAXON=$2
HOME_TEMP=$3
export classeAlvo='ND'
if [ $# -ge 4 ]; then
   classeAlvo=$4
fi 

if [[ "$JAVAEXEC" == "" ]]; then 
   JAVAEXEC="java -Xms512m -Xmx2G "
fi

if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
   if [[ "$HOME_GERADOR_URL" == "" ]]; then
      export HOME_GERADOR_URL="file:///"$HOME_GERADOR
   fi
else 
   if [[ "$HOME_GERADOR_URL" == "" ]]; then
      export HOME_GERADOR_URL="file://"$HOME_GERADOR
   fi
fi

echo '--> '
echo '--> Converte o dicionario de classes para XML de Referencias Parte 2- dicionario2xmlReferenciasCompleto.xsl'
echo '--> '
##----------------------- xml referencias -------------------------------------------------
outputFolder=$HOME_GERADOR_URL/target
xslFile=$HOME_GERADOR/src/main/java/v2/dicionario2xmlReferenciasCompleto.xsl
xmlFile=$HOME_GERADOR/target/xmlReferencias.xml
outFile=$HOME_GERADOR/target/xmlReferenciasCompleto.xml

echo '--> SAXON Home Edition v9.6.0.7 (Executando)'
if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
   $JAVAEXEC -jar -Dline.separator=$'\n' $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile outputFolder=$outputFolder
else
   $JAVAEXEC -jar $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile outputFolder=$outputFolder
fi

ENDTIME=$(date +%s)
echo '--> '
echo "--> dicionario2xmlReferenciasCompleto.xsl executou em $(($ENDTIME - $STARTTIME)) segundos..."
echo '--> '
