#!/bin/bash
STARTTIME=$(date +%s)
SISTEMAOPERACIONAL="${SISTEMAOPERACIONAL:=LINUX}"

echo '--> '
echo '--> Gera NGFactory do Sistema'
echo '--> '
fazUpdate=true
geraDicionario=true
if [ $# -ge 1 ]; then
   if [ !$1 ]; then
      geraDicionario=$1
   fi
   fazUpdate=false
   if [ $# -ge 2 ]; then
      fazUpdate=$2
   fi
fi

if [ ! $# -ge 1 ]; then
   echo '--> '
   echo '--> Configurando variaveis locais...'
   echo '--> '
fi
PASTASCRIPTS=$3
HOME_GERADOR=$4
HOME_MAPAS=$5
HOME_JNG=$6
HOME_JNG_URL=$7
HOME_XALAN=$8
HOME_SAXON=$9
HOME_TEMP=${10}
ATIVAR_BLOCKUI=${11}
unity='ND'
if [ $# -ge 12 ]; then
   unity=${12}
fi

if [[ "$JAVAEXEC" == "" ]]; then 
   JAVAEXEC="java -Xms256m -Xmx2G "
fi

if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
   if [[ "$HOME_GERADOR_URL" == "" ]]; then
      export HOME_GERADOR_URL="file:///"$HOME_GERADOR
   fi
else
   if [[ "$HOME_GERADOR_URL" == "" ]]; then
      export HOME_GERADOR_URL="file://"$HOME_GERADOR
   fi
fi


if [ $geraDicionario = true ]; then
   $PASTASCRIPTS/geraDicionarioXML.sh $fazUpdate
   if [ $? -ne 0 ]; then
      exit 1
   fi
fi

echo '--> '
echo '--> Converte o dicionario para NG Factory Classes - dicionario2ngFactory.xsl'
echo '--> '
#---------------------- NG Factory Classes ------------------------------------
factorySourcePath=$HOME_JNG_URL/app/factory
xslFile=$HOME_GERADOR/src/main/java/v2/dicionario2ngFactory.xsl
xmlFile=$HOME_GERADOR/target/classesAgroRevenda.xml
outFile=$HOME_TEMP/factorySource.lst
echo '--> SAXON Home Edition v9.6.0.7 (Executando)'
if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
   #$JAVAEXEC -Dline.separator=$'\n' -cp "$HOME_XALAN/lib/*" org.apache.xalan.xslt.Process -XSL $xslFile -IN $xmlFile -OUT $outFile  -PARAM factorySourcePath $factorySourcePath
   $JAVAEXEC -jar -Dline.separator=$'\n' $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile factorySourcePath=$factorySourcePath unity=$unity ativarBlockUI=$ATIVAR_BLOCKUI
else
   #$JAVAEXEC -cp "$HOME_XALAN/lib/*" org.apache.xalan.xslt.Process -XSL $xslFile -IN $xmlFile -OUT $outFile  -PARAM factorySourcePath $factorySourcePath
   $JAVAEXEC -jar $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile factorySourcePath=$factorySourcePath unity=$unity ativarBlockUI=$ATIVAR_BLOCKUI
fi

echo '--> '
echo '--> Identando arquivos JavaScripts'
echo '--> '
listaArq=''
count=0
for arquivo in `find $HOME_JNG/app/factory -type f -name "*.js"`; do	
   ((count++))
   listaArq="$listaArq $arquivo"
   if [ $count -eq 100 ]; then
		js-beautify -q -f $listaArq -r > /dev/null &
		listaArq=''
		count=0
   fi
done
js-beautify -q -f $listaArq -r > /dev/null &

ENDTIME=$(date +%s)
echo '--> '
echo "--> geraNGFactory.sh executou em $(($ENDTIME - $STARTTIME)) segundos."
echo '--> '
