#!/bin/bash
if [ -z $SISTEMAOPERACIONAL ]; then
   SISTEMAOPERACIONAL="LINUX"
   export SISTEMAOPERACIONAL
fi
if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
   if [[ "$HOME_GERADOR_URL" == "" ]]; then
      export HOME_GERADOR_URL="file:///"$HOME_GERADOR
   fi
else
   if [[ "$HOME_GERADOR_URL" == "" ]]; then
      export HOME_GERADOR_URL="file://"$HOME_GERADOR
   fi
fi
all=false
editor=false
design=false
for c in $* 
do
	if [ "$c" = "--all" ] || [ "$c" = "--all" ] || [ "$c" = "all" ]; then
		all=true
	elif [ "$c" = "--design" ] || [ "$c" = "-design" ] || [ "$c" = "design" ]; then
		design=true
	elif [ "$c" = "--editor" ] || [ "$c" = "-editor" ] || [ "$c" = "editor" ]; then
		editor=true
	fi
done

echo '--> '
echo '--> Converte o XML de relatorios p/ XML Sync'
echo '--> '

xslFile=$HOME_GERADOR/src/main/java/v2/relatorio2Sync.xsl
xmlFile=$HOME_GERADOR/target/xmlListRelatorio.xml
outFile=$HOME_GERADOR/target/xmlListRelatorio_sync.xml
syncRelatorioPath=$HOME_GERADOR_URL/target/sync
xmlClasses=$HOME_GERADOR/target/classesAgroRevenda.xml

if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
	$JAVAEXEC -jar -Dline.separator=$'\n' $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile syncRelatorioPath=$syncRelatorioPath xmlClasses=$xmlClasses
else
	$JAVAEXEC -jar $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile syncRelatorioPath=$syncRelatorioPath xmlClasses=$xmlClasses
fi

if [ "$all" = true ] || [ "$editor" = true ]; then
	
	echo '--> '
	echo '--> Converte o XML de tela complexa para HTML, relatorio editor - relatorio2Editor.xsl'
	echo '--> '

	xslFile=$HOME_GERADOR/src/main/java/v2/relatorio2Editor.xsl
	xmlFile=$HOME_GERADOR/target/xmlListRelatorio.xml
	outFile=$HOME_GERADOR/target/htmlRelatorio.lst
	xmlClasses=$HOME_GERADOR/target/classesAgroRevenda.xml
	htmlSourcePath=$HOME_JNG_URL/app/tpls
	
	if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
		$JAVAEXEC -jar -Dline.separator=$'\n' $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile  htmlSourcePath=$htmlSourcePath xmlClasses=$xmlClasses sistemaOperacional="WINDOWS"
	else
		$JAVAEXEC -jar $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile  htmlSourcePath=$htmlSourcePath xmlClasses=$xmlClasses sistemaOperacional="WINDOWS"
	fi

	echo '--> '
	echo '--> Identando arquivos HTML Relatorio - Editor'
	echo '--> '

	listaArq=''
	for arquivo in `cat $HOME_GERADOR/target/htmlRelatorio.lst`;
	do
	   listaArq="$listaArq $arquivo"
	done
	js-beautify -q --type html -r -m 0 -f $listaArq

	echo '--> '
	echo '--> Converte o XML de tela complexa para HTML, relatorio viewer - relatorio2View.xsl'
	echo '--> '

	xslFile=$HOME_GERADOR/src/main/java/v2/relatorio2View.xsl
	xmlFile=$HOME_GERADOR/target/xmlListRelatorio.xml
	outFile=$HOME_GERADOR/target/htmlRelatorioViewer.lst
	xmlClasses=$HOME_GERADOR/target/classesAgroRevenda.xml
	htmlSourcePath=$HOME_JNG_URL/app/tpls

	if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
		$JAVAEXEC -jar -Dline.separator=$'\n' $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile  htmlSourcePath=$htmlSourcePath xmlClasses=$xmlClasses sistemaOperacional="WINDOWS"
	else
		$JAVAEXEC -jar $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile  htmlSourcePath=$htmlSourcePath xmlClasses=$xmlClasses sistemaOperacional="WINDOWS"
	fi

	echo '--> '
	echo '--> Identando arquivos HTML Relatorio - Viewer'
	echo '--> '

	listaArq=''
	for arquivo in `cat $HOME_GERADOR/target/htmlRelatorioViewer.lst`;
	do
	   listaArq="$listaArq $arquivo"
	done
	js-beautify -q --type html -r -m 0 -f $listaArq

	echo '--> '
	echo '--> Converte o XML de tela complexa para JS, relatorio controller - relatorio2Controller.xsl'
	echo '--> '

	xslFile=$HOME_GERADOR/src/main/java/v2/relatorio2Controller.xsl
	xmlFile=$HOME_GERADOR/target/xmlListRelatorio_sync.xml
	outFile=$HOME_GERADOR/target/ctrlRelatorio.lst
	ctrlSourcePath=$HOME_JNG_URL/app/ctrl
	xmlClasses=$HOME_GERADOR/target/classesAgroRevenda.xml
	
	if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
		$JAVAEXEC -jar -Dline.separator=$'\n' $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile ctrlSourcePath=$ctrlSourcePath xmlClasses=$xmlClasses sistemaOperacional="WINDOWS"
	else
		$JAVAEXEC -jar $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile ctrlSourcePath=$ctrlSourcePath xmlClasses=$xmlClasses sistemaOperacional="WINDOWS"
	fi

	echo '--> '
	echo '--> Identando arquivos JavaScripts'
	echo '--> '

	listaArq=''
	for arquivo in `cat $HOME_GERADOR/target/ctrlRelatorio.lst`;
	do
	   listaArq="$listaArq $arquivo"
	done
	js-beautify -q -f $listaArq -r
	

	echo '--> '
	echo '--> Converte o XML de relatorio para JavaScript Functions - telaComplexa2Functions.xsl'
	echo '--> '
	xslFile=$HOME_GERADOR/src/main/java/v2/telaComplexa2Functions.xsl
	xmlFile=$HOME_GERADOR/target/xmlListRelatorio_sync.xml
	outFile=$HOME_GERADOR/target/fnRelatorio.lst
	functionsSourcePath=$HOME_JNG_URL/app/functions
	xmlClasses=$HOME_GERADOR/target/classesAgroRevenda.xml

	if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
		$JAVAEXEC -jar -Dline.separator=$'\n' $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile functionsSourcePath=$functionsSourcePath xmlClasses=$xmlClasses sistemaOperacional="WINDOWS" ativarBlockUI=$ATIVAR_BLOCKUI
	else
		$JAVAEXEC -jar $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile functionsSourcePath=$functionsSourcePath xmlClasses=$xmlClasses sistemaOperacional="WINDOWS" ativarBlockUI=$ATIVAR_BLOCKUI
	fi
	if [ $? -ne 0 ]; then
	   exit 1
	fi
	echo '--> '
	echo '--> Identando arquivos JavaScripts'
	echo '--> '
	listaArq=''
	count=0
	for arquivo in `cat $HOME_GERADOR/target/fnRelatorio.lst`; do	
	   ((count++))
	   listaArq="$listaArq $arquivo"
	   if [ $count -eq 100 ]; then
			js-beautify -q -f $listaArq -r > /dev/null &
			listaArq=''
			count=0
	   fi
	done
	js-beautify -q -f $listaArq -r > /dev/null &

	echo '--> '
	echo '--> Converte o XML de relatorio para JavaScript Events - telaComplexa2Events.xsl'
	echo '--> '
	xslFile=$HOME_GERADOR/src/main/java/v2/telaComplexa2Events.xsl
	xmlFile=$HOME_GERADOR/target/xmlListRelatorio_sync.xml
	outFile=$HOME_GERADOR/target/evtRelatorio.lst
	eventsSourcePath=$HOME_JNG_URL/app/events
	xmlClasses=$HOME_GERADOR/target/classesAgroRevenda.xml

	if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
		$JAVAEXEC -jar -Dline.separator=$'\n' $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile eventsSourcePath=$eventsSourcePath xmlClasses=$xmlClasses sistemaOperacional="WINDOWS" ativarBlockUI=$ATIVAR_BLOCKUI
	else
		$JAVAEXEC -jar $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile eventsSourcePath=$eventsSourcePath xmlClasses=$xmlClasses sistemaOperacional="WINDOWS" ativarBlockUI=$ATIVAR_BLOCKUI
	fi
	if [ $? -ne 0 ]; then
	   exit 1
	fi
	echo '--> '
	echo '--> Identando arquivos JavaScripts'
	echo '--> '
	listaArq=''
	count=0
	for arquivo in `cat $HOME_GERADOR/target/evtRelatorio.lst`; do	
	   ((count++))
	   listaArq="$listaArq $arquivo"
	   if [ $count -eq 100 ]; then
			js-beautify -q -f $listaArq -r > /dev/null &
			listaArq=''
			count=0
	   fi
	done
	js-beautify -q -f $listaArq -r > /dev/null &

	echo '--> '
	echo '--> Converte o XML de relatorio para JavaScript Validators - telaComplexa2Validators.xsl'
	echo '--> '
	xslFile=$HOME_GERADOR/src/main/java/v2/telaComplexa2Validators.xsl
	xmlFile=$HOME_GERADOR/target/xmlListRelatorio_sync.xml
	outFile=$HOME_GERADOR/target/vltRelatorio.lst
	validatorsSourcePath=$HOME_JNG_URL/app/validators
	xmlClasses=$HOME_GERADOR/target/classesAgroRevenda.xml

	if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
		$JAVAEXEC -jar -Dline.separator=$'\n' $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile validatorsSourcePath=$validatorsSourcePath xmlClasses=$xmlClasses sistemaOperacional="WINDOWS" ativarBlockUI=$ATIVAR_BLOCKUI
	else
		$JAVAEXEC -jar $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile validatorsSourcePath=$validatorsSourcePath xmlClasses=$xmlClasses sistemaOperacional="WINDOWS" ativarBlockUI=$ATIVAR_BLOCKUI
	fi
	if [ $? -ne 0 ]; then
	   exit 1
	fi
	echo '--> '
	echo '--> Identando arquivos JavaScripts'
	echo '--> '
	listaArq=''
	count=0
	for arquivo in `cat $HOME_GERADOR/target/vltRelatorio.lst`; do	
	   ((count++))
	   listaArq="$listaArq $arquivo"
	   if [ $count -eq 100 ]; then
			js-beautify -q -f $listaArq -r > /dev/null &
			listaArq=''
			count=0
	   fi
	done
	js-beautify -q -f $listaArq -r > /dev/null &

	bash gera1.sh "--onlyStates"
fi

if [ "$all" = true ] || [ "$design" = true ]; then
	echo '--> '
	echo '--> Converte o XML de tela complexa para report design - relatorio2Design.xsl'
	echo '--> '

	xslFile=$HOME_GERADOR/src/main/java/v2/relatorio2Design.xsl
	xmlFile=$HOME_GERADOR/target/xmlListRelatorio.xml
	outFile=$HOME_GERADOR/target/designRelatorio.lst
	xmlClasses=$HOME_GERADOR/target/classesAgroRevenda.xml
	rptdesignSourcePath=$SVN_RPTDESIGN_URL

	if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
		$JAVAEXEC -jar -Dline.separator=$'\n' $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile  rptdesignSourcePath=$rptdesignSourcePath xmlClasses=$xmlClasses sistemaOperacional="WINDOWS"
	else
		$JAVAEXEC -jar $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile  rptdesignSourcePath=$rptdesignSourcePath xmlClasses=$xmlClasses sistemaOperacional="WINDOWS"
	fi

	echo '--> '
	echo '--> Converte o XML das funcoes de relatorios para JavaScript - relatorio2Javascript.xsl'
	echo '--> '

	xslFile=$HOME_GERADOR/src/main/java/v2/relatorio2Javascript.xsl
	xmlFile=$HOME_GERADOR/target/xmlListRelatorio_sync.xml
	outFile=$HOME_GERADOR/target/jsRelatorio.lst
	javascriptSourcePath=$SVN_RPTDESIGN_URL/rptscripts
	xmlClasses=$HOME_GERADOR/target/classesAgroRevenda.xml
	profileFile=C:/Apps/javascriptRelatorio.html

	if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
		$JAVAEXEC -jar -Dline.separator=$'\n' $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile javascriptSourcePath=$javascriptSourcePath xmlClasses=$xmlClasses sistemaOperacional="WINDOWS"
	else
		$JAVAEXEC -jar $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile javascriptSourcePath=$javascriptSourcePath xmlClasses=$xmlClasses sistemaOperacional="WINDOWS"
	fi

	echo '--> '
	echo '--> Identando arquivos JavaScripts'
	echo '--> '

	listaArq=''
	count=0
	for arquivo in `cat $HOME_GERADOR/target/jsRelatorio.lst`; do	
	   ((count++))
	   listaArq="$listaArq $arquivo"
	   if [ $count -eq 100 ]; then
			js-beautify -q -f $listaArq -r > /dev/null &
			listaArq=''
			count=0
	   fi
	done
	js-beautify -q -f $listaArq -r > /dev/null &
fi

if [ "$all" = true ] || [ "$design" = true ]; then
	bash syncRelatoriosWso2.sh
fi

if [ "$all" = true ] || [ "$editor" = true ]; then
	bash syncAgroRevendasWso2.sh
fi