#!/bin/bash
if [ -z $SISTEMAOPERACIONAL ]; then
   SISTEMAOPERACIONAL="LINUX"
   export SISTEMAOPERACIONAL
fi
if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
   if [[ "$HOME_GERADOR_URL" == "" ]]; then
      export HOME_GERADOR_URL="file:///"$HOME_GERADOR
   fi
else
   if [[ "$HOME_GERADOR_URL" == "" ]]; then
      export HOME_GERADOR_URL="file://"$HOME_GERADOR
   fi
fi
events=false
functions=false
validators=false
for c in $* 
do
	if [ "$c" = "--events" ] || [ "$c" = "-events" ] || [ "$c" = "events" ]; then
		events=true
	elif [ "$c" = "--functions" ] || [ "$c" = "-functions" ] || [ "$c" = "functions" ]; then
		functions=true
	elif [ "$c" = "--validators" ] || [ "$c" = "-validators" ] || [ "$c" = "validators" ]; then
		validators=true
	fi
done

echo '--> '
echo '--> Converte o XML de tela complexa e XML Sync'
echo '--> '

xslFile=$HOME_GERADOR/src/main/java/v2/telaComplexa2Sync.xsl
xmlFile=$HOME_GERADOR/target/xmlListTelaComplexa.xml
outFile=$HOME_GERADOR/target/xmlListTelaComplexa_sync.xml
syncTelaComplexaPath=$HOME_GERADOR_URL/target/sync
xmlClasses=$HOME_GERADOR/target/classesAgroRevenda.xml
xmlListTelaSimplesCustomizada=$HOME_GERADOR/target/xmlListTelaSimplesCustomizada.xml

if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
	$JAVAEXEC -jar -Dline.separator=$'\n' $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile syncTelaComplexaPath=$syncTelaComplexaPath xmlClasses=$xmlClasses xmlListTelaSimplesCustomizada=$xmlListTelaSimplesCustomizada
else
	$JAVAEXEC -jar $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile syncTelaComplexaPath=$syncTelaComplexaPath xmlClasses=$xmlClasses xmlListTelaSimplesCustomizada=$xmlListTelaSimplesCustomizada
fi

if [ "$events" = true ]; then
	echo '--> '
	echo '--> Converte o XML de telas para JavaScript Events - telaComplexa2Events.xsl'
	echo '--> '
	xslFile=$HOME_GERADOR/src/main/java/v2/telaComplexa2Events.xsl
	xmlFile=$HOME_GERADOR/target/xmlListTelaComplexa_sync.xml
	outFile=$HOME_GERADOR/target/evtTelaComplexa.lst
	eventsSourcePath=$HOME_JNG_URL/app/events
	xmlClasses=$HOME_GERADOR/target/classesAgroRevenda.xml

	if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
		$JAVAEXEC -jar -Dline.separator=$'\n' $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile eventsSourcePath=$eventsSourcePath xmlClasses=$xmlClasses sistemaOperacional="WINDOWS" ativarBlockUI=$ATIVAR_BLOCKUI
	else
		$JAVAEXEC -jar $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile eventsSourcePath=$eventsSourcePath xmlClasses=$xmlClasses sistemaOperacional="WINDOWS" ativarBlockUI=$ATIVAR_BLOCKUI
	fi
	if [ $? -ne 0 ]; then
	   exit 1
	fi
	echo '--> '
	echo '--> Identando arquivos JavaScripts'
	echo '--> '
	listaArq=''
	count=0
	for arquivo in `cat $HOME_GERADOR/target/evtTelaComplexa.lst`; do	
	   ((count++))
	   listaArq="$listaArq $arquivo"
	   if [ $count -eq 100 ]; then
			js-beautify -q -f $listaArq -r > /dev/null &
			listaArq=''
			count=0
	   fi
	done
	js-beautify -q -f $listaArq -r > /dev/null &
elif [ "$functions" = true ]; then
	echo '--> '
	echo '--> Converte o XML de telas para JavaScript Functions - telaComplexa2Functions.xsl'
	echo '--> '
	xslFile=$HOME_GERADOR/src/main/java/v2/telaComplexa2Functions.xsl
	xmlFile=$HOME_GERADOR/target/xmlListTelaComplexa_sync.xml
	outFile=$HOME_GERADOR/target/fnTelaComplexa.lst
	functionsSourcePath=$HOME_JNG_URL/app/functions
	xmlClasses=$HOME_GERADOR/target/classesAgroRevenda.xml

	if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
		$JAVAEXEC -jar -Dline.separator=$'\n' $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile functionsSourcePath=$functionsSourcePath xmlClasses=$xmlClasses sistemaOperacional="WINDOWS" ativarBlockUI=$ATIVAR_BLOCKUI
	else
		$JAVAEXEC -jar $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile functionsSourcePath=$functionsSourcePath xmlClasses=$xmlClasses sistemaOperacional="WINDOWS" ativarBlockUI=$ATIVAR_BLOCKUI
	fi
	if [ $? -ne 0 ]; then
	   exit 1
	fi
	echo '--> '
	echo '--> Identando arquivos JavaScripts'
	echo '--> '
	listaArq=''
	count=0
	for arquivo in `cat $HOME_GERADOR/target/fnTelaComplexa.lst`; do	
	   ((count++))
	   listaArq="$listaArq $arquivo"
	   if [ $count -eq 100 ]; then
			js-beautify -q -f $listaArq -r > /dev/null &
			listaArq=''
			count=0
	   fi
	done
	js-beautify -q -f $listaArq -r > /dev/null &
elif [ "$validators" = true ]; then
	echo '--> '
	echo '--> Converte o XML de telas para JavaScript Validators - telaComplexa2Validators.xsl'
	echo '--> '
	xslFile=$HOME_GERADOR/src/main/java/v2/telaComplexa2Validators.xsl
	xmlFile=$HOME_GERADOR/target/xmlListTelaComplexa_sync.xml
	outFile=$HOME_GERADOR/target/vltTelaComplexa.lst
	validatorsSourcePath=$HOME_JNG_URL/app/validators
	xmlClasses=$HOME_GERADOR/target/classesAgroRevenda.xml

	if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
		$JAVAEXEC -jar -Dline.separator=$'\n' $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile validatorsSourcePath=$validatorsSourcePath xmlClasses=$xmlClasses sistemaOperacional="WINDOWS" ativarBlockUI=$ATIVAR_BLOCKUI
	else
		$JAVAEXEC -jar $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile validatorsSourcePath=$validatorsSourcePath xmlClasses=$xmlClasses sistemaOperacional="WINDOWS" ativarBlockUI=$ATIVAR_BLOCKUI
	fi
	if [ $? -ne 0 ]; then
	   exit 1
	fi
	echo '--> '
	echo '--> Identando arquivos JavaScripts'
	echo '--> '
	listaArq=''
	count=0
	for arquivo in `cat $HOME_GERADOR/target/vltTelaComplexa.lst`; do	
	   ((count++))
	   listaArq="$listaArq $arquivo"
	   if [ $count -eq 100 ]; then
			js-beautify -q -f $listaArq -r > /dev/null &
			listaArq=''
			count=0
	   fi
	done
	js-beautify -q -f $listaArq -r > /dev/null &
fi
bash syncAgroRevendasWso2.sh