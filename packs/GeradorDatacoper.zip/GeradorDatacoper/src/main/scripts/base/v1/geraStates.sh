#!/bin/bash
STARTTIME=$(date +%s)
SISTEMAOPERACIONAL="${SISTEMAOPERACIONAL:=LINUX}"

echo '--> '
echo '--> Gera States do Sistema'
echo '--> '
fazUpdate=true
geraDicionario=true
if [ $# -ge 1 ]; then
   if [ !$1 ]; then
      geraDicionario=$1
   fi
   fazUpdate=false
   if [ $# -ge 2 ]; then
      fazUpdate=$2
   fi
fi

if [ ! $# -ge 1 ]; then
   echo '--> '
   echo '--> Configurando variaveis locais...'
   echo '--> '
fi
PASTASCRIPTS=$3
HOME_GERADOR=$4
HOME_MAPAS=$5
HOME_JNG=$6
HOME_JNG_URL=$7
HOME_XALAN=$8
HOME_SAXON=$9
HOME_TEMP=${10}
unity='ND'
if [ $# -ge 11 ]; then
   unity=${11}
fi
if [[ "$JAVAEXEC" == "" ]]; then 
   JAVAEXEC="java -Xms256m -Xmx2G "
fi

echo '--> '
echo "unity={$unity}"
echo "JAVAEXEC={$JAVAEXEC}"
echo '--> '

if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
   if [[ "$HOME_GERADOR_URL" == "" ]]; then
      export HOME_GERADOR_URL="file:///"$HOME_GERADOR
   fi
else
   if [[ "$HOME_GERADOR_URL" == "" ]]; then
      export HOME_GERADOR_URL="file://"$HOME_GERADOR
   fi
fi


if [ $geraDicionario = true ]; then
   $PASTASCRIPTS/geraDicionarioXML.sh $fazUpdate
   if [ $? -ne 0 ]; then
      exit 1
   fi
fi

echo '--> '
echo '--> Converte o mapa do menu para os States - menu2classesReferenciadas.xsl'
echo '--> '

stateSourcePath=$HOME_JNG_URL/app/states
xmlClasses=$HOME_GERADOR/target/classesAgroRevenda.xml
bigXmlClasses=$HOME_GERADOR/target/bigClassesAgroRevenda.xml
xmlSourcePath=$HOME_GERADOR_URL/target/
xmlGrafo=$HOME_GERADOR/target/classesAgroRevendaGrafo.xml
xslFile=$HOME_GERADOR/src/main/java/v2/menu2classesReferenciadas.xsl
xmlFile=$HOME_GERADOR/target/menuPrincipalSistema.xml
outFile=$HOME_GERADOR/target/classesReferenciadas.xml

echo '--> SAXON Home Edition v9.6.0.7 (Executando)'
if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
  $JAVAEXEC -jar -Dline.separator=$'\n' $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile stateSourcePath=$stateSourcePath bigXmlClasses=$bigXmlClasses xmlClasses=$xmlClasses xmlSourcePath=$xmlSourcePath xmlGrafo=$xmlGrafo
else
  $JAVAEXEC -jar $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile stateSourcePath=$stateSourcePath bigXmlClasses=$bigXmlClasses xmlClasses=$xmlClasses xmlSourcePath=$xmlSourcePath xmlGrafo=$xmlGrafo
fi

echo '--> '
echo '--> Converte o mapa do menu para os States - menuPrincipalSistemaMM2State.xsl'
echo '--> '

stateSourcePath=$HOME_JNG_URL/app/states
xmlClasses=$HOME_GERADOR/target/classesAgroRevenda.xml
xmlRefs=$HOME_GERADOR/target/classesReferenciadas.xml
xmlSourcePath=$HOME_GERADOR_URL/target/
xslFile=$HOME_GERADOR/src/main/java/v2/menuPrincipalSistemaMM2State.xsl
xmlFile=$HOME_GERADOR/target/menuPrincipalSistema.xml
outFile=$HOME_JNG/states.jag

echo '--> SAXON Home Edition v9.6.0.7 (Executando)'
if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
   $JAVAEXEC -jar -Dline.separator=$'\n' $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile stateSourcePath=$stateSourcePath xmlClasses=$xmlClasses xmlSourcePath=$xmlSourcePath xmlRefs=$xmlRefs
else
   $JAVAEXEC -jar $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile stateSourcePath=$stateSourcePath xmlClasses=$xmlClasses xmlSourcePath=$xmlSourcePath xmlRefs=$xmlRefs
fi
ENDTIME=$(date +%s)
echo '--> '
echo "--> geraStates.sh executou em $(($ENDTIME - $STARTTIME)) segundos."
echo '--> '
