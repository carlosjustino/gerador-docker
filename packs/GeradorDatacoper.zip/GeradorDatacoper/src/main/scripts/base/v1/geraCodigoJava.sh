#!/bin/bash
echo '--> '
echo '--> Gera codigo Java...'
echo '--> '
STARTTIME=$(date +%s)
SISTEMAOPERACIONAL="${SISTEMAOPERACIONAL:=LINUX}"
echo '--> '
echo '--> Gera Codigo Java'
echo '--> '

fazUpdate=true
geraDicionario=true
if [ $# -ge 1 ]; then
   if [ !$1 ]; then
      geraDicionario=$1
   fi
   fazUpdate=false
   if [ $# -ge 2 ]; then
      fazUpdate=$2
   fi
fi

HOME_MAPAS=$3
HOME_GERADOR=$4
HOME_DOMAIN=$5
HOME_REST_API=$6
HOME_XALAN=$7
HOME_SAXON=$8
HOME_JACOBE=$9
HOME_CARBON=${10}
HOME_TEMP=${11}
geraErros=${12}
PASTASCRIPTS=${13}
export classeAlvo='ND'
if [ $# -ge 14 ]; then
   classeAlvo=${14}
fi


echo "PASTASCRIPTS=$PASTASCRIPTS"
if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
   if [[ "$HOME_DOMAIN_URL" == "" ]]; then
      export HOME_DOMAIN_URL="file:///"$HOME_DOMAIN
   fi
   if [[ "$HOME_REST_API_URL" == "" ]]; then
      export HOME_REST_API_URL="file:///"$HOME_REST_API
   fi
   if [[ "$HOME_CARBON_URL" == "" ]]; then
      export HOME_CARBON_URL="file:///"$HOME_CARBON
   fi
else
   if [[ "$HOME_DOMAIN_URL" == "" ]]; then
      export HOME_DOMAIN_URL="file://"$HOME_DOMAIN
   fi
   if [[ "$HOME_REST_API_URL" == "" ]]; then
      export HOME_REST_API_URL="file://"$HOME_REST_API
   fi
   if [[ "$HOME_CARBON_URL" == "" ]]; then
      export HOME_CARBON_URL="file://"$HOME_CARBON
   fi
fi
if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
   CAMINHOJAVA=$JAVA_HOME/bin/javaw
else
   CAMINHOJAVA=$JAVA_HOME/bin/java
fi

if [[ "$JAVAEXEC" == "" ]]; then
   JAVAEXEC="java -Xms256m -Xmx2G "
fi

echo '--> '
echo 'HOME_MAPAS='$HOME_MAPAS
echo 'HOME_GERADOR='$HOME_GERADOR
echo 'HOME_DOMAIN='$HOME_DOMAIN
echo 'HOME_REST_API='$HOME_REST_API
echo 'HOME_XALAN='$HOME_XALAN
echo 'HOME_SAXON='$HOME_SAXON
echo 'HOME_JACOBE='$HOME_JACOBE
echo 'HOME_CARBON='$HOME_CARBON
echo 'HOME_TEMP='$HOME_TEMP
echo 'geraErros='$geraErros
echo 'PASTASCRIPTS='$PASTASCRIPTS
echo 'HOME_DOMAIN_URL='$HOME_DOMAIN_URL
echo 'HOME_REST_API_URL='$HOME_REST_API_URL
echo 'HOME_CARBON_URL='$HOME_CARBON_URL
echo 'JAVAEXEC='$JAVAEXEC
echo 'classeAlvo='$classeAlvo

export HOME_MAPAS HOME_GERADOR HOME_DOMAIN HOME_REST_API HOME_XALAN HOME_SAXON HOME_JACOBE HOME_CARBON HOME_TEMP geraErros PASTASCRIPTS JAVAEXEC HOME_DOMAIN_URL HOME_REST_API_URL HOME_CARBON_URL

if [ $geraDicionario = true ]; then
   $PASTASCRIPTS/geraDicionarioXML.sh $fazUpdate $HOME_MAPAS $HOME_GERADOR $HOME_XALAN $HOME_SAXON $geraErros $classeAlvo
   if [ $? -ne 0 ]; then
      exit 1
   fi
fi

#echo '--> ' > $HOME_TEMP/SaidaUtilitarios.txt
#echo '--> Gera Codigo Java UTILITARIOS' >> $HOME_TEMP/SaidaUtilitarios.txt
#echo '--> ' >> $HOME_TEMP/SaidaUtilitarios.txt
#echo `date`
#$PASTASCRIPTS/geraCodigoJavaUTILITARIOS.sh $HOME_GERADOR $HOME_DOMAIN_URL $HOME_XALAN $HOME_SAXON $HOME_JACOBE $HOME_TEMP $classeAlvo 1> $HOME_TEMP/SaidaUtilitarios.txt 2> $HOME_TEMP/SaidaErrosUtilitarios.txt &
#export UTILITARIOPID=$!
#echo "retorno = " $?
#if [ $? -ne 0 ]; then
#   exit 1
#fi

echo '--> '
echo '--> Gera Codigo Java UTILITARIOS'
echo '--> '
echo `date`
$PASTASCRIPTS/geraCodigoJavaUTILITARIOS.sh $HOME_GERADOR $HOME_DOMAIN_URL $HOME_XALAN $HOME_SAXON $HOME_JACOBE $HOME_TEMP $classeAlvo
echo "retorno = " $?
if [ $? -ne 0 ]; then
   exit 1
fi


#echo '--> ' > $HOME_TEMP/SaidaReferrer.txt
#echo '--> Gera Codigo Java Referrers' >> $HOME_TEMP/SaidaReferrer.txt
#echo '--> ' >> $HOME_TEMP/SaidaReferrer.txt
#echo `date`
#$PASTASCRIPTS/geraCodigoJavaREFERRER.sh $HOME_GERADOR $HOME_DOMAIN_URL $HOME_XALAN $HOME_SAXON $HOME_JACOBE $HOME_TEMP $classeAlvo 1> $HOME_TEMP/SaidaReferrer.txt 2> $HOME_TEMP/SaidaErrosReferrer.txt &
#export REFERRERPID=$!
#echo "retorno = " $?
#if [ $? -ne 0 ]; then
#   exit 1
#fi

echo '--> '
echo '--> Gera Codigo Java Referrers'
echo '--> '
echo `date`
$PASTASCRIPTS/geraCodigoJavaREFERRER.sh $HOME_GERADOR $HOME_DOMAIN_URL $HOME_XALAN $HOME_SAXON $HOME_JACOBE $HOME_TEMP $classeAlvo
echo "retorno = " $?
if [ $? -ne 0 ]; then
   exit 1
fi

echo '--> '
echo '--> Gera Codigo Java CONTAINER'
echo '--> '
$PASTASCRIPTS/geraCodigoJavaCONTAINER.sh $HOME_GERADOR $HOME_DOMAIN_URL $HOME_XALAN $HOME_SAXON $HOME_JACOBE $HOME_TEMP $classeAlvo
echo "retorno = " $?
if [ $? -ne 0 ]; then
   exit 1
fi

echo '--> '
echo '--> Gera Codigo Java QUERIES'
echo '--> '
$PASTASCRIPTS/geraCodigoJavaQUERIES.sh $HOME_GERADOR $HOME_DOMAIN_URL $HOME_SAXON $HOME_TEMP $classeAlvo
echo "retorno = " $?
if [ $? -ne 0 ]; then
   exit 1
fi


echo '--> '
echo '--> Gera Codigo Java DOMAIN'
echo '--> '
$PASTASCRIPTS/geraCodigoJavaDOMAIN.sh $HOME_GERADOR $HOME_DOMAIN_URL $HOME_XALAN $HOME_SAXON $HOME_JACOBE $HOME_TEMP $classeAlvo
echo "retorno = " $?
if [ $? -ne 0 ]; then
   exit 1
fi

#echo '--> '
#echo '--> Gera Codigo Java JPARS'
#echo '--> '
#$PASTASCRIPTS/geraCodigoJavaJPARS.sh $HOME_GERADOR $HOME_DOMAIN_URL $HOME_XALAN $HOME_SAXON $HOME_JACOBE $HOME_TEMP $classeAlvo
#echo "retorno = " $?
#if [ $? -ne 0 ]; then
#   exit 1
#fi

echo '--> '
echo '--> Gera Codigo Java CONSTRUTORES'
echo '--> '
$PASTASCRIPTS/geraCodigoJavaCONSTRUTORES.sh $HOME_GERADOR $HOME_DOMAIN_URL $HOME_XALAN $HOME_SAXON $HOME_JACOBE $HOME_TEMP $classeAlvo
echo "retorno = " $?
if [ $? -ne 0 ]; then
   exit 1
fi

echo '--> '
echo '--> Gera Codigo Java REST CONTAINER'
echo '--> '
$PASTASCRIPTS/geraCodigoJavaRESTContainer.sh $HOME_GERADOR $HOME_REST_API_URL $HOME_XALAN $HOME_SAXON $HOME_JACOBE $HOME_TEMP $classeAlvo
echo "retorno = " $?
if [ $? -ne 0 ]; then
   exit 1
fi

echo '--> '
echo '--> Gera Codigo Java REST DOMAIN'
echo '--> '
$PASTASCRIPTS/geraCodigoJavaREST.sh $HOME_GERADOR $HOME_REST_API_URL $HOME_XALAN $HOME_SAXON $HOME_JACOBE $HOME_TEMP $classeAlvo
echo "retorno = " $?
if [ $? -ne 0 ]; then
   exit 1
fi

echo '--> '
echo '--> Gera Codigo Java EVENTOS'
echo '--> '
$PASTASCRIPTS/geraCodigoJavaEVENTOS.sh $HOME_GERADOR $HOME_DOMAIN_URL $HOME_XALAN $HOME_SAXON $HOME_JACOBE $HOME_TEMP $classeAlvo
echo "retorno = " $?
if [ $? -ne 0 ]; then
   exit 1
fi


#while [ "ok"`ps ax | awk '{print $1}' | grep $UTILITARIOPID` == "ok${UTILITARIOPID}" ]
#do
#   echo 'Aguardando término do processo '$UTILITARIOPID' - UTILITARIOS'
#   sleep 2
#done
#
#
#while [ "ok"`ps ax | awk '{print $1}' | grep $REFERRERPID` == "ok${REFERRERPID}" ]
#do
#   echo 'Aguardando término do processo '$REFERRERPID' - REFERRER'
#   sleep 2
#done
#while [ "ok"`ps ax | awk '{print $1}' | grep $EVENTOSPID` == "ok${EVENTOSPID}" ]
#do
#   echo 'Aguardando término do processo '$EVENTOSPID' - EVENTOS'
#   sleep 2
#done

#
#echo '----------------------------------------'
#echo '--------- Saida Eventos ------'
#echo '----------------------------------------'
#cat $HOME_TEMP/SaidaEventos.txt
#echo '----------------------------------------'
#echo '--------- Saida Erros Eventos ------'
#echo '----------------------------------------'
#cat $HOME_TEMP/SaidaErrosEventos.txt
#echo '----------------------------------------'
#echo '--------- FIM Apresentacao EVENTOS -----'
#echo '----------------------------------------'
#echo '----------------------------------------'
#echo '--------- Saida Utilitarios ------'
#echo '----------------------------------------'
#cat $HOME_TEMP/SaidaUtilitarios.txt
#echo '----------------------------------------'
#echo '--------- Saida Erros Utilitarios ------'
#echo '----------------------------------------'
#cat $HOME_TEMP/SaidaErrosUtilitarios.txt
#echo '----------------------------------------'
#echo '--------- FIM Apresentacao UTILITARIOS -'
#echo '----------------------------------------'
#echo '----------------------------------------'
#echo '--------- Saida Referrer ------'
#echo '----------------------------------------'
#cat $HOME_TEMP/SaidaReferrer.txt
#echo '----------------------------------------'
#echo '--------- Saida Erros Referrer ------'
#echo '----------------------------------------'
#cat $HOME_TEMP/SaidaErrosReferrer.txt
#echo '----------------------------------------'
#echo '--------- FIM Apresentacao Referrer -'
#echo '----------------------------------------'
#while [ "ok"`ps a | awk '{print $1}' | grep $CONTAINERPID` == "ok${CONTAINERPID}" ]
#do
#   echo 'Aguardando temino do processo '$CONTAINERPID' - CONTAINERS'
#   sleep 2
#done
#
#while [ "ok"`ps a | awk '{print $1}' | grep $DOMAINPID` == "ok${DOMAINPID}" ]
#do
#   echo 'Aguardando temino do processo '$DOMAINPID' - DOMINIOS'
#   sleep 2
#done
#

#while [ "ok"`ps a | awk '{print $1}' | grep $CONSTRUTORPID` == "ok${CONSTRUTORPID}" ]
#do
#   echo 'Aguardando temino do processo '$CONSTRUTORPID' - CONSTRUTORES'
#   sleep 2
#done
#

#while [ "ok"`ps a | awk '{print $1}' | grep $RESTPID` == "ok${RESTPID}" ]
#do
#   echo 'Aguardando temino do processo '$RESTPID' - SERVICOS'
#   sleep 2
#done
#identa apenas as classes nas maquinas, no servidor nao precisa
if [[ $classeAlvo == "ND" ]]; then
   $PASTASCRIPTS/identaCodigoJava.sh
fi


ENDTIME=$(date +%s)
echo '--> '
echo "--> geraCodigoJava.sh executou em $(($ENDTIME - $STARTTIME)) segundos..."
echo '--> '
