#!/bin/bash
STARTTIME=$(date +%s)
#PASTASCRIPTS=/cygdrive/c/Carlosj/AgroRevendas/SVN/GeradorDatacoper/trunk/GeradorDatacoper/src/main/scripts/CarlosJ
SISTEMAOPERACIONAL="${SISTEMAOPERACIONAL:=LINUX}"
echo '--> '
echo '--> Configurando variaveis locais...'
echo '--> '
HOME_GERADOR=$1
HOME_REST_API_URL=$2
HOME_XALAN=$3
HOME_SAXON=$4
HOME_JACOBE=$5
HOME_TEMP=$6
export classeAlvo='ND'
if [ $# -ge 7 ]; then
   classeAlvo=$7
fi 

if [[ "$JAVAEXEC" == "" ]]; then 
   JAVAEXEC="java -Xms256m -Xmx2G "
fi

echo '--> '
echo '--> Converte o dicionario de classes para REST - dicionario2rest.xsl'
echo '--> '
#----------------------- REST ---------------------------------
javaSourcePath=$HOME_REST_API_URL/src/main/java
xslFile=$HOME_GERADOR/src/main/java/v2/dicionario2rest.xsl
xmlFile=$HOME_GERADOR/target/classesAgroRevenda.xml
outFile=$HOME_TEMP/restDomainSource.lst
if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
   #$JAVAEXEC -Dline.separator=$'\n' -cp "$HOME_XALAN/lib/*" org.apache.xalan.xslt.Process -XSL $xslFile -IN $xmlFile -OUT $outFile  -PARAM javaSourcePath $javaSourcePath
      echo `date`
   $JAVAEXEC -jar -Dline.separator=$'\n' $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile javaSourcePath=$javaSourcePath sistemaOperacional=$SISTEMAOPERACIONAL classeAlvo=$classeAlvo
else
   #$JAVAEXEC -cp "$HOME_XALAN/lib/*" org.apache.xalan.xslt.Process -XSL $xslFile -IN $xmlFile -OUT $outFile  -PARAM javaSourcePath $javaSourcePath
   $JAVAEXEC -jar $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile javaSourcePath=$javaSourcePath sistemaOperacional=$SISTEMAOPERACIONAL classeAlvo=$classeAlvo
fi

xslFile=$HOME_GERADOR/src/main/java/v2/atualizaDadosFixos.xsl
xmlFile=$HOME_GERADOR/target/classesAgroRevenda.xml
outFile=$HOME_TEMP/dadosFixosSource.lst
javaSourcePath=$HOME_DOMAIN_URL/src/main/java
echo '--> SAXON Home Edition v9.6.0.8 (Executando)'
if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
   #$JAVAEXEC -Dline.separator=$'\n' -cp "$HOME_XALAN/lib/*" org.apache.xalan.xslt.Process -XSL $xslFile -IN $xmlFile  -OUT $outFile
   $JAVAEXEC -jar -Dline.separator=$'\n' $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile javaSourcePath=$javaSourcePath
else
   #$JAVAEXEC -cp "$HOME_XALAN/lib/*" org.apache.xalan.xslt.Process -XSL $xslFile -IN $xmlFile  -OUT $outFile
   $JAVAEXEC -jar $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile javaSourcePath=$javaSourcePath
fi



ENDTIME=$(date +%s)
echo '--> '
echo "--> dicionario2rest.xsl executou em $(($ENDTIME - $STARTTIME)) segundos..."
echo '--> '
