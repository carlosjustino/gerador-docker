#!/bin/bash
STARTTIME=$(date +%s)

if [ ! -f "$HOME_GEN/target/classesAgroRevenda.xml" ]; then
   geraDicionario=true
fi

if [ ! -d "$HOME_TEMP" ]; then
   mkdir $HOME_TEMP
   chmod 777 $HOME_TEMP
fi

if [ $geraDicionario = true ]; then
   $MY_SCRIPTS/generate.sh --dictionary
   if [ $? -ne 0 ]; then
      exit 1
   fi
fi
echo '--------------------------------------------------------------------------------------'
echo 'ATIVAR_BLOCKUI='$ATIVAR_BLOCKUI
echo '--------------------------------------------------------------------------------------'

$PASTASCRIPTS/geraXmlTelas.sh false false $PASTASCRIPTS $HOME_GERADOR $HOME_MAPAS $HOME_JNG $HOME_JNG_URL $HOME_XALAN $HOME_SAXON $HOME_TEMP
if [ $? -ne 0 ]; then
   exit 1
fi

$PASTASCRIPTS/geraMenuSistema.sh false false $PASTASCRIPTS $HOME_GERADOR $HOME_MAPAS $HOME_JNG $HOME_JNG_URL $HOME_XALAN $HOME_SAXON $HOME_TEMP
if [ $? -ne 0 ]; then
   exit 1
fi

$PASTASCRIPTS/geraRoutesJNG.sh false false $PASTASCRIPTS $HOME_GERADOR $HOME_JNG $HOME_JNG_URL $HOME_XALAN $HOME_SAXON $HOME_TEMP
if [ $? -ne 0 ]; then
   exit 1
fi

$PASTASCRIPTS/geraNGFactory.sh false false $PASTASCRIPTS $HOME_GERADOR $HOME_MAPAS $HOME_JNG $HOME_JNG_URL $HOME_XALAN $HOME_SAXON $HOME_TEMP $ATIVAR_BLOCKUI
if [ $? -ne 0 ]; then
   exit 1
fi
## -- substituido pelo geraXmlTelas.sh
#$PASTASCRIPTS/geraTelasAgroRevendaSimples.sh false false $PASTASCRIPTS $HOME_GERADOR $HOME_MAPAS $HOME_JNG $HOME_JNG_URL $HOME_XALAN $HOME_SAXON $HOME_TEMP
#if [ $? -ne 0 ]; then
#   exit 1
#fi

$PASTASCRIPTS/geraStates.sh false false $PASTASCRIPTS $HOME_GERADOR $HOME_MAPAS $HOME_JNG $HOME_JNG_URL $HOME_XALAN $HOME_SAXON $HOME_TEMP
if [ $? -ne 0 ]; then
   exit 1
fi

$PASTASCRIPTS/geraTelasAgroRevendaRelatorios.sh false false $PASTASCRIPTS $HOME_GERADOR $HOME_MAPAS $HOME_JNG $HOME_JNG_URL $HOME_XALAN $HOME_SAXON $HOME_TEMP $ATIVAR_BLOCKUI
if [ $? -ne 0 ]; then
   exit 1
fi

$PASTASCRIPTS/geraTelasAgroRevendaComplexas.sh false false $PASTASCRIPTS $HOME_GERADOR $HOME_MAPAS $HOME_JNG $HOME_JNG_URL $HOME_XALAN $HOME_SAXON $HOME_TEMP $ATIVAR_BLOCKUI
if [ $? -ne 0 ]; then
   exit 1
fi

ENDTIME=$(date +%s)
echo '--> '
echo "--> geraTelasAgroRevenda.sh executou em $(($ENDTIME - $STARTTIME)) segundos."
echo '--> '
