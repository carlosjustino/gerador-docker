#!/bin/bash
echo '--> '
echo '--> Gera Page Objects...'
echo '--> '
STARTTIME=$(date +%s)
SISTEMAOPERACIONAL="${SISTEMAOPERACIONAL:=LINUX}"

if [ "$poALL" = true ] || [ "$poDICIONARIO" = true ]; then
	source geraDicionarioXML.sh false
	if [ $? -ne 0 ]; then
	  exit 1
	fi
    
	source geraXmlTelas.sh false false $PASTASCRIPTS $HOME_GERADOR $HOME_MAPAS $HOME_JNG $HOME_JNG_URL $HOME_XALAN $HOME_SAXON $HOME_TEMP
	if [ $? -ne 0 ]; then
	   exit 1
	fi

	echo '--> '
	echo '--> Converte o mapa de menu para o XML - mm2menuXml.xsl'
	echo '--> '
	classesXMLFile=$HOME_GERADOR/target/classesAgroRevenda.xml
	xmlTelaSourcePath=$HOME_GERADOR/target
	xslFile=$HOME_GERADOR/src/main/java/v2/mm2menuXml.xsl
	xmlFile=$HOME_MAPAS/MenuPrincipalSistema.mm
	outFile=$HOME_GERADOR/target/menuPrincipalSistema.xml
	if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
	   $JAVAEXEC -jar -Dline.separator=$'\n' $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile classesXMLFile=$classesXMLFile xmlTelaSourcePath=$xmlTelaSourcePath
	else
	   $JAVAEXEC -jar $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile classesXMLFile=$classesXMLFile xmlTelaSourcePath=$xmlTelaSourcePath
	fi

	echo '--> '
	echo '--> Gera XML de Rotinas - menuPrincipalSistema2XmlRotinas.xsl'
	echo '--> '

	xslFile=$HOME_GERADOR/src/main/java/v2/menuPrincipalSistema2XmlRotinas.xsl
	xmlFile=$HOME_GERADOR/target/menuPrincipalSistema.xml
	outFile=$HOME_GERADOR/target/xmlRotinas.xml

	if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
		$JAVAEXEC -jar -Djava.ext.dirs=$HOME_SAXON -Dline.separator=$'\n' $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile
	else
		$JAVAEXEC -jar -Djava.ext.dirs=$HOME_SAXON $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile
	fi
fi

if [ "$poALL" = true ] || [ "$poLISTAR" = true ]; then
	echo '--> '
	echo '--> Converte o XML de tela complexa para Classes JAVA ListarPageObjects - telaComplexa2ListarPageObjects.xsl'
	echo '--> '

	xslFile=$HOME_GERADOR/src/main/java/v2/telaComplexa2ListarPageObjects.xsl
	xmlFile=$HOME_GERADOR/target/xmlListTelaComplexa.xml
	outFile=$HOME_GERADOR/target/listarPageObjects.lst
	pageObjectsSourcePath=$HOME_PAGE_OBJECTS_URL
	xmlRotinas=$HOME_GERADOR/target/xmlRotinas.xml
	xmlClasses=$HOME_GERADOR/target/classesAgroRevenda.xml
	xmlListTelaSimplesCustomizada=$HOME_GERADOR/target/xmlListTelaSimplesCustomizada.xml

	if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
		$JAVAEXEC -jar -Dline.separator=$'\n' $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile pageObjectsSourcePath=$pageObjectsSourcePath xmlClasses=$xmlClasses xmlRotinas=$xmlRotinas xmlListTelaSimplesCustomizada=$xmlListTelaSimplesCustomizada sistemaOperacional="WINDOWS"
	else
		$JAVAEXEC -jar $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile pageObjectsSourcePath=$pageObjectsSourcePath xmlClasses=$xmlClasses xmlRotinas=$xmlRotinas xmlListTelaSimplesCustomizada=$xmlListTelaSimplesCustomizada sistemaOperacional="WINDOWS"
	fi
fi

if [ "$poALL" = true ] || [ "$poMANTER" = true ]; then
	echo '--> '
	echo '--> Converte o XML de tela complexa para Classes JAVA ManterPageObjects - telaComplexa2ManterPageObjects.xsl'
	echo '--> '

	xslFile=$HOME_GERADOR/src/main/java/v2/telaComplexa2ManterPageObjects.xsl
	xmlFile=$HOME_GERADOR/target/xmlListTelaComplexa.xml
	outFile=$HOME_GERADOR/target/manterPageObjects.lst
	pageObjectsSourcePath=$HOME_PAGE_OBJECTS_URL
	xmlRotinas=$HOME_GERADOR/target/xmlRotinas.xml
	xmlClasses=$HOME_GERADOR/target/classesAgroRevenda.xml
	xmlListTelaSimplesCustomizada=$HOME_GERADOR/target/xmlListTelaSimplesCustomizada.xml

	if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
		$JAVAEXEC -jar -Dline.separator=$'\n' $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile pageObjectsSourcePath=$pageObjectsSourcePath xmlClasses=$xmlClasses xmlRotinas=$xmlRotinas xmlListTelaSimplesCustomizada=$xmlListTelaSimplesCustomizada sistemaOperacional="WINDOWS"
	else
		$JAVAEXEC -jar $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile pageObjectsSourcePath=$pageObjectsSourcePath xmlClasses=$xmlClasses xmlRotinas=$xmlRotinas xmlListTelaSimplesCustomizada=$xmlListTelaSimplesCustomizada sistemaOperacional="WINDOWS"
	fi
fi

if [ "$poALL" = true ] || [ "$poVIEW" = true ]; then
	echo '--> '
	echo '--> Converte o XML de tela complexa para Classes JAVA ViewPageObjects - telaComplexa2ViewPageObjects.xsl'
	echo '--> '

	xslFile=$HOME_GERADOR/src/main/java/v2/telaComplexa2ViewPageObjects.xsl
	xmlFile=$HOME_GERADOR/target/xmlListTelaComplexa.xml
	outFile=$HOME_GERADOR/target/viewPageObjects.lst
	pageObjectsSourcePath=$HOME_PAGE_OBJECTS_URL
	xmlRotinas=$HOME_GERADOR/target/xmlRotinas.xml
	xmlClasses=$HOME_GERADOR/target/classesAgroRevenda.xml
	xmlListTelaSimplesCustomizada=$HOME_GERADOR/target/xmlListTelaSimplesCustomizada.xml

	if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
		$JAVAEXEC -jar -Dline.separator=$'\n' $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile pageObjectsSourcePath=$pageObjectsSourcePath xmlClasses=$xmlClasses xmlListTelaSimplesCustomizada=$xmlListTelaSimplesCustomizada xmlRotinas=$xmlRotinas sistemaOperacional="WINDOWS"
	else
		$JAVAEXEC -jar $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile pageObjectsSourcePath=$pageObjectsSourcePath xmlClasses=$xmlClasses xmlRotinas=$xmlRotinas xmlListTelaSimplesCustomizada=$xmlListTelaSimplesCustomizada sistemaOperacional="WINDOWS"
	fi
fi

ENDTIME=$(date +%s)
echo '--> '
echo "--> geraPageObjects.sh executou em $(($ENDTIME - $STARTTIME)) segundos..."
echo '--> '
