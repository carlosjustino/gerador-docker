#!/bin/bash
STARTTIME=$(date +%s)
PASTASCRIPTS=/cygdrive/c/Carlosj/AgroRevendas/SVN/GeradorDatacoper/trunk/GeradorDatacoper/src/main/scripts/CarlosJ
SISTEMAOPERACIONAL="${SISTEMAOPERACIONAL:=LINUX}"
echo '--> '
echo '--> Configurando variaveis locais...'
echo '--> '
HOME_GERADOR=$1
HOME_DOMAIN_URL=$2
HOME_XALAN=$3
HOME_SAXON=$4
HOME_JACOBE=$5
HOME_TEMP=$6
classeAlvo='ND'
profileFile='c:/Carlosj/AgroRevendas/SVN/GeradorDatacoper/trunk/GeradorDatacoper/target/profileUtilitarios.html'
if [ $# -ge 7 ]; then
   classeAlvo=$7
fi

if [[ "$JAVAEXEC" == "" ]]; then 
   JAVAEXEC="java -Xms256m -Xmx2G "
fi

if [[ "$IDENTA" == "" ]]; then
   IDENTA="SIM"
fi

echo '--> '
echo '--> Converte o dicionario para codigo java, UTILITARIOS - dicionario2utility.xsl'
echo '--> '
#----------------------- UTILITÁRIOS -------------------------------------------------
javaSourcePath=$HOME_DOMAIN_URL/src/main/java
xslFile=$HOME_GERADOR/src/main/java/v2/dicionario2utility.xsl
xmlFile=$HOME_GERADOR/target/classesAgroRevenda.xml
outFile=$HOME_TEMP/utilitySource.lst
if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
   #$JAVAEXEC -Dline.separator=$'\n' -cp "$HOME_XALAN/lib/*" org.apache.xalan.xslt.Process -XSL $xslFile -IN $xmlFile -OUT $outFile -PARAM javaSourcePath $javaSourcePath -PARAM resourceSourcePath $resourceSourcePath
   echo `date`
   $JAVAEXEC -jar -Dline.separator=$'\n' $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile javaSourcePath=$javaSourcePath sistemaOperacional=$SISTEMAOPERACIONAL classeAlvo=$classeAlvo
else
   #$JAVAEXEC -cp "$HOME_XALAN/lib/*" org.apache.xalan.xslt.Process -XSL $xslFile -IN $xmlFile -OUT $outFile -PARAM javaSourcePath $javaSourcePath -PARAM resourceSourcePath $resourceSourcePath
   $JAVAEXEC -jar $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile javaSourcePath=$javaSourcePath sistemaOperacional=$SISTEMAOPERACIONAL classeAlvo=$classeAlvo
fi

ENDTIME=$(date +%s)
echo '--> '
echo "--> dicionario2utility.xsl executou em $(($ENDTIME - $STARTTIME)) segundos..."
echo '--> '
