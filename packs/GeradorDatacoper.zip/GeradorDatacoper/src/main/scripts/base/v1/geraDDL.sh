#!/bin/bash

STARTTIME=$(date +%s)

SISTEMAOPERACIONAL="${SISTEMAOPERACIONAL:=LINUX}"
echo '--> '
echo '--> Configurando variaveis locais...'
echo '--> '
echo 'HOME_GERADOR='$1
echo 'HOME_SAXON='$2
echo '--> '
HOME_GERADOR=$1
HOME_SAXON=$2
JAVAEXEC=$3

if [[ $JAVAEXEC == "" ]]; then
   JAVAEXEC="java -Xms256m -Xmx1024m "
fi

echo '--> '
echo '--> Gera DDL XML'
echo '--> '
xslFile=$HOME_GERADOR/src/main/java/v2/dicionario2ddl.xsl
xmlFile=$HOME_GERADOR/target/classesAgroRevenda.xml
outFile=$HOME_GERADOR/target/ddlAgroRevenda.xml
if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
   #$JAVAEXEC -Dline.separator=$'\n' -cp "$HOME_XALAN/lib/*" org.apache.xalan.xslt.Process -XSL $xslFile -IN $xmlFile  -OUT $outFile
   $JAVAEXEC -jar -Dline.separator=$'\n' $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile 
else
   #$JAVAEXEC -cp "$HOME_XALAN/lib/*" org.apache.xalan.xslt.Process -XSL $xslFile -IN $xmlFile  -OUT $outFile
   $JAVAEXEC -jar $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile 
fi


ENDTIME=$(date +%s)
echo '--> '
echo "--> geraDDL.sh executou em $(($ENDTIME - $STARTTIME)) segundos."
echo '--> '
