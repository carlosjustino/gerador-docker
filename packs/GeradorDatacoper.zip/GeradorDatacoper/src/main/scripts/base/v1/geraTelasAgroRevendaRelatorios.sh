#!/bin/bash
STARTTIME=$(date +%s)
if [ -z $SISTEMAOPERACIONAL ]; then
   SISTEMAOPERACIONAL="LINUX"
   export SISTEMAOPERACIONAL
fi

echo '--> '
echo '--> Gera Relatorios'
echo '--> '
fazUpdate=true
geraDicionario=true
if [ $# -ge 1 ]; then
   if [ !$1 ]; then
      geraDicionario=$1
   fi
   fazUpdate=false
   if [ $# -ge 2 ]; then
      fazUpdate=$2
   fi
fi

if [ ! $# -ge 1 ]; then
   echo '--> '
   echo '--> Configurando variaveis locais...'
   echo '--> '
fi
PASTASCRIPTS=$3
HOME_GERADOR=$4
HOME_MAPAS=$5
HOME_JNG=$6
HOME_JNG_URL=$7
HOME_XALAN=$8
HOME_SAXON=$9
HOME_TEMP=${10}
ATIVAR_BLOCKUI=${11}
unity='ND'
if [ $# -ge 12 ]; then
   unity=${12}
fi

if [[ "$JAVAEXEC" == "" ]]; then 
   JAVAEXEC="java -Xms256m -Xmx2G "
fi

if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
   if [[ "$HOME_GERADOR_URL" == "" ]]; then
      export HOME_GERADOR_URL="file:///"$HOME_GERADOR
   fi
else
   if [[ "$HOME_GERADOR_URL" == "" ]]; then
      export HOME_GERADOR_URL="file://"$HOME_GERADOR
   fi
fi

if [ $geraDicionario = true ]; then
   $PASTASCRIPTS/geraDicionarioXML.sh $fazUpdate
   if [ $? -ne 0 ]; then
      exit 1
   fi
fi

echo '--> '
echo '--> Configurando variaveis locais...'
echo '--> unity='$unity
echo '--> ATIVAR_BLOCKUI='$ATIVAR_BLOCKUI
echo '--> '

echo '--> '
echo '--> Converte o XML de relatorios p/ XML Sync'
echo '--> '

xslFile=$HOME_GERADOR/src/main/java/v2/relatorio2Sync.xsl
xmlFile=$HOME_GERADOR/target/xmlListRelatorio.xml
outFile=$HOME_GERADOR/target/xmlListRelatorio_sync.xml
syncRelatorioPath=$HOME_GERADOR_URL/target/sync
xmlClasses=$HOME_GERADOR/target/classesAgroRevenda.xml

if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
   $JAVAEXEC -jar -Dline.separator=$'\n' $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile syncRelatorioPath=$syncRelatorioPath xmlClasses=$xmlClasses
else
   $JAVAEXEC -jar $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile syncRelatorioPath=$syncRelatorioPath xmlClasses=$xmlClasses
fi

STARTTIME4=$(date +%s)
echo '--> '
echo '--> Converte o XML de tela complexa para HTML, relatorio editor - relatorio2Editor.xsl'
echo '--> '

xslFile=$HOME_GERADOR/src/main/java/v2/relatorio2Editor.xsl
xmlFile=$HOME_GERADOR/target/xmlListRelatorio.xml
outFile=$HOME_GERADOR/target/htmlRelatorio.lst
xmlClasses=$HOME_GERADOR/target/classesAgroRevenda.xml
htmlSourcePath=$HOME_JNG_URL/app/tpls

if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
   $JAVAEXEC -jar -Dline.separator=$'\n' $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile  htmlSourcePath=$htmlSourcePath xmlClasses=$xmlClasses sistemaOperacional="WINDOWS"
else
   $JAVAEXEC -jar $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile  htmlSourcePath=$htmlSourcePath xmlClasses=$xmlClasses
fi

echo '--> '
echo '--> Identando arquivos HTML Relatorio - Editor'
echo '--> '
listaArq=''
count=0
for arquivo in `cat $HOME_GERADOR/target/htmlRelatorio.lst`; do	
   ((count++))
   listaArq="$listaArq $arquivo"
   if [ $count -eq 100 ]; then
		js-beautify -q --type html -r -m 0 -f $listaArq > /dev/null &
		listaArq=''
		count=0
   fi
done
js-beautify -q --type html -r -m 0 -f $listaArq > /dev/null &

ENDTIME4=$(date +%s)
echo '--> '
echo "--> relatorio2Editor.xsl executou em $(($ENDTIME4 - $STARTTIME4)) segundos..."
echo '--> '

STARTTIME5=$(date +%s)
echo '--> '
echo '--> Converte o XML de tela complexa para HTML, relatorio viewer - relatorio2View.xsl'
echo '--> '

xslFile=$HOME_GERADOR/src/main/java/v2/relatorio2View.xsl
xmlFile=$HOME_GERADOR/target/xmlListRelatorio.xml
outFile=$HOME_GERADOR/target/htmlRelatorioViewer.lst
xmlClasses=$HOME_GERADOR/target/classesAgroRevenda.xml
htmlSourcePath=$HOME_JNG_URL/app/tpls

if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
   $JAVAEXEC -jar -Dline.separator=$'\n' $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile  htmlSourcePath=$htmlSourcePath xmlClasses=$xmlClasses sistemaOperacional="WINDOWS"
else
   $JAVAEXEC -jar $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile  htmlSourcePath=$htmlSourcePath xmlClasses=$xmlClasses
fi

echo '--> '
echo '--> Identando arquivos HTML Relatorio - Viewer'
echo '--> '
listaArq=''
count=0
for arquivo in `cat $HOME_GERADOR/target/htmlRelatorioViewer.lst`; do	
   ((count++))
   listaArq="$listaArq $arquivo"
   if [ $count -eq 100 ]; then
		js-beautify -q --type html -r -m 0 -f $listaArq > /dev/null &
		listaArq=''
		count=0
   fi
done
js-beautify -q --type html -r -m 0 -f $listaArq > /dev/null &

ENDTIME5=$(date +%s)
echo '--> '
echo "--> relatorio2View.xsl executou em $(($ENDTIME5 - $STARTTIME5)) segundos..."
echo '--> '

STARTTIME6=$(date +%s)
echo '--> '
echo '--> Converte o XML de tela complexa e XML do dicionario para JavaScript, Ctrl Relatorio - relatorio2Controller.xsl'
echo '--> '

xslFile=$HOME_GERADOR/src/main/java/v2/relatorio2Controller.xsl
xmlFile=$HOME_GERADOR/target/xmlListRelatorio_sync.xml
outFile=$HOME_GERADOR/target/ctrlRelatorio.lst
ctrlSourcePath=$HOME_JNG_URL/app/ctrl
xmlClasses=$HOME_GERADOR/target/classesAgroRevenda.xml

if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
   $JAVAEXEC -jar -Dline.separator=$'\n' $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile ctrlSourcePath=$ctrlSourcePath xmlClasses=$xmlClasses sistemaOperacional="WINDOWS"
else
   $JAVAEXEC -jar $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile ctrlSourcePath=$ctrlSourcePath xmlClasses=$xmlClasses
fi

echo '--> '
echo '--> Identando arquivos JavaScripts'
echo '--> '
listaArq=''
count=0
for arquivo in `cat $HOME_GERADOR/target/ctrlRelatorio.lst`; do	
   ((count++))
   listaArq="$listaArq $arquivo"
   if [ $count -eq 100 ]; then
		js-beautify -q -f $listaArq -r > /dev/null &
		listaArq=''
		count=0
   fi
done
js-beautify -q -f $listaArq -r > /dev/null &

ENDTIME6=$(date +%s)
echo '--> '
echo "--> relatorio2Controller.xsl executou em $(($ENDTIME6 - $STARTTIME6)) segundos..."
echo '--> '

STARTTIME8=$(date +%s)
echo '--> '
echo '--> Converte o XML de relatorio para JavaScript Functions - telaComplexa2Functions.xsl'
echo '--> '
xslFile=$HOME_GERADOR/src/main/java/v2/telaComplexa2Functions.xsl
xmlFile=$HOME_GERADOR/target/xmlListRelatorio_sync.xml
outFile=$HOME_GERADOR/target/fnRelatorio.lst
functionsSourcePath=$HOME_JNG_URL/app/functions
xmlClasses=$HOME_GERADOR/target/classesAgroRevenda.xml

if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
	$JAVAEXEC -jar -Dline.separator=$'\n' $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile functionsSourcePath=$functionsSourcePath xmlClasses=$xmlClasses sistemaOperacional="WINDOWS" ativarBlockUI=$ATIVAR_BLOCKUI
else
    $JAVAEXEC -jar $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile functionsSourcePath=$functionsSourcePath xmlClasses=$xmlClasses ativarBlockUI=$ATIVAR_BLOCKUI
fi
if [ $? -ne 0 ]; then
   exit 1
fi
echo '--> '
echo '--> Identando arquivos JavaScripts'
echo '--> '
listaArq=''
count=0
for arquivo in `cat $HOME_GERADOR/target/fnRelatorio.lst`; do	
   ((count++))
   listaArq="$listaArq $arquivo"
   if [ $count -eq 100 ]; then
		js-beautify -q -f $listaArq -r > /dev/null &
		listaArq=''
		count=0
   fi
done
js-beautify -q -f $listaArq -r > /dev/null &

ENDTIME8=$(date +%s)
echo '--> '
echo "--> telaComplexa2Functions.xsl executou em $(($ENDTIME8 - $STARTTIME8)) segundos..."
echo '--> '

STARTTIME9=$(date +%s)
echo '--> '
echo '--> Converte o XML de relatorio para JavaScript Events - telaComplexa2Events.xsl'
echo '--> '
xslFile=$HOME_GERADOR/src/main/java/v2/telaComplexa2Events.xsl
xmlFile=$HOME_GERADOR/target/xmlListRelatorio_sync.xml
outFile=$HOME_GERADOR/target/evtRelatorio.lst
eventsSourcePath=$HOME_JNG_URL/app/events
xmlClasses=$HOME_GERADOR/target/classesAgroRevenda.xml

if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
	$JAVAEXEC -jar -Dline.separator=$'\n' $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile eventsSourcePath=$eventsSourcePath xmlClasses=$xmlClasses sistemaOperacional="WINDOWS" ativarBlockUI=$ATIVAR_BLOCKUI
else
    $JAVAEXEC -jar $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile eventsSourcePath=$eventsSourcePath xmlClasses=$xmlClasses ativarBlockUI=$ATIVAR_BLOCKUI
fi
if [ $? -ne 0 ]; then
   exit 1
fi
echo '--> '
echo '--> Identando arquivos JavaScripts'
echo '--> '
listaArq=''
count=0
for arquivo in `cat $HOME_GERADOR/target/evtRelatorio.lst`; do	
   ((count++))
   listaArq="$listaArq $arquivo"
   if [ $count -eq 100 ]; then
		js-beautify -q -f $listaArq -r > /dev/null &
		listaArq=''
		count=0
   fi
done
js-beautify -q -f $listaArq -r > /dev/null &

ENDTIME9=$(date +%s)
echo '--> '
echo "--> telaComplexa2Events.xsl executou em $(($ENDTIME9 - $STARTTIME9)) segundos..."
echo '--> '

STARTTIME10=$(date +%s)
echo '--> '
echo '--> Converte o XML de relatorio para JavaScript Validators - telaComplexa2Validators.xsl'
echo '--> '
xslFile=$HOME_GERADOR/src/main/java/v2/telaComplexa2Validators.xsl
xmlFile=$HOME_GERADOR/target/xmlListRelatorio_sync.xml
outFile=$HOME_GERADOR/target/vltRelatorio.lst
validatorsSourcePath=$HOME_JNG_URL/app/validators
xmlClasses=$HOME_GERADOR/target/classesAgroRevenda.xml

if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
	$JAVAEXEC -jar -Dline.separator=$'\n' $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile validatorsSourcePath=$validatorsSourcePath xmlClasses=$xmlClasses sistemaOperacional="WINDOWS" ativarBlockUI=$ATIVAR_BLOCKUI
else
    $JAVAEXEC -jar $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile validatorsSourcePath=$validatorsSourcePath xmlClasses=$xmlClasses ativarBlockUI=$ATIVAR_BLOCKUI
fi
if [ $? -ne 0 ]; then
   exit 1
fi
echo '--> '
echo '--> Identando arquivos JavaScripts'
echo '--> '
listaArq=''
count=0
for arquivo in `cat $HOME_GERADOR/target/vltRelatorio.lst`; do	
   ((count++))
   listaArq="$listaArq $arquivo"
   if [ $count -eq 100 ]; then
		js-beautify -q -f $listaArq -r > /dev/null &
		listaArq=''
		count=0
   fi
done
js-beautify -q -f $listaArq -r > /dev/null &

ENDTIME10=$(date +%s)
echo '--> '
echo "--> telaComplexa2Validators.xsl executou em $(($ENDTIME10 - $STARTTIME10)) segundos..."
echo '--> '

STARTTIME7=$(date +%s)
echo '--> '
echo '--> Converte o XML de tela complexa para report design - relatorio2Design.xsl'
echo '--> '

xslFile=$HOME_GERADOR/src/main/java/v2/relatorio2Design.xsl
xmlFile=$HOME_GERADOR/target/xmlListRelatorio.xml
outFile=$HOME_GERADOR/target/designRelatorio.lst
xmlClasses=$HOME_GERADOR/target/classesAgroRevenda.xml
rptdesignSourcePath=$SVN_RPTDESIGN_URL

if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
	$JAVAEXEC -jar -Dline.separator=$'\n' $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile  rptdesignSourcePath=$rptdesignSourcePath xmlClasses=$xmlClasses sistemaOperacional="WINDOWS"
else
	$JAVAEXEC -jar $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile  rptdesignSourcePath=$rptdesignSourcePath xmlClasses=$xmlClasses
fi

ENDTIME7=$(date +%s)
echo '--> '
echo "--> relatorio2Design.xsl executou em $(($ENDTIME7 - $STARTTIME7)) segundos..."
echo '--> '

STARTTIME11=$(date +%s)

echo '--> '
echo '--> Converte o XML das funcoes de relatorios para JavaScript - relatorio2Javascript.xsl'
echo '--> '

xslFile=$HOME_GERADOR/src/main/java/v2/relatorio2Javascript.xsl
xmlFile=$HOME_GERADOR/target/xmlListRelatorio_sync.xml
outFile=$HOME_GERADOR/target/jsRelatorio.lst
javascriptSourcePath=$SVN_RPTDESIGN_URL/rptscripts
xmlClasses=$HOME_GERADOR/target/classesAgroRevenda.xml
profileFile=C:/Apps/javascriptRelatorio.html

if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
	$JAVAEXEC -jar -Dline.separator=$'\n' $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile javascriptSourcePath=$javascriptSourcePath xmlClasses=$xmlClasses sistemaOperacional="WINDOWS"
else
	$JAVAEXEC -jar $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile javascriptSourcePath=$javascriptSourcePath xmlClasses=$xmlClasses
fi

echo '--> '
echo '--> Identando arquivos JavaScripts'
echo '--> '

listaArq=''
count=0
for arquivo in `cat $HOME_GERADOR/target/jsRelatorio.lst`; do	
   ((count++))
   listaArq="$listaArq $arquivo"
   if [ $count -eq 100 ]; then
		js-beautify -q -f $listaArq -r > /dev/null &
		listaArq=''
		count=0
   fi
done
js-beautify -q -f $listaArq -r > /dev/null &

ENDTIME11=$(date +%s)
echo '--> '
echo "--> relatorio2Javascript.xsl executou em $(($ENDTIME11 - $STARTTIME11)) segundos..."
echo '--> '

ENDTIME=$(date +%s)
echo '--> '
echo "--> geraTelasAgroRevendaRelatorios.sh executou em $(($ENDTIME - $STARTTIME)) segundos."
echo '--> '
