#!/bin/bash
STARTTIME=$(date +%s)
#PASTASCRIPTS=/cygdrive/c/Carlosj/AgroRevendas/SVN/GeradorDatacoper/trunk/GeradorDatacoper/src/main/scripts/CarlosJ
SISTEMAOPERACIONAL="${SISTEMAOPERACIONAL:=LINUX}"

HOME_GERADOR=$1
HOME_DOMAIN_URL=$2
HOME_SAXON=$3
HOME_TEMP=$4
export classeAlvo='ND'
if [ $# -ge 5 ]; then
   classeAlvo=$5
fi 

if [[ "$JAVAEXEC" == "" ]]; then 
   JAVAEXEC="java -Xms256m -Xmx2G "
fi

echo '--> '
echo '--> Converte o dicionario de classes para QUERIES - dicionario2consultasDinamicas.xsl'
echo '--> '
##----------------------- Queries -------------------------------------------------
javaSourcePath=$HOME_DOMAIN_URL/src/main/java
xslFile=$HOME_GERADOR/src/main/java/v2/dicionario2consultasDinamicas.xsl
xmlFile=$HOME_GERADOR/target/classesAgroRevenda.xml
outFile=$HOME_TEMP/queriesSource.lst
echo '--> SAXON Home Edition (Executando)'
if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
   echo `date`
   $JAVAEXEC -jar -Dline.separator=$'\n' $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile javaSourcePath=$javaSourcePath sistemaOperacional=$SISTEMAOPERACIONAL classeAlvo=$classeAlvo
else
   $JAVAEXEC -jar $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile javaSourcePath=$javaSourcePath sistemaOperacional=$SISTEMAOPERACIONAL classeAlvo=$classeAlvo
fi

ENDTIME=$(date +%s)
echo '--> '
echo "--> dicionario2consultasDinamicas.xsl executou em $(($ENDTIME - $STARTTIME)) segundos..."
echo '--> '
