#!/bin/bash

STARTTIME=$(date +%s)

#PASTASCRIPTS=/cygdrive/c/Carlosj/AgroRevendas/SVN/GeradorDatacoper/trunk/GeradorDatacoper/src/main/scripts/CarlosJ
SISTEMAOPERACIONAL="${SISTEMAOPERACIONAL:=LINUX}"
echo '--> '
echo '--> Configurando variaveis locais...'
echo '--> '
KETTLE_DIR=$1
HOME_GERADOR=$2

echo '--> '
echo '--> executa transformacao ReconstroiControleSequencia'
echo '--> '
$KETTLE_DIR/pan.bat -file $HOME_GERADOR/target/ReconstroiControleSequencia.ktr

ENDTIME=$(date +%s)
echo '--> '
echo "--> ReconstroiControleSequencia executou em $(($ENDTIME - $STARTTIME)) segundos..."
echo '--> '
