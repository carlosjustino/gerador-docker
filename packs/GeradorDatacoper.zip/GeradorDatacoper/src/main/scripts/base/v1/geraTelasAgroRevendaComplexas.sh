#!/bin/bash
STARTTIME=$(date +%s)
if [ -z $SISTEMAOPERACIONAL ]; then
   SISTEMAOPERACIONAL="LINUX"
   export SISTEMAOPERACIONAL
fi

echo '--> '
echo '--> Gera Telas Complexas'
echo '--> '
fazUpdate=true
geraDicionario=true
if [ $# -ge 1 ]; then
   if [ !$1 ]; then
      geraDicionario=$1
   fi
   fazUpdate=false
   if [ $# -ge 2 ]; then
      fazUpdate=$2
   fi
fi

if [ ! $# -ge 1 ]; then
   echo '--> '
   echo '--> Configurando variaveis locais...'
   echo '--> '
fi
PASTASCRIPTS=$3
HOME_GERADOR=$4
HOME_MAPAS=$5
HOME_JNG=$6
HOME_JNG_URL=$7
HOME_XALAN=$8
HOME_SAXON=$9
HOME_TEMP=${10}
ATIVAR_BLOCKUI=${11}
unity='ND'
if [ $# -ge 12 ]; then
   unity=${12}
fi

if [[ "$JAVAEXEC" == "" ]]; then 
   JAVAEXEC="java -Xms256m -Xmx2G "
fi

if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
   if [[ "$HOME_GERADOR_URL" == "" ]]; then
      export HOME_GERADOR_URL="file:///"$HOME_GERADOR
   fi
else
   if [[ "$HOME_GERADOR_URL" == "" ]]; then
      export HOME_GERADOR_URL="file://"$HOME_GERADOR
   fi
fi

if [ $geraDicionario = true ]; then
   $PASTASCRIPTS/geraDicionarioXML.sh $fazUpdate
   if [ $? -ne 0 ]; then
      exit 1
   fi
fi

echo '--> '
echo '--> Configurando variaveis locais...'
echo '--> unity='$unity
echo '--> ATIVAR_BLOCKUI='$ATIVAR_BLOCKUI
echo '--> '

STARTTIME3=$(date +%s)
echo '--> '
echo '--> Converte o XML de tela complexa para HTML, tela complexa List - telaComplexa2List.xsl'
echo '--> '
#---------------------- converte o XML para Html Tela Complexa  List------------------------------------
xslFile=$HOME_GERADOR/src/main/java/v2/telaComplexa2List.xsl
xmlFile=$HOME_GERADOR/target/xmlListTelaComplexa.xml
outFile=$HOME_GERADOR/target/htmlTelaComplexaList.lst
xmlClasses=$HOME_GERADOR/target/classesAgroRevenda.xml
xmlListTelaSimplesCustomizada=$HOME_GERADOR/target/xmlListTelaSimplesCustomizada.xml
htmlTelaComplexaSourcePath=$HOME_JNG_URL/app/tpls
echo '--> SAXON Home Edition v9.6.0.7 (Executando)'
if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
   #$JAVAEXEC -Dline.separator=$'\n' -cp "$HOME_XALAN/lib/*" org.apache.xalan.xslt.Process -XSL $xslFile -IN $xmlFile -OUT $outFile -PARAM htmlTelaComplexaSourcePath $htmlTelaComplexaSourcePath -PARAM xmlClasses $xmlClasses -PARAM mapasSourcePath $mapasSourcePath -PARAM xmlTelaComplexaSourcePath $xmlTelaComplexaSourcePath
   $JAVAEXEC -jar -Dline.separator=$'\n' $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile htmlTelaComplexaSourcePath=$htmlTelaComplexaSourcePath xmlClasses=$xmlClasses xmlListTelaSimplesCustomizada=$xmlListTelaSimplesCustomizada sistemaOperacional=$SISTEMAOPERACIONAL
else
   #$JAVAEXEC -cp "$HOME_XALAN/lib/*" org.apache.xalan.xslt.Process -XSL $xslFile -IN $xmlFile -OUT $outFile -PARAM htmlTelaComplexaSourcePath $htmlTelaComplexaSourcePath -PARAM xmlClasses $xmlClasses -PARAM mapasSourcePath $mapasSourcePath -PARAM xmlTelaComplexaSourcePath $xmlTelaComplexaSourcePath
   $JAVAEXEC -jar $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile htmlTelaComplexaSourcePath=$htmlTelaComplexaSourcePath xmlClasses=$xmlClasses xmlListTelaSimplesCustomizada=$xmlListTelaSimplesCustomizada sistemaOperacional=$SISTEMAOPERACIONAL
fi
if [ $? -ne 0 ]; then
   exit 1
fi
echo '--> '
echo '--> Identando arquivos HTML Tela Complexa - List'
echo '--> '
listaArq=''
count=0
for arquivo in `cat $HOME_GERADOR/target/htmlTelaComplexaList.lst`; do	
   ((count++))
   listaArq="$listaArq $arquivo"
   if [ $count -eq 100 ]; then
		js-beautify -q --type html -r -m 0 -f $listaArq > /dev/null &
		listaArq=''
		count=0
   fi
done
js-beautify -q --type html -r -m 0 -f $listaArq > /dev/null &

ENDTIME3=$(date +%s)
echo '--> '
echo "--> telaComplexa2List.xsl executou em $(($ENDTIME3 - $STARTTIME3)) segundos..."
echo '--> '

STARTTIME4=$(date +%s)
echo '--> '
echo '--> Converte o XML de tela complexa para HTML, tela complexa Editor - telaComplexa2Editor.xsl'
echo '--> '
#---------------------- converte o XML para Html Tela Complexa  Editor------------------------------------
xslFile=$HOME_GERADOR/src/main/java/v2/telaComplexa2Editor.xsl
xmlFile=$HOME_GERADOR/target/xmlListTelaComplexa.xml
outFile=$HOME_GERADOR/target/htmlTelaComplexaEditor.lst
xmlClasses=$HOME_GERADOR/target/classesAgroRevenda.xml
xmlListTelaSimplesCustomizada=$HOME_GERADOR/target/xmlListTelaSimplesCustomizada.xml
htmlTelaComplexaSourcePath=$HOME_JNG_URL/app/tpls
echo '--> SAXON Home Edition v9.6.0.7 (Executando)'
if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
   #$JAVAEXEC -Dline.separator=$'\n' -cp "$HOME_XALAN/lib/*" org.apache.xalan.xslt.Process -XSL $xslFile -IN $xmlFile -OUT $outFile -PARAM htmlTelaComplexaSourcePath $htmlTelaComplexaSourcePath -PARAM xmlClasses $xmlClasses -PARAM mapasSourcePath $mapasSourcePath -PARAM xmlTelaComplexaSourcePath $xmlTelaComplexaSourcePath
   $JAVAEXEC -jar -Dline.separator=$'\n' $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile  htmlTelaComplexaSourcePath=$htmlTelaComplexaSourcePath xmlClasses=$xmlClasses xmlListTelaSimplesCustomizada=$xmlListTelaSimplesCustomizada sistemaOperacional=$SISTEMAOPERACIONAL
else
   #$JAVAEXEC -cp "$HOME_XALAN/lib/*" org.apache.xalan.xslt.Process -XSL $xslFile -IN $xmlFile -OUT $outFile -PARAM htmlTelaComplexaSourcePath $htmlTelaComplexaSourcePath -PARAM xmlClasses $xmlClasses -PARAM mapasSourcePath $mapasSourcePath -PARAM xmlTelaComplexaSourcePath $xmlTelaComplexaSourcePath
   $JAVAEXEC -jar $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile  htmlTelaComplexaSourcePath=$htmlTelaComplexaSourcePath xmlClasses=$xmlClasses xmlListTelaSimplesCustomizada=$xmlListTelaSimplesCustomizada sistemaOperacional=$SISTEMAOPERACIONAL
fi
if [ $? -ne 0 ]; then
   exit 1
fi
echo '--> '
echo '--> Identando arquivos HTML Tela Complexa - Editor'
echo '--> '
listaArq=''
count=0
for arquivo in `cat $HOME_GERADOR/target/htmlTelaComplexaEditor.lst`; do	
   ((count++))
   listaArq="$listaArq $arquivo"
   if [ $count -eq 100 ]; then
		js-beautify -q --type html -r -m 0 -f $listaArq > /dev/null &
		listaArq=''
		count=0
   fi
done
js-beautify -q --type html -r -m 0 -f $listaArq > /dev/null &

ENDTIME4=$(date +%s)
echo '--> '
echo "--> telaComplexa2Editor.xsl executou em $(($ENDTIME4 - $STARTTIME4)) segundos..."
echo '--> '

STARTTIME5=$(date +%s)
echo '--> '
echo '--> Converte o XML de tela complexa para HTML, tela complexa View - telaComplexa2View.xsl'
echo '--> '
#---------------------- converte o XML para Html Tela Complexa  View------------------------------------
xslFile=$HOME_GERADOR/src/main/java/v2/telaComplexa2View.xsl
xmlFile=$HOME_GERADOR/target/xmlListTelaComplexa.xml
outFile=$HOME_GERADOR/target/htmlTelaComplexaView.lst
xmlListTelaSimplesCustomizada=$HOME_GERADOR/target/xmlListTelaSimplesCustomizada.xml
xmlClasses=$HOME_GERADOR/target/classesAgroRevenda.xml
htmlTelaComplexaSourcePath=$HOME_JNG_URL/app/tpls
echo '--> SAXON Home Edition v9.6.0.7 (Executando)'
if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
   #$JAVAEXEC -Dline.separator=$'\n' -cp "$HOME_XALAN/lib/*" org.apache.xalan.xslt.Process -XSL $xslFile -IN $xmlFile -OUT $outFile -PARAM htmlTelaComplexaSourcePath $htmlTelaComplexaSourcePath -PARAM xmlClasses $xmlClasses -PARAM mapasSourcePath $mapasSourcePath -PARAM xmlTelaComplexaSourcePath $xmlTelaComplexaSourcePath
   $JAVAEXEC -jar -Dline.separator=$'\n' $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile htmlTelaComplexaSourcePath=$htmlTelaComplexaSourcePath xmlClasses=$xmlClasses xmlListTelaSimplesCustomizada=$xmlListTelaSimplesCustomizada sistemaOperacional=$SISTEMAOPERACIONAL
else
   #$JAVAEXEC -cp "$HOME_XALAN/lib/*" org.apache.xalan.xslt.Process -XSL $xslFile -IN $xmlFile -OUT $outFile -PARAM htmlTelaComplexaSourcePath $htmlTelaComplexaSourcePath -PARAM xmlClasses $xmlClasses -PARAM mapasSourcePath $mapasSourcePath -PARAM xmlTelaComplexaSourcePath $xmlTelaComplexaSourcePath
   $JAVAEXEC -jar $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile htmlTelaComplexaSourcePath=$htmlTelaComplexaSourcePath xmlClasses=$xmlClasses xmlListTelaSimplesCustomizada=$xmlListTelaSimplesCustomizada sistemaOperacional=$SISTEMAOPERACIONAL
fi
if [ $? -ne 0 ]; then
   exit 1
fi
echo '--> '
echo '--> Identando arquivos HTML Tela Complexa - View'
echo '--> '
listaArq=''
count=0
for arquivo in `cat $HOME_GERADOR/target/htmlTelaComplexaView.lst`; do	
   ((count++))
   listaArq="$listaArq $arquivo"
   if [ $count -eq 100 ]; then
		js-beautify -q --type html -r -m 0 -f $listaArq > /dev/null &
		listaArq=''
		count=0
   fi
done
js-beautify -q --type html -r -m 0 -f $listaArq > /dev/null &

ENDTIME5=$(date +%s)
echo '--> '
echo "--> telaComplexa2View.xsl executou em $(($ENDTIME5 - $STARTTIME5)) segundos..."
echo '--> '

STARTTIME7=$(date +%s)

echo '--> '
echo '--> Converte o XML de tela complexa e XML Sync'
echo '--> '
#---------------------- converte o XML Telas para XML Sync------------------------------------
xslFile=$HOME_GERADOR/src/main/java/v2/telaComplexa2Sync.xsl
xmlFile=$HOME_GERADOR/target/xmlListTelaComplexa.xml
outFile=$HOME_GERADOR/target/xmlListTelaComplexa_sync.xml
syncTelaComplexaPath=$HOME_GERADOR_URL/target/sync
xmlClasses=$HOME_GERADOR/target/classesAgroRevenda.xml
xmlListTelaSimplesCustomizada=$HOME_GERADOR/target/xmlListTelaSimplesCustomizada.xml

$JAVAEXEC -jar -Dline.separator=$'\n' $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile syncTelaComplexaPath=$syncTelaComplexaPath xmlClasses=$xmlClasses xmlListTelaSimplesCustomizada=$xmlListTelaSimplesCustomizada

echo '--> '
echo '--> Identando arquivos JavaScripts'
echo '--> '

ENDTIME7=$(date +%s)
echo '--> '
echo "--> telaComplexa2Sync.xsl executou em $(($ENDTIME7 - $STARTTIME7)) segundos..."
echo '--> '

STARTTIME6=$(date +%s)
echo '--> '
echo '--> Converte o XML de tela complexa e XML do dicionario para JavaScript, Ctrl Tela Complexa - telaComplexa2Controller.xsl'
echo '--> '
#---------------------- converte o XML para Ctrl Tela Complexa ------------------------------------
xslFile=$HOME_GERADOR/src/main/java/v2/telaComplexa2Controller.xsl
xmlFile=$HOME_GERADOR/target/xmlListTelaComplexa_sync.xml
outFile=$HOME_GERADOR/target/ctrlTelaComplexa.lst
ctrlTelaComplexaSourcePath=$HOME_JNG_URL/app/ctrl
xmlClasses=$HOME_GERADOR/target/classesAgroRevenda.xml
echo '--> SAXON Home Edition v9.6.0.7 (Executando)'
if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
   #$JAVAEXEC -Dline.separator=$'\n' -cp "$HOME_XALAN/lib/*" org.apache.xalan.xslt.Process -XSL $xslFile -IN $xmlFile -OUT $outFile -PARAM ctrlTelaComplexaSourcePath $ctrlTelaComplexaSourcePath -PARAM xmlClasses $xmlClasses -PARAM mapasSourcePath $mapasSourcePath -PARAM xmlTelaComplexaSourcePath $xmlTelaComplexaSourcePath
   #$JAVAEXEC -jar -Dline.separator=$'\n' $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile ctrlTelaComplexaSourcePath=$ctrlTelaComplexaSourcePath xmlClasses=$xmlClasses xmlListTelaSimplesCustomizada=$xmlListTelaSimplesCustomizada sistemaOperacional=$SISTEMAOPERACIONAL
	$JAVAEXEC -jar -Dline.separator=$'\n' $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile ctrlTelaComplexaSourcePath=$ctrlTelaComplexaSourcePath xmlClasses=$xmlClasses sistemaOperacional="WINDOWS" ativarBlockUI=$ATIVAR_BLOCKUI
else
   #$JAVAEXEC -cp "$HOME_XALAN/lib/*" org.apache.xalan.xslt.Process -XSL $xslFile -IN $xmlFile -OUT $outFile -PARAM ctrlTelaComplexaSourcePath $ctrlTelaComplexaSourcePath -PARAM xmlClasses $xmlClasses -PARAM mapasSourcePath $mapasSourcePath -PARAM xmlTelaComplexaSourcePath $xmlTelaComplexaSourcePath
   #$JAVAEXEC -jar $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile ctrlTelaComplexaSourcePath=$ctrlTelaComplexaSourcePath xmlClasses=$xmlClasses xmlListTelaSimplesCustomizada=$xmlListTelaSimplesCustomizada sistemaOperacional=$SISTEMAOPERACIONAL
    $JAVAEXEC -jar $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile ctrlTelaComplexaSourcePath=$ctrlTelaComplexaSourcePath xmlClasses=$xmlClasses ativarBlockUI=$ATIVAR_BLOCKUI
fi
if [ $? -ne 0 ]; then
   exit 1
fi
echo '--> '
echo '--> Identando arquivos JavaScripts'
echo '--> '
listaArq=''
count=0
for arquivo in `cat $HOME_GERADOR/target/ctrlTelaComplexa.lst`; do	
   ((count++))
   listaArq="$listaArq $arquivo"
   if [ $count -eq 100 ]; then
		js-beautify -q -f $listaArq -r > /dev/null &
		listaArq=''
		count=0
   fi
done
js-beautify -q -f $listaArq -r > /dev/null &

ENDTIME6=$(date +%s)
echo '--> '
echo "--> telaComplexa2Controller.xsl executou em $(($ENDTIME6 - $STARTTIME6)) segundos..."
echo '--> '

STARTTIME8=$(date +%s)
echo '--> '
echo '--> Converte o XML de telas para JavaScript Functions - telaComplexa2Functions.xsl'
echo '--> '
xslFile=$HOME_GERADOR/src/main/java/v2/telaComplexa2Functions.xsl
xmlFile=$HOME_GERADOR/target/xmlListTelaComplexa_sync.xml
outFile=$HOME_GERADOR/target/fnTelaComplexa.lst
functionsSourcePath=$HOME_JNG_URL/app/functions
xmlClasses=$HOME_GERADOR/target/classesAgroRevenda.xml

if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
	$JAVAEXEC -jar -Dline.separator=$'\n' $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile functionsSourcePath=$functionsSourcePath xmlClasses=$xmlClasses sistemaOperacional="WINDOWS" ativarBlockUI=$ATIVAR_BLOCKUI
else
    $JAVAEXEC -jar $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile functionsSourcePath=$functionsSourcePath xmlClasses=$xmlClasses ativarBlockUI=$ATIVAR_BLOCKUI
fi
if [ $? -ne 0 ]; then
   exit 1
fi
echo '--> '
echo '--> Identando arquivos JavaScripts'
echo '--> '
listaArq=''
count=0
for arquivo in `cat $HOME_GERADOR/target/fnTelaComplexa.lst`; do	
   ((count++))
   listaArq="$listaArq $arquivo"
   if [ $count -eq 100 ]; then
		js-beautify -q -f $listaArq -r > /dev/null &
		listaArq=''
		count=0
   fi
done
js-beautify -q -f $listaArq -r > /dev/null &

ENDTIME8=$(date +%s)
echo '--> '
echo "--> telaComplexa2Functions.xsl executou em $(($ENDTIME8 - $STARTTIME8)) segundos..."
echo '--> '

STARTTIME9=$(date +%s)
echo '--> '
echo '--> Converte o XML de telas para JavaScript Events - telaComplexa2Events.xsl'
echo '--> '
xslFile=$HOME_GERADOR/src/main/java/v2/telaComplexa2Events.xsl
xmlFile=$HOME_GERADOR/target/xmlListTelaComplexa_sync.xml
outFile=$HOME_GERADOR/target/evtTelaComplexa.lst
eventsSourcePath=$HOME_JNG_URL/app/events
xmlClasses=$HOME_GERADOR/target/classesAgroRevenda.xml

if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
	$JAVAEXEC -jar -Dline.separator=$'\n' $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile eventsSourcePath=$eventsSourcePath xmlClasses=$xmlClasses sistemaOperacional="WINDOWS" ativarBlockUI=$ATIVAR_BLOCKUI
else
    $JAVAEXEC -jar $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile eventsSourcePath=$eventsSourcePath xmlClasses=$xmlClasses ativarBlockUI=$ATIVAR_BLOCKUI
fi
if [ $? -ne 0 ]; then
   exit 1
fi
echo '--> '
echo '--> Identando arquivos JavaScripts'
echo '--> '
listaArq=''
count=0
for arquivo in `cat $HOME_GERADOR/target/evtTelaComplexa.lst`; do	
   ((count++))
   listaArq="$listaArq $arquivo"
   if [ $count -eq 100 ]; then
		js-beautify -q -f $listaArq -r > /dev/null &
		listaArq=''
		count=0
   fi
done
js-beautify -q -f $listaArq -r > /dev/null &

ENDTIME9=$(date +%s)
echo '--> '
echo "--> telaComplexa2Events.xsl executou em $(($ENDTIME9 - $STARTTIME9)) segundos..."
echo '--> '

STARTTIME10=$(date +%s)
echo '--> '
echo '--> Converte o XML de telas para JavaScript Validators - telaComplexa2Validators.xsl'
echo '--> '
xslFile=$HOME_GERADOR/src/main/java/v2/telaComplexa2Validators.xsl
xmlFile=$HOME_GERADOR/target/xmlListTelaComplexa_sync.xml
outFile=$HOME_GERADOR/target/vltTelaComplexa.lst
validatorsSourcePath=$HOME_JNG_URL/app/validators
xmlClasses=$HOME_GERADOR/target/classesAgroRevenda.xml

if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
	$JAVAEXEC -jar -Dline.separator=$'\n' $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile validatorsSourcePath=$validatorsSourcePath xmlClasses=$xmlClasses sistemaOperacional="WINDOWS" ativarBlockUI=$ATIVAR_BLOCKUI
else
    $JAVAEXEC -jar $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile validatorsSourcePath=$validatorsSourcePath xmlClasses=$xmlClasses ativarBlockUI=$ATIVAR_BLOCKUI
fi
if [ $? -ne 0 ]; then
   exit 1
fi
echo '--> '
echo '--> Identando arquivos JavaScripts'
echo '--> '
listaArq=''
count=0
for arquivo in `cat $HOME_GERADOR/target/vltTelaComplexa.lst`; do	
   ((count++))
   listaArq="$listaArq $arquivo"
   if [ $count -eq 100 ]; then
		js-beautify -q -f $listaArq -r > /dev/null &
		listaArq=''
		count=0
   fi
done
js-beautify -q -f $listaArq -r > /dev/null &

ENDTIME10=$(date +%s)
echo '--> '
echo "--> telaComplexa2Validators.xsl executou em $(($ENDTIME10 - $STARTTIME10)) segundos..."
echo '--> '


ENDTIME=$(date +%s)
echo '--> '
echo "--> geraTelasAgroRevendaComplexas.sh executou em $(($ENDTIME - $STARTTIME)) segundos."
echo '--> '
