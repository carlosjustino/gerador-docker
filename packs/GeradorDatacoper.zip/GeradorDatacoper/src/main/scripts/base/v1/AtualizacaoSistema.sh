#!/bin/bash

STARTTIME=$(date +%s)

SISTEMAOPERACIONAL="${SISTEMAOPERACIONAL:=LINUX}"
echo '--> '
echo '--> Configurando variaveis locais...'
echo '--> '
echo 'HOME_JNG='$1
echo 'HOME_WSO2JAGGERY='$2
echo 'OPCAO='$2
echo '--> '
HOME_JNG=$1
HOME_WSO2JAGGERY=$2
OPCAO=$3

if [[ "$JAVAEXEC" == "" ]]; then 
   JAVAEXEC="java -Xms256m -Xmx2G "
fi


ENDTIME=$(date +%s)
echo '--> '
echo "--> geraCodigoDatacoper.sh executou em $(($ENDTIME - $STARTTIME)) segundos."
echo '--> '
