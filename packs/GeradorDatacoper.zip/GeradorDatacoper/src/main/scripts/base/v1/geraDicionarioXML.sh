#!/bin/bash 
STARTTIME=$(date +%s)
SISTEMAOPERACIONAL="${SISTEMAOPERACIONAL:=LINUX}"
echo '--> '
echo '--> Gera Dicionario XML'
echo '--> Sistema Operacional: ' $SISTEMAOPERACIONAL
#PASTASCRIPTS=/cygdrive/c/Carlosj/AgroRevendas/SVN/GeradorDatacoper/trunk/GeradorDatacoper/src/main/scripts/CarlosJ
PASTASCRIPTS="${PASTASCRIPTS:=.}"
HOME_MAPAS=$1
HOME_GERADOR=$2
HOME_XALAN=$3
HOME_SAXON=$4
geraErros=$5

export classeAlvo='ND'
if [ $# -ge 6 ]; then
   classeAlvo=$6
fi 
export geraGrafo='sim'
if [ $# -ge 7 ]; then
   geraGrafo=$7
fi 

if [[ "$JAVAEXEC" == "" ]]; then 
   JAVAEXEC="java -Xms256m -Xmx1024m "
fi
SAXONEXEC="${HOME_SAXON}/saxon9he.jar"

if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
   if [[ "$HOME_GERADOR_URL" == "" ]]; then
      export HOME_GERADOR_URL="file:///"$HOME_GERADOR
   fi
else
   if [[ "$HOME_GERADOR_URL" == "" ]]; then
      export HOME_GERADOR_URL="file://"$HOME_GERADOR
   fi
fi

echo '--> '
echo '--> Caminho dos Mapas: ' $HOME_MAPAS
echo '--> PASTASCRIPTS: ' $PASTASCRIPTS
echo '--> '
if [[ $classeAlvo == "ND" ]]; then
   STARTTIME1=$(date +%s)
   echo '--> '
   echo '--> Converte o mapa para padroes do sistema - mm2padroes.xsl'
   echo '--> '

   #converte o mapa para padroes do sistema
   xslFile=$HOME_GERADOR/src/main/java/mm2padroes.xsl
   xmlFile=$HOME_MAPAS/Padroes.mm
   outFile=$HOME_GERADOR/target/padroesAgroRevenda.xml
   if [ ! -d "$HOME_GERADOR/target" ]; then
      mkdir $HOME_GERADOR/target
      chmod 777 $HOME_GERADOR/target
   fi
   if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
      echo `date`
      $JAVAEXEC -Dline.separator=$'\n' -cp "$HOME_XALAN/lib/*" org.apache.xalan.xslt.Process -XSL $xslFile -IN $xmlFile  -OUT $outFile
   else
      $JAVAEXEC -cp "$HOME_XALAN/lib/*" org.apache.xalan.xslt.Process -XSL $xslFile -IN $xmlFile  -OUT $outFile
   fi
   echo "retorno = " $?
   if [ $? -ne 0 ]; then
      exit 1
   fi
   ENDTIME1=$(date +%s)
   echo '--> '
   echo "--> mm2padroes.xsl executou em $(($ENDTIME1 - $STARTTIME1)) segundos..."
   echo '--> '
fi
STARTTIME2=$(date +%s)
echo '--> '
echo '--> Converte o mapa para dicionario de classes - mm2dicionario.xsl'
echo '--> '

#converte o mapa para dicionario de classes
padroesFileName=$HOME_GERADOR/target/padroesAgroRevenda.xml
xslFile=$HOME_GERADOR/src/main/java/v2/mm2dicionario.xsl
xmlFile=$HOME_MAPAS/AgroRevenda.mm
outFile=$HOME_GERADOR/target/classesAgroRevenda.xml
pathXml=$HOME_GERADOR_URL/target/xmlClasses

if [[ $classeAlvo == "ND" ]]; then
   rm -f $HOME_GERADOR/target/xmlClasses/*.xml 
fi

if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
   echo `date`
   $JAVAEXEC -jar -Dline.separator=$'\n' $SAXONEXEC -xsl:$xslFile -s:$xmlFile -o:$outFile padroesFileName=$padroesFileName geraErros=$geraErros classeAlvo=$classeAlvo pathXml=$pathXml
else
   $JAVAEXEC -jar $SAXONEXEC -xsl:$xslFile -s:$xmlFile -o:$outFile padroesFileName=$padroesFileName geraErros=$geraErros classeAlvo=$classeAlvo pathXml=$pathXml
fi
export retorno=$?
echo "retorno = " $retorno 
if [ 0 -ne $retorno ]; then
   exit 1
fi
ENDTIME2=$(date +%s)
echo '--> ---------------------------------------------------------------------- '
echo '--> ---------------------------------------------------------------------- '
echo "--> mm2dicionario.xsl executou em $(($ENDTIME2 - $STARTTIME2)) segundos..."
echo '--> ---------------------------------------------------------------------- '
echo '--> ---------------------------------------------------------------------- '
# STARTTIMEB=$(date +%s)
# echo '--> '
# echo '--> Gera BIG Xml Classes'
# echo '--> '
# xslFile=$HOME_GERADOR/src/main/java/v2/dicionario2bigXmlClasses.xsl
# xmlFile=$HOME_GERADOR/target/classesAgroRevenda.xml
# outFile=$HOME_GERADOR/target/bigClassesAgroRevenda.xml

# echo "--> SAXON: ${SAXONEXEC}"
# if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
   # $JAVAEXEC -jar -Dline.separator=$'\n' $SAXONEXEC -xsl:$xslFile -s:$xmlFile -o:$outFile 
# else
   # $JAVAEXEC -jar $SAXONEXEC -xsl:$xslFile -s:$xmlFile -o:$outFile 
# fi

# ENDTIMEB=$(date +%s)
# echo '--> '
# echo "--> geraBigXmlClasses.sh executou em $(($ENDTIMEB - $STARTTIMEB)) segundos."
# echo '--> '

# if [ $? -ne 0 ]; then
   # exit 1
# fi

if [[ $classeAlvo == "ND" ]]; then
   STARTTIME3=$(date +%s)
   echo '--> '
   echo '--> Extrai dados fixos do dicionario de classes - dicionario2cargaDadosFixos.xsl'
   echo '--> '
   #converte o dicionario de classes para Carga de dados fixa
   cargaDadosSourcePath=$HOME_GERADOR_URL/target/dadosFixos
   xslFile=$HOME_GERADOR/src/main/java/v2/dicionario2cargaDadosFixos.xsl
   xmlFile=$HOME_GERADOR/target/classesAgroRevenda.xml
   outFile=$HOME_GERADOR/target/arquivosDadosFixosGerados.xml

   echo "--> SAXON: ${SAXONEXEC}"
   if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
      echo `date`
      $JAVAEXEC -jar -Dline.separator=$'\n' $SAXONEXEC -xsl:$xslFile -s:$xmlFile -o:$outFile cargaDadosSourcePath=$cargaDadosSourcePath sistemaOperacional=$SISTEMAOPERACIONAL classeAlvo=$classeAlvo
   else
      $JAVAEXEC -jar $SAXONEXEC -xsl:$xslFile -s:$xmlFile -o:$outFile cargaDadosSourcePath=$cargaDadosSourcePath sistemaOperacional=$SISTEMAOPERACIONAL classeAlvo=$classeAlvo
   fi
   if [ $? -ne 0 ]; then
      exit 1
   fi
   ENDTIME3=$(date +%s)
   echo '--> '
   echo "--> dicionario2cargaDadosFixos.xsl executou em $(($ENDTIME3 - $STARTTIME3)) segundos..."
   echo '--> '
fi
if [[ $geraGrafo == "sim" ]]; then
   STARTTIME4=$(date +%s)

   echo '--> '
   echo '--> Converte o dicionario de classes para uma referencia simplificada - dicionario2simplificado.xsl'
   echo '--> '

   xslFile=$HOME_GERADOR/src/main/java/v2/dicionario2simplificado.xsl
   xmlFile=$HOME_GERADOR/target/classesAgroRevenda.xml
   outFile=$HOME_GERADOR/target/classesAgroRevendaSimplificado.xml

   echo "--> SAXON: ${SAXONEXEC}"
   if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
      echo `date`
     $JAVAEXEC -jar -Dline.separator=$'\n' $SAXONEXEC -xsl:$xslFile -s:$xmlFile -o:$outFile
   else
     $JAVAEXEC -jar $SAXONEXEC -xsl:$xslFile -s:$xmlFile -o:$outFile
   fi

   ENDTIME4=$(date +%s)
   echo '--> '
   echo "--> dicionario2simplificado.xsl executou em $(($ENDTIME4 - $STARTTIME4)) segundos..."
   echo '--> '
fi
if [[ $geraGrafo == "sim" ]]; then
   STARTTIME5=$(date +%s)

   echo '--> '
   echo '--> Converte o dicionario de classes para uma grafo de referencias - dicionario2grafo.xsl'
   echo '--> '

   xslFile=$HOME_GERADOR/src/main/java/v2/dicionario2grafo.xsl
   xmlFile=$HOME_GERADOR/target/classesAgroRevendaSimplificado.xml
   outFile=$HOME_GERADOR/target/classesAgroRevendaGrafo.xml

   echo "--> SAXON: ${SAXONEXEC}"
   if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
      echo `date`
     $JAVAEXEC -jar -Dline.separator=$'\n' $SAXONEXEC -xsl:$xslFile -s:$xmlFile -o:$outFile
   else
     $JAVAEXEC -jar $SAXONEXEC -xsl:$xslFile -s:$xmlFile -o:$outFile
   fi

   ENDTIME5=$(date +%s)
   echo '--> '
   echo "--> dicionario2grafo.xsl executou em $(($ENDTIME5 - $STARTTIME5)) segundos..."
   echo '--> '
fi
ENDTIME=$(date +%s)
echo '--> '
echo "--> geraDicionarioXML.sh executou em $(($ENDTIME - $STARTTIME)) segundos..."
echo '--> '
