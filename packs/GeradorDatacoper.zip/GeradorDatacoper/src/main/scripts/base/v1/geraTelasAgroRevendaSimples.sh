#!/bin/bash
STARTTIME=$(date +%s)
SISTEMAOPERACIONAL="${SISTEMAOPERACIONAL:=LINUX}"
echo '--> '
echo '--> Gera Telas Simples'
echo '--> '
fazUpdate=true
geraDicionario=true
if [ $# -ge 1 ]; then
   if [ !$1 ]; then
      geraDicionario=$1
   fi
   fazUpdate=false
   if [ $# -ge 2 ]; then
      fazUpdate=$2
   fi
fi

if [ ! $# -ge 1 ]; then
   echo '--> '
   echo '--> Configurando variaveis locais...'
   echo '--> '
fi
PASTASCRIPTS=$3
HOME_GERADOR=$4
HOME_MAPAS=$5
HOME_JNG=$6
HOME_JNG_URL=$7
HOME_XALAN=$8
HOME_SAXON=$9
HOME_TEMP=${10}
if [[ "$JAVAEXEC" == "" ]]; then 
   JAVAEXEC="java -Xms256m -Xmx2G "
fi

if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
   if [[ "$HOME_GERADOR_URL" == "" ]]; then
      export HOME_GERADOR_URL="file:///"$HOME_GERADOR
   fi
else
   if [[ "$HOME_GERADOR_URL" == "" ]]; then
      export HOME_GERADOR_URL="file://"$HOME_GERADOR
   fi
fi

if [ $geraDicionario = true ]; then
   $PASTASCRIPTS/geraDicionarioXML.sh $fazUpdate
   if [ $? -ne 0 ]; then
      exit 1
   fi
fi

STARTTIME1=$(date +%s)
echo '--> '
echo '--> Converte o mapa para XML Tela Simples Customizada - mm2telaSimplesCustomizada.xsl'
echo '--> '
#---------------------- converte o mapa para XML Tela Simples Customizada ------------------------------------
xslFile=$HOME_GERADOR/src/main/java/v2/mm2telaSimplesCustomizada.xsl
xmlFile=$HOME_MAPAS/AgroRevenda.mm
outFile=$HOME_GERADOR/target/xmlListTelaSimplesCustomizada.xml
telaSimplesCustomizadaSourcePath=$HOME_GERADOR_URL/target/telas
classesAgroRevenda=$HOME_GERADOR/target/classesAgroRevenda.xml
padroesFileName=$HOME_GERADOR/target/padroesAgroRevenda.xml
echo '--> SAXON Home Edition v9.6.0.7 (Executando)'
if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
   #$JAVAEXEC -Dline.separator=$'\n' -cp "$HOME_XALAN/lib/*" org.apache.xalan.xslt.Process -XSL $xslFile -IN $xmlFile -OUT $outFile -PARAM telaSimplesCustomizadaSourcePath $telaSimplesCustomizadaSourcePath -PARAM classesAgroRevenda $classesAgroRevenda -PARAM padroesFileName $padroesFileName
   $JAVAEXEC -jar -Dline.separator=$'\n' $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile telaSimplesCustomizadaSourcePath=$telaSimplesCustomizadaSourcePath classesAgroRevenda=$classesAgroRevenda padroesFileName=$padroesFileName sistemaOperacional=$SISTEMAOPERACIONAL
else
   #$JAVAEXEC -cp "$HOME_XALAN/lib/*" org.apache.xalan.xslt.Process -XSL $xslFile -IN $xmlFile -OUT $outFile -PARAM telaSimplesCustomizadaSourcePath $telaSimplesCustomizadaSourcePath -PARAM classesAgroRevenda $classesAgroRevenda -PARAM padroesFileName $padroesFileName
   $JAVAEXEC -jar $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile telaSimplesCustomizadaSourcePath=$telaSimplesCustomizadaSourcePath classesAgroRevenda=$classesAgroRevenda padroesFileName=$padroesFileName sistemaOperacional=$SISTEMAOPERACIONAL
fi
ENDTIME1=$(date +%s)
echo '--> '
echo "--> mm2telaSimplesCustomizada.xsl executou em $(($ENDTIME1 - $STARTTIME1)) segundos..."
echo '--> '

# STARTTIME2=$(date +%s)
# echo '--> '
# echo '--> Converte o dicionario de classes para HTML, tela simples List - dicionario2telaSimplesList.xsl'
# echo '--> '
# #---------------------- HTML Tela Simples List ------------------------------------
# htmlSourcePath=$HOME_JNG_URL/app/tpls/cadastros
# xslFile=$HOME_GERADOR/src/main/java/v2/dicionario2telaSimplesList.xsl
# xmlFile=$HOME_GERADOR/target/classesAgroRevenda.xml
# outFile=$HOME_TEMP/htmlListSource.lst
# cd $HOME_GERADOR/target/
# echo '--> SAXON Home Edition v9.6.0.7 (Executando)'
# if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
#    #$JAVAEXEC -Dline.separator=$'\n' -cp "$HOME_XALAN/lib/*" org.apache.xalan.xslt.Process -XSL $xslFile -IN $xmlFile -OUT $outFile  -PARAM htmlSourcePath $htmlSourcePath
#    $JAVAEXEC -jar -Dline.separator=$'\n' $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile htmlSourcePath=$htmlSourcePath sistemaOperacional=$SISTEMAOPERACIONAL
# else
#    #$JAVAEXEC -cp "$HOME_XALAN/lib/*" org.apache.xalan.xslt.Process -XSL $xslFile -IN $xmlFile -OUT $outFile  -PARAM htmlSourcePath $htmlSourcePath
#    $JAVAEXEC -jar $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile htmlSourcePath=$htmlSourcePath sistemaOperacional=$SISTEMAOPERACIONAL
# fi
# echo '--> '
# echo '--> Identando arquivos HTML Tela Simples - List'
# echo '--> '
# listaArq=''
# for arquivo in `cat $HOME_TEMP/htmlListSource.lst`;
# do
#    listaArq="$listaArq $arquivo"
# done
# js-beautify -q --type html -r -m 0 -f $listaArq
# ENDTIME2=$(date +%s)
# echo '--> '
# echo "--> dicionario2telaSimplesList.xsl executou em $(($ENDTIME2 - $STARTTIME2)) segundos..."
# echo '--> '
#
# STARTTIME3=$(date +%s)
# echo '--> '
# echo '--> Converte o dicionario de classes para HTML, tela simples Editor - dicionario2telaSimplesEditor.xsl'
# echo '--> '
# #---------------------- HTML Tela Simples Editor ------------------------------------
# htmlSourcePath=$HOME_JNG_URL/app/tpls/cadastros
# xslFile=$HOME_GERADOR/src/main/java/v2/dicionario2telaSimplesEditor.xsl
# xmlFile=$HOME_GERADOR/target/classesAgroRevenda.xml
# outFile=$HOME_TEMP/htmlEditSource.lst
# cd $HOME_GERADOR/target/
# echo '--> SAXON Home Edition v9.6.0.7 (Executando)'
# if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
#    #$JAVAEXEC -Dline.separator=$'\n' -cp "$HOME_XALAN/lib/*" org.apache.xalan.xslt.Process -XSL $xslFile -IN $xmlFile -OUT $outFile  -PARAM htmlSourcePath $htmlSourcePath
#    $JAVAEXEC -jar -Dline.separator=$'\n' $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile htmlSourcePath=$htmlSourcePath sistemaOperacional=$SISTEMAOPERACIONAL
# else
#    #$JAVAEXEC -cp "$HOME_XALAN/lib/*" org.apache.xalan.xslt.Process -XSL $xslFile -IN $xmlFile -OUT $outFile  -PARAM htmlSourcePath $htmlSourcePath
#    $JAVAEXEC -jar $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile htmlSourcePath=$htmlSourcePath sistemaOperacional=$SISTEMAOPERACIONAL
# fi
# echo '--> '
# echo '--> Identando arquivos HTML Tela Simples - Edit'
# echo '--> '
# listaArq=''
# for arquivo in `cat $HOME_TEMP/htmlEditSource.lst`;
# do
#    listaArq="$listaArq $arquivo"
# done
# js-beautify -q --type html -r -m 0 -f $listaArq
# ENDTIME3=$(date +%s)
# echo '--> '
# echo "--> dicionario2telaSimplesEditor.xsl executou em $(($ENDTIME3 - $STARTTIME3)) segundos..."
# echo '--> '
#
# STARTTIME4=$(date +%s)
# echo '--> '
# echo '--> Converte o dicionario de classes para HTML, tela simples View - dicionario2telaSimplesView.xsl'
# echo '--> '
# #---------------------- HTML Tela Simples View ------------------------------------
# htmlSourcePath=$HOME_JNG_URL/app/tpls/cadastros
# xslFile=$HOME_GERADOR/src/main/java/v2/dicionario2telaSimplesView.xsl
# xmlFile=$HOME_GERADOR/target/classesAgroRevenda.xml
# outFile=$HOME_TEMP/htmlViewSource.lst
# cd $HOME_GERADOR/target/
# echo '--> SAXON Home Edition v9.6.0.7 (Executando)'
# if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
#    #$JAVAEXEC -Dline.separator=$'\n' -cp "$HOME_XALAN/lib/*" org.apache.xalan.xslt.Process -XSL $xslFile -IN $xmlFile -OUT $outFile  -PARAM htmlSourcePath $htmlSourcePath
#    $JAVAEXEC -jar -Dline.separator=$'\n' $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile htmlSourcePath=$htmlSourcePath sistemaOperacional=$SISTEMAOPERACIONAL
# else
#    #$JAVAEXEC -cp "$HOME_XALAN/lib/*" org.apache.xalan.xslt.Process -XSL $xslFile -IN $xmlFile -OUT $outFile  -PARAM htmlSourcePath $htmlSourcePath
#    $JAVAEXEC -jar $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile htmlSourcePath=$htmlSourcePath sistemaOperacional=$SISTEMAOPERACIONAL
# fi
# echo '--> '
# echo '--> Identando arquivos HTML Tela Simples - View'
# echo '--> '
# listaArq=''
# for arquivo in `cat $HOME_TEMP/htmlViewSource.lst`;
# do
#    listaArq="$listaArq $arquivo"
# done
# js-beautify -q --type html -r -m 0 -f $listaArq
# ENDTIME4=$(date +%s)
# echo '--> '
# echo "--> dicionario2telaSimplesView.xsl executou em $(($ENDTIME4 - $STARTTIME4)) segundos..."
# echo '--> '
#
# STARTTIME5=$(date +%s)
# echo '--> '
# echo '--> Converte o XML do dicionario para JavaScript, Ctrl Tela Simples - dicionario2telaSimplesCtrl.xsl'
# echo '--> '
# #---------------------- CTRL Tela Simples ------------------------------------
# ctrlSourcePath=$HOME_JNG_URL/app/ctrl/cadastros
# xslFile=$HOME_GERADOR/src/main/java/v2/dicionario2telaSimplesCtrl.xsl
# xmlFile=$HOME_GERADOR/target/classesAgroRevenda.xml
# outFile=$HOME_TEMP/ctrlSource.lst
# echo '--> SAXON Home Edition v9.6.0.7 (Executando)'
# if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
#    #$JAVAEXEC -Dline.separator=$'\n' -cp "$HOME_XALAN/lib/*" org.apache.xalan.xslt.Process -XSL $xslFile -IN $xmlFile -OUT $outFile  -PARAM ctrlSourcePath $ctrlSourcePath
#    $JAVAEXEC -jar -Dline.separator=$'\n' $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile ctrlSourcePath=$ctrlSourcePath sistemaOperacional=$SISTEMAOPERACIONAL
# else
#    #$JAVAEXEC -cp "$HOME_XALAN/lib/*" org.apache.xalan.xslt.Process -XSL $xslFile -IN $xmlFile -OUT $outFile  -PARAM ctrlSourcePath $ctrlSourcePath
#    $JAVAEXEC -jar $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile ctrlSourcePath=$ctrlSourcePath sistemaOperacional=$SISTEMAOPERACIONAL
# fi
# echo '--> '
# echo '--> Identando arquivos JavaScripts'
# echo '--> '
#
# listaArq=''
# for arquivo in `cat $HOME_TEMP/ctrlSource.lst`;
# do
#    listaArq="$listaArq $arquivo"
# done
# js-beautify -q -f $listaArq -r
# ENDTIME5=$(date +%s)
# echo '--> '
# echo "--> dicionario2telaSimplesCtrl.xsl executou em $(($ENDTIME5 - $STARTTIME5)) segundos..."
# echo '--> '

ENDTIME=$(date +%s)
echo '--> '
echo "--> geraTelasAgroRevendaSimples.sh executou em $(($ENDTIME - $STARTTIME)) segundos."
echo '--> '
