#!/bin/bash

export PASTASCRIPTS=$1
export HOME_MAPAS=$2
export HOME_GERADOR=$3
export HOME_JNG=$4
export HOME_SAXON=$5
export HOME_XALAN=$6
export HOME_TEMP=$7
export JAVAEXEC=$8
export unity=$9
export states=$10
export partial=${11}

onlyStates=false
if [ "$unity" = "--onlyStates" ]; then
	onlyStates=true
fi

unity=$9
[[ -z "$9" ]] && { echo "--> [ERROR] Shell: O parametro $9 referente ao nome da arquivo esta vazio." ; exit 1; }
export state=$unity
partial=false
if [ "${10}" = true ] || [ "${10}" = false ] ; then
	partial=${10}
else
	state=${10}
fi
if [ "${11}" = true ]; then
	partial=${11}
fi

if [ -z $SISTEMAOPERACIONAL ]; then
   SISTEMAOPERACIONAL="LINUX"
   export SISTEMAOPERACIONAL
fi

ATIVAR_BLOCKUI='true'

echo '--> '
echo '--> Gera Telas Complexas'
echo '--> '

echo "PASTASCRIPTS=$PASTASCRIPTS"
if [[ $SISTEMAOPERACIONAL == "WINDOWS" ]]; then
   if [[ "$HOME_DOMAIN_URL" == "" ]]; then
      export HOME_DOMAIN_URL="file:///"$HOME_DOMAIN
   fi
   if [[ "$HOME_JNG_URL" == "" ]]; then
      export HOME_JNG_URL="file:///"$HOME_JNG
   fi
else 
   if [[ "$HOME_DOMAIN_URL" == "" ]]; then
      export HOME_DOMAIN_URL="file://"$HOME_DOMAIN
   fi
   if [[ "$HOME_JNG_URL" == "" ]]; then
      export HOME_JNG_URL="file://"$HOME_JNG
   fi
fi

if [[ "$JAVAEXEC" == "" ]]; then 
   JAVAEXEC="java -Xms256m -Xmx2G "
fi

if [ "$onlyStates" = true ]; then
	$PASTASCRIPTS/geraStates.sh false false $PASTASCRIPTS $HOME_GERADOR $HOME_MAPAS $HOME_JNG $HOME_JNG_URL $HOME_XALAN $HOME_SAXON $HOME_TEMP
elif [ "$partial" = false ]; then
	$PASTASCRIPTS/geraNGFactory.sh false false $PASTASCRIPTS $HOME_GERADOR $HOME_MAPAS $HOME_JNG $HOME_JNG_URL $HOME_XALAN $HOME_SAXON $HOME_TEMP $ATIVAR_BLOCKUI
	if [ $? -ne 0 ]; then
	   exit 1
	fi
	$PASTASCRIPTS/geraMenuSistema.sh false false $PASTASCRIPTS $HOME_GERADOR $HOME_MAPAS $HOME_JNG $HOME_JNG_URL $HOME_XALAN $HOME_SAXON $HOME_TEMP
	if [ $? -ne 0 ]; then
	   exit 1
	fi
	$PASTASCRIPTS/geraStates.sh false false $PASTASCRIPTS $HOME_GERADOR $HOME_MAPAS $HOME_JNG $HOME_JNG_URL $HOME_XALAN $HOME_SAXON $HOME_TEMP
    if [ $? -ne 0 ]; then
       exit 1
    fi
	$PASTASCRIPTS/geraRoutesJNG.sh false false $PASTASCRIPTS $HOME_GERADOR $HOME_JNG $HOME_JNG_URL $HOME_XALAN $HOME_SAXON $HOME_TEMP
	if [ $? -ne 0 ]; then
		exit 1
	fi
	$PASTASCRIPTS/geraTelasAgroRevendaComplexas.sh false false $PASTASCRIPTS $HOME_GERADOR $HOME_MAPAS $HOME_JNG $HOME_JNG_URL $HOME_XALAN $HOME_SAXON $HOME_TEMP $ATIVAR_BLOCKUI $unity
	if [ $? -ne 0 ]; then
		exit 1
	fi 
else
	$PASTASCRIPTS/geraNGFactory.sh false false $PASTASCRIPTS $HOME_GERADOR $HOME_MAPAS $HOME_JNG $HOME_JNG_URL $HOME_XALAN $HOME_SAXON $HOME_TEMP $ATIVAR_BLOCKUI $unity
	if [ $? -ne 0 ]; then
		exit 1
	fi
	$PASTASCRIPTS/geraMenuSistema.sh false false $PASTASCRIPTS $HOME_GERADOR $HOME_MAPAS $HOME_JNG $HOME_JNG_URL $HOME_XALAN $HOME_SAXON $HOME_TEMP
	if [ $? -ne 0 ]; then
	   exit 1
	fi
	$PASTASCRIPTS/geraStates.sh false false $PASTASCRIPTS $HOME_GERADOR $HOME_MAPAS $HOME_JNG $HOME_JNG_URL $HOME_XALAN $HOME_SAXON $HOME_TEMP $state 
	if [ $? -ne 0 ]; then
		exit 1
	fi
	$PASTASCRIPTS/geraTelasAgroRevendaComplexas.sh false false $PASTASCRIPTS $HOME_GERADOR $HOME_MAPAS $HOME_JNG $HOME_JNG_URL $HOME_XALAN $HOME_SAXON $HOME_TEMP $ATIVAR_BLOCKUI $unity
	if [ $? -ne 0 ]; then
		exit 1
	fi   
fi