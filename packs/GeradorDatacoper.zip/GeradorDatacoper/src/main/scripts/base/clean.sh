#!/bin/bash

# ABORT EXECUTION WITH CTRL + C
trap ctrl_c INT

function ctrl_c() {
	echo '--> '
	echo "--> Encerrando processo..."
	echo '--> '
	exit 1
}

STARTTIME=$(date +%s)

source base.sh

echo "----------------------------- C L E A N -------------------------------"
echo "--> GEN_PROJECT=${GEN_PROJECT}"
echo "--> CORE_PROJECT=${CORE_PROJECT}"
echo "--> RESOURCES_PROJECT=${RESOURCES_PROJECT}"
echo "--> BUSINESS_PROJECT=${BUSINESS_PROJECT}"
echo "--> SERVER_DEPLOYMENT=${SERVER_DEPLOYMENT}"
echo "--> SERVER_TMP=${SERVER_TMP}"
echo "--> SERVER_LOGS=${SERVER_LOGS}"
echo "--> SERVER_ERROR_LOGS=${SERVER_ERROR_LOGS}"
echo "--> SERVER_ERROR_DUMPS=${SERVER_ERROR_DUMPS}"
echo "-----------------------------------------------------------------------"

if [ -d "${GEN_PROJECT}/target" ]; then
   echo "--> Apagando pasta ${GEN_PROJECT}/target"
   rm $GEN_PROJECT/target/ -Rf
   echo "--> Diretorio $GEN_PROJECT/target apagado"
	 mkdir $GEN_PROJECT/target
	 chmod 775 $GEN_PROJECT/target
fi

if [ -f "${SERVER_DEPLOYMENT}.war" ]; then
    echo "--> Apagando arquivo e pasta ${SERVER_DEPLOYMENT}"
    rm $SERVER_DEPLOYMENT* -Rf
    echo "--> Arquivo $SERVER_DEPLOYMENT apagado"
else
   if [ -d "${SERVER_DEPLOYMENT}" ]; then
      echo "--> Apagando pasta ${SERVER_DEPLOYMENT}"
      rm $SERVER_DEPLOYMENT* -Rf
      echo "--> Diretorio $SERVER_DEPLOYMENT apagado"
   fi
fi

if [ -d "${SERVER_TMP}" ]; then
   echo "--> Apagando pasta ${SERVER_TMP}"
   rm $SERVER_TMP -Rf
   echo "--> Diretorio $SERVER_TMP apagado"
fi

if [ -f "${SERVER_LOGS}/wso2carbon.log" ]; then
    echo "--> Apagando arquivos da pasta ${SERVER_LOGS}"
    rm $SERVER_LOGS/*.* -f
    echo "--> Arquivos $SERVER_LOGS/*.* apagados"
    rm $SERVER_ERROR_LOGS -f
    echo "--> Arquivos $SERVER_ERROR_LOGS apagados"
    rm $SERVER_ERROR_DUMPS -f
    echo "--> Arquivos $SERVER_ERROR_DUMPS apagados"
fi
## -- CORE PROJECT
if [ -d "${CORE_PROJECT}/src/main" ]; then
   echo "--> Apagando pasta ${CORE_PROJECT}/src/main"
   rm $CORE_PROJECT/src/main -Rf
   echo "--> Diretorio $CORE_PROJECT/src/main apagado"
fi
if [ -d "${CORE_PROJECT}/target" ]; then
   echo "--> Apagando pasta ${CORE_PROJECT}/target"
   rm $CORE_PROJECT/target -Rf
   echo "--> Diretorio $CORE_PROJECT/target apagado"
fi
## -- BUSINESS PROJECT
if [ -d "${BUSINESS_PROJECT}/src/main" ]; then
   echo "--> Apagando pasta ${BUSINESS_PROJECT}/src/main"
   rm $BUSINESS_PROJECT/src/main -Rf
   echo "--> Diretorio $BUSINESS_PROJECT/src/main apagado"
fi
if [ -d "${BUSINESS_PROJECT}/target" ]; then
   echo "--> Apagando pasta ${BUSINESS_PROJECT}/target"
   rm $BUSINESS_PROJECT/target -Rf
   echo "--> Diretorio $BUSINESS_PROJECT/target apagado"
fi
## -- CORE PROJECT
if [ -d "${RESOURCES_PROJECT}/src/main" ]; then
   echo "--> Apagando pasta ${RESOURCES_PROJECT}/src/main"
   rm $RESOURCES_PROJECT/src/main -Rf
   echo "--> Diretorio $RESOURCES_PROJECT/src/main apagado"
fi
if [ -d "${RESOURCES_PROJECT}/target" ]; then
   echo "--> Apagando pasta ${RESOURCES_PROJECT}/target"
   rm $RESOURCES_PROJECT/target -Rf
   echo "--> Diretorio $RESOURCES_PROJECT/target apagado"
fi


ENDTIME=$(date +%s)
echo '--> '
echo "--> CLEAN executou em $(($ENDTIME - $STARTTIME)) segundos..."
echo '--> '
