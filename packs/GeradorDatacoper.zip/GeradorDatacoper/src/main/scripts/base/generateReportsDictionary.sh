#!/bin/bash

# ABORT EXECUTION WITH CTRL + C
trap ctrl_c INT

function ctrl_c() {
	echo '--> '
	echo "--> Encerrando processo..."
	echo '--> '
	exit 1
}

STARTTIME=$(date +%s)
echo '--> '
echo '--> Gera dicionário de RELATÓRIOS'
echo '--> '

source base.sh

eraseFiles=true
deleteXmlFiles=true
for c in $*
do
	if [ "$c" = "--front-end" ] || [ "$c" = "-F" ] || [ "$c" = "--interface" ] || [ "$c" = "-i" ] || [ "$c" = "--all" ] || [ "$c" = "-A" ]; then
			eraseFiles=false
  elif [ "$c" = "--report" ] || [ "$c" = "-p" ]; then
    CMD="--report"
    continue
  elif [ "$CMD" = "--report" ]; then
    unset CMD
		if [[ $c != -* ]]; then
			report=$c
			deleteXmlFiles=false
		fi
  fi
done

# EMPTY FILE VAR
empty1='<arquivos/>'
empty2='<lista/>'

if [ "$eraseFiles" = true ]; then
	# ERASE LIST INTERFACE FILES
	rm -f $HOME_GEN/target/listaTelaComplexa.xml
	rm -f $HOME_GEN/target/xmlListTelaComplexa.xml
	rm -f $HOME_GEN/target/xmlListTelaComplexa_sync.xml
	rm -f $HOME_GEN/target/xmlListTelaSimplesCustomizada.xml
	rm -f $HOME_GEN/target/listaRelatorio.xml
	rm -f $HOME_GEN/target/xmlListRelatorio.xml
	rm -f $HOME_GEN/target/xmlListRelatorio_sync.xml

	# CREATE EMPTY FILES
	touch $HOME_GEN/target/listaTelaComplexa.xml
	touch $HOME_GEN/target/xmlListTelaComplexa.xml
	touch $HOME_GEN/target/xmlListTelaComplexa_sync.xml
	touch $HOME_GEN/target/xmlListTelaSimplesCustomizada.xml
	touch $HOME_GEN/target/listaRelatorio.xml
	touch $HOME_GEN/target/xmlListRelatorio.xml
	touch $HOME_GEN/target/xmlListRelatorio_sync.xml
	echo $empty1 > $HOME_GEN/target/xmlListTelaComplexa.xml
	echo $empty1 > $HOME_GEN/target/xmlListTelaComplexa_sync.xml
	echo $empty1 > $HOME_GEN/target/xmlListTelaSimplesCustomizada.xml
	echo $empty2 > $HOME_GEN/target/listaTelaComplexa.xml
	echo $empty1 > $HOME_GEN/target/xmlListRelatorio.xml
	echo $empty1 > $HOME_GEN/target/xmlListRelatorio_sync.xml
	echo $empty2 > $HOME_GEN/target/listaRelatorio.xml
fi

if [ "$deleteXmlFiles" = true ]; then
	echo '--> '
	echo '--> Apagando arquivos anteriores...'
	echo '--> '
	# ERASE TARGET DICTIONARY FOLDER
	rm -rf $HOME_GEN/target/relatorios/*
fi

STARTTIME1=$(date +%s)
echo '--> '
echo '--> Converte o mapa para XML de lista Relatorio - mm2listaRelatorio.xsl'
echo '--> '

xslFile=$HOME_GEN/src/main/java/v2/mm2listaRelatorio.xsl
xmlFile=$HOME_MINDMAPS/MenuPrincipalSistema.mm
outFile=$HOME_GEN/target/listaRelatorio.xml

$EXEC_XSL_SAXON -xsl:$xslFile -s:$xmlFile -o:$outFile unity=$report

ENDTIME1=$(date +%s)
echo '--> '
echo "--> mm2listaRelatorio.xsl executou em $(($ENDTIME1 - $STARTTIME1)) segundos..."
echo '--> '

STARTTIME2=$(date +%s)
echo '--> '
echo '--> Converte o mapa para o XML de Relatorio - mm2relatorio.xsl'
echo '--> '

xslFile=$HOME_GEN/src/main/java/v2/mm2relatorio.xsl
xmlFile=$HOME_GEN/target/listaRelatorio.xml
outFile=$HOME_GEN/target/xmlListRelatorio.xml
relatorioSourcePath=$HOME_GEN_URL/target
xmlClasses=$HOME_GEN/target/classes$PROJECT_NAME.xml
mapasSourcePath=$HOME_MINDMAPS
padroesFileName=$HOME_GEN/target/padroes$PROJECT_NAME.xml

$EXEC_XSL_SAXON -xsl:$xslFile -s:$xmlFile -o:$outFile relatorioSourcePath=$relatorioSourcePath xmlClasses=$xmlClasses mapasSourcePath=$mapasSourcePath padroesFileName=$padroesFileName

ENDTIME2=$(date +%s)
echo '--> '
echo "--> mm2relatorio.xsl executou em $(($ENDTIME2 - $STARTTIME2)) segundos..."
echo '--> '

STARTTIME3=$(date +%s)
echo '--> '
echo '--> Converte o XML de relatorios p/ XML Sync'
echo '--> '

xslFile=$HOME_GEN/src/main/java/v2/relatorio2Sync.xsl
xmlFile=$HOME_GEN/target/xmlListRelatorio.xml
outFile=$HOME_GEN/target/xmlListRelatorio_sync.xml
syncRelatorioPath=$HOME_GEN_URL/target/sync
xmlClasses=$HOME_GEN/target/classes$PROJECT_NAME.xml

$EXEC_XSL_SAXON -xsl:$xslFile -s:$xmlFile -o:$outFile syncRelatorioPath=$syncRelatorioPath xmlClasses=$xmlClasses

ENDTIME3=$(date +%s)
echo '--> '
echo "--> relatorio2Sync.xsl executou em $(($ENDTIME3 - $STARTTIME3)) segundos..."
echo '--> '

ENDTIME=$(date +%s)
echo '--> '
echo "--> XML de RELATÓRIOS gerado em $(($ENDTIME - $STARTTIME)) segundos."
echo '--> '
