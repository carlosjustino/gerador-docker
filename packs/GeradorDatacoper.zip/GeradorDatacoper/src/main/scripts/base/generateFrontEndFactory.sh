#!/bin/bash

# ABORT EXECUTION WITH CTRL + C
trap ctrl_c INT

function ctrl_c() {
	echo '--> '
	echo "--> Encerrando processo..."
	echo '--> '
	exit 1
}

# SHELL OPTIONS
for c in $*
do
  if [ "$c" = "--target" ]; then
    CMD="--target"
    continue
  elif [ "$CMD" = "--target" ]; then
    unset CMD
    target=$c
  elif [ "$c" = "--indent" ] || [ "$c" = "-i" ]; then
		if command -v js-beautify >/dev/null 2>&1 2>/dev/null; then
			indent=true
		fi
	fi
done

STARTTIME=$(date +%s)

source base.sh

echo '--> '
echo '--> Converte o dicionario para NG Factory Classes - dicionario2ngFactory.xsl'
echo '--> '

factorySourcePath=$HOME_JNG_URL/app/factory
xslFile=$HOME_GEN/src/main/java/v2/dicionario2ngFactory.xsl
xmlFile=$HOME_GEN/target/classes$PROJECT_NAME.xml
outFile=$HOME_TEMP/factorySource.lst

$EXEC_XSL_SAXON -xsl:$xslFile -s:$xmlFile -o:$outFile factorySourcePath=$factorySourcePath unity=$target ativarBlockUI=$ACTIVATE_BLOCKUI

if [ ! -z "$indent" ]; then
  echo '--> '
  echo '--> Identando arquivos JavaScripts'
  echo '--> '
  listaArq=''
  count=0
  for arquivo in `find $HOME_JNG/app/factory -type f -name "*.js"`; do
     ((count++))
     listaArq="$listaArq $arquivo"
     if [ $count -eq 100 ]; then
  		js-beautify -q -f $listaArq -r > /dev/null &
  		listaArq=''
  		count=0
     fi
  done
  js-beautify -q -f $listaArq -r > /dev/null &
fi

ENDTIME=$(date +%s)
echo '--> '
echo "--> geraNGFactory.sh executou em $(($ENDTIME - $STARTTIME)) segundos."
echo '--> '
