#!/bin/bash

# ABORT EXECUTION WITH CTRL + C
trap ctrl_c INT

function ctrl_c() {
	echo '--> '
	echo "--> Encerrando processo..."
	echo '--> '
	exit 1
}

STARTTIME=$(date +%s)

source base.sh

for c in $*
do
  if [ "$c" = "--target" ]; then
    CMD="--target"
    continue
  elif [ "$CMD" = "--target" ]; then
    unset CMD
    target=$c
  fi
done

echo '--> '
echo '--> Gera Mapa de classes templates : '$target
echo '--> '

if [ -z $target ]; then
   echo 'Faltou parametro --target'
   exit 1
fi 

padroesFileName=$HOME_GEN/target/padroes$PROJECT_NAME.xml
xslFile=$HOME_GEN/src/main/java/v2/mm2dicionario.xsl
xmlFile=$HOME_MINDMAPS/$PROJECT_NAME.mm
outFile=$HOME_GEN/target/$PROJECT_NAME.classeTemplates.mm
mapaGerado=target/classe_$target.templates.mm
pathXml=$HOME_GEN_URL/target/xmlClasses

echo '<map version="1.0.1"><node TEXT="GERANDO MAPA"><node TEXT="AGUARDE"></node></node></map>' > $HOME_GEN/$mapaGerado

$EXEC_XSL_SAXON -xsl:$xslFile -s:$xmlFile -o:$outFile padroesFileName=$padroesFileName geraErros=$GENERATE_ERRORS classeAlvo=$target pathXml=$pathXml geraMapaTemplatesParaClasseAlvo=S mapaGerado=$HOME_GEN_URL/$mapaGerado
if [ $? -ne 0  ]; then
   exit 1
fi
ENDTIME=$(date +%s)
echo '--> '
echo "--> generateTemplatesMap.sh executou em $(($ENDTIME - $STARTTIME)) segundos..."
echo '--> '
