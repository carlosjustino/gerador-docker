#!/bin/bash

# ABORT EXECUTION WITH CTRL + C
trap ctrl_c INT

function ctrl_c() {
	echo '--> '
	echo "--> Encerrando processo..."
	echo '--> '
	exit 1
}

STARTTIME=$(date +%s)

source base.sh

echo '--> '
echo '--> Gera Menu do Sistema'
echo '--> '

STARTTIME2=$(date +%s)
echo '--> '
echo '--> Converte o mapa de menu para o XML - mm2menuXml.xsl'
echo '--> '

classesXMLFile=$HOME_GEN_URL/target/classes$PROJECT_NAME.xml
xmlTelaSourcePath=$HOME_GEN/target
xslFile=$HOME_GEN/src/main/java/v2/mm2menuXml.xsl
xmlFile=$HOME_MINDMAPS/MenuPrincipalSistema.mm
outFile=$HOME_GEN/target/menuPrincipalSistema.xml

$EXEC_XSL_SAXON -xsl:$xslFile -s:$xmlFile -o:$outFile classesXMLFile=$classesXMLFile xmlTelaSourcePath=$xmlTelaSourcePath
if [ $? -ne 0 ]; then
   exit 1
fi
ENDTIME2=$(date +%s)
echo '--> '
echo "--> mm2menuXml.xsl executou em $(($ENDTIME2 - $STARTTIME2)) segundos..."
echo '--> '

STARTTIME1=$(date +%s)
echo '--> '
echo '--> Converte o mapa de menu para o Json (menu Lateral) - mm2menuJson.xsl'
echo '--> '

classesXMLFile=$HOME_GEN_URL/target/classes$PROJECT_NAME.xml
mapasSourcePath=$HOME_MINDMAPS
xslFile=$HOME_GEN/src/main/java/v2/mm2menuJson.xsl
xmlFile=$HOME_GEN/target/menuPrincipalSistema.xml
outFile=$HOME_JNG/app/menu/menuPrincipalSistema.json

if [ ! -d "$HOME_JNG/app/menu" ]; then
  mkdir $HOME_JNG/app/menu
  chmod 775 $HOME_JNG/app/menu
fi

$EXEC_XSL_SAXON -xsl:$xslFile -s:$xmlFile -o:$outFile classesXMLFile=$classesXMLFile mapasSourcePath=$mapasSourcePath sistemaOperacional=$OS
if [ $? -ne 0 ]; then
   exit 1
fi
ENDTIME1=$(date +%s)
echo '--> '
echo "--> mm2menuJson.xsl executou em $(($ENDTIME1 - $STARTTIME1)) segundos..."
echo '--> '

STARTTIME3=$(date +%s)
echo '--> '
echo '--> Converte o xml do menu para o Json (menu Horizontal) - menuXml2menuHorizontalJson.xsl'
echo '--> '

xslFile=$HOME_GEN/src/main/java/v2/menuXml2menuHorizontalJson.xsl
xmlFile=$HOME_GEN/target/menuPrincipalSistema.xml
outFile=$HOME_JNG/app/menu/menuHorizontalSistema.json

if [ ! -d "$HOME_JNG/app/menu" ]; then
  mkdir $HOME_JNG/app/menu
  chmod 775 $HOME_JNG/app/menu
fi

$EXEC_XSL_SAXON -xsl:$xslFile -s:$xmlFile -o:$outFile
if [ $? -ne 0 ]; then
   exit 1
fi

ENDTIME3=$(date +%s)
echo '--> '
echo "--> menuXml2menuHorizontalJson.xsl executou em $(($ENDTIME3 - $STARTTIME3)) segundos..."
echo '--> '

echo '--> '
echo '--> Converte o menuPrincipalSistema.xml para rotinaMenu.sql - menuPrincipalSistema2db.xsl'
echo '--> '

xslFile=$HOME_GEN/src/main/java/v2/menuPrincipalSistema2db.xsl
xmlFile=$HOME_GEN/target/menuPrincipalSistema.xml
outFile=$HOME_GEN/target/rotinaMenu.sql

$EXEC_XSL_SAXON -xsl:$xslFile -s:$xmlFile -o:$outFile
if [ $? -ne 0 ]; then
   exit 1
fi

echo '--> '
echo "--> Movendo script RotinaMenu.sql para /GeradorDatacoper/src/main/scripts/banco"
echo '--> '

rm -rf $HOME_GEN/src/main/scripts/banco/rotinaMenu*.sql
mv $HOME_GEN/target/rotinaMenu.sql $HOME_GEN/src/main/scripts/banco/rotinaMenu-$(date +%F-%H-%M).sql

ENDTIME=$(date +%s)
echo '--> '
echo "--> geraMenuSistema.sh executou em $(($ENDTIME - $STARTTIME)) segundos."
echo '--> '
