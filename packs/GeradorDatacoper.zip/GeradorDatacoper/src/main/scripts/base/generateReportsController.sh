#!/bin/bash

# ABORT EXECUTION WITH CTRL + C
trap ctrl_c INT

function ctrl_c() {
	echo '--> '
	echo "--> Encerrando processo..."
	echo '--> '
	exit 1
}

source base.sh

# SHELL OPTIONS
for c in $*
do
  if [ "$c" = "--indent" ] || [ "$c" = "-i" ]; then
		if command -v js-beautify >/dev/null 2>&1 2>/dev/null; then
			indent=true
		fi
	fi
done

STARTTIME=$(date +%s)
echo '--> '
echo '--> Converte o XML de tela complexa e XML do dicionario para JavaScript, Ctrl Relatorio - relatorio2Controller.xsl'
echo '--> '

xslFile=$HOME_GEN/src/main/java/v2/relatorio2Controller.xsl
xmlFile=$HOME_GEN/target/xmlListRelatorio_sync.xml
outFile=$HOME_GEN/target/ctrlRelatorio.lst
ctrlSourcePath=$HOME_JNG_URL/app/ctrl
xmlClasses=$HOME_GEN/target/classes$PROJECT_NAME.xml

$EXEC_XSL_SAXON -xsl:$xslFile -s:$xmlFile -o:$outFile ctrlSourcePath=$ctrlSourcePath xmlClasses=$xmlClasses sistemaOperacional=$OS

if [ ! -z "$indent" ]; then
  echo '--> '
  echo '--> Identando arquivos JavaScripts'
  echo '--> '

  listaArq=''
  for arquivo in `cat $HOME_GEN/target/ctrlRelatorio.lst`;
  do
     listaArq="$listaArq $arquivo"
  done
  js-beautify -q -f $listaArq -r
fi

ENDTIME=$(date +%s)
echo '--> '
echo "--> relatorio2Controller.xsl executou em $(($ENDTIME - $STARTTIME)) segundos..."
echo '--> '
