#!/bin/bash

# ABORT EXECUTION WITH CTRL + C
trap ctrl_c INT

function ctrl_c() {
	echo '--> '
	echo "--> Encerrando processo..."
	echo '--> '
	exit 1
}

source base.sh

STARTTIME=$(date +%s)

echo '--> '
echo '--> Gera XML de Rotinas - menuPrincipalSistema2XmlRotinas.xsl'
echo '--> '

xslFile=$HOME_GEN/src/main/java/v2/menuPrincipalSistema2XmlRotinas.xsl
xmlFile=$HOME_GEN/target/menuPrincipalSistema.xml
outFile=$HOME_GEN/target/xmlRotinas.xml

$EXEC_XSL_SAXON -xsl:$xslFile -s:$xmlFile -o:$outFile

ENDTIME=$(date +%s)
echo '--> '
echo "--> menuPrincipalSistema2XmlRotinas.xsl executou em $(($ENDTIME - $STARTTIME)) segundos..."
echo '--> '
