#!/bin/bash

# ABORT EXECUTION WITH CTRL + C
trap ctrl_c INT

function ctrl_c() {
	echo '--> '
	echo "--> Encerrando processo..."
	echo '--> '
	exit 1
}

STARTTIME=$(date +%s)
echo '--> '
echo '--> Gera dicionário de INTERFACES'
echo '--> '

source base.sh

deleteXmlFiles=true
for c in $*
do
  if [ "$c" = "--interface" ] || [ "$c" = "-i" ]; then
    CMD="--interface"
    continue
  elif [ "$CMD" = "--interface" ]; then
    unset CMD
		if [[ $c != -* ]]; then
			interface=$c
			deleteXmlFiles=false
		fi
  fi
done

# EMPTY FILE VAR
empty1='<arquivos/>'
empty2='<lista/>'

# ERASE LIST INTERFACE FILES
rm -f $HOME_GEN/target/listaTelaComplexa.xml
rm -f $HOME_GEN/target/xmlListTelaComplexa.xml
rm -f $HOME_GEN/target/xmlListTelaComplexa_sync.xml
rm -f $HOME_GEN/target/xmlListTelaSimplesCustomizada.xml
rm -f $HOME_GEN/target/listaRelatorio.xml
rm -f $HOME_GEN/target/xmlListRelatorio.xml
rm -f $HOME_GEN/target/xmlListRelatorio_sync.xml

# CREATE EMPTY FILES
touch $HOME_GEN/target/listaTelaComplexa.xml
touch $HOME_GEN/target/xmlListTelaComplexa.xml
touch $HOME_GEN/target/xmlListTelaComplexa_sync.xml
touch $HOME_GEN/target/xmlListTelaSimplesCustomizada.xml
touch $HOME_GEN/target/listaRelatorio.xml
touch $HOME_GEN/target/xmlListRelatorio.xml
touch $HOME_GEN/target/xmlListRelatorio_sync.xml
echo $empty1 > $HOME_GEN/target/xmlListTelaComplexa.xml
echo $empty1 > $HOME_GEN/target/xmlListTelaComplexa_sync.xml
echo $empty1 > $HOME_GEN/target/xmlListTelaSimplesCustomizada.xml
echo $empty2 > $HOME_GEN/target/listaTelaComplexa.xml
echo $empty1 > $HOME_GEN/target/xmlListRelatorio.xml
echo $empty1 > $HOME_GEN/target/xmlListRelatorio_sync.xml
echo $empty2 > $HOME_GEN/target/listaRelatorio.xml

if [ "$deleteXmlFiles" = true ]; then
	echo '--> '
	echo '--> Apagando arquivos anteriores...'
	echo '--> '

	# ERASE TARGET DICTIONARY FOLDER
	rm -rf $HOME_GEN/target/telas/*
fi

STARTTIME1=$(date +%s)
echo '--> '
echo '--> Converte o mapa para XML Tela Simples Customizada - mm2telaSimplesCustomizada.xsl'
echo '--> '

xslFile=$HOME_GEN/src/main/java/v2/mm2telaSimplesCustomizada.xsl
xmlFile=$HOME_MINDMAPS/$PROJECT_NAME.mm
outFile=$HOME_GEN/target/xmlListTelaSimplesCustomizada.xml
telaSimplesCustomizadaSourcePath=$HOME_GEN_URL/target/telas
xmlClasses=$HOME_GEN/target/classes$PROJECT_NAME.xml
padroesFileName=$HOME_GEN/target/padroes$PROJECT_NAME.xml

$EXEC_XSL_SAXON -xsl:$xslFile -s:$xmlFile -o:$outFile telaSimplesCustomizadaSourcePath=$telaSimplesCustomizadaSourcePath xmlClasses=$xmlClasses padroesFileName=$padroesFileName sistemaOperacional=$OS unity=$interface

ENDTIME1=$(date +%s)
echo '--> '
echo "--> mm2telaSimplesCustomizada.xsl executou em $(($ENDTIME1 - $STARTTIME1)) segundos..."
echo '--> '

# READ FILE TO VAR
fileList=`cat $HOME_GEN/target/xmlListTelaSimplesCustomizada.xml`

if [ -z "$interface" ] || [ "$empty1" = "$fileList" ]; then

  unset fileList

  STARTTIME2=$(date +%s)
  echo '--> '
  echo '--> Converte o mapa para XML de lista Tela Complexa - mm2listaTelaComplexa.xsl'
  echo '--> '

  xslFile=$HOME_GEN/src/main/java/v2/mm2listaTelaComplexa.xsl
  xmlFile=$HOME_MINDMAPS/$PROJECT_NAME.mm
  outFile=$HOME_GEN/target/listaTelaComplexa.xml

  $JAVAEXEC -jar -Dline.separator=$'\n' $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile unity=$interface

  ENDTIME2=$(date +%s)
  echo '--> '
  echo "--> mm2listaTelaComplexa.xsl executou em $(($ENDTIME2 - $STARTTIME2)) segundos..."
  echo '--> '

  STARTTIME3=$(date +%s)
  echo '--> '
  echo '--> Converte o mapa para o XML de Tela Complexa - mm2telaComplexa.xsl'
  echo '--> '

  xslFile=$HOME_GEN/src/main/java/v2/mm2telaComplexa.xsl
  xmlFile=$HOME_GEN/target/listaTelaComplexa.xml
  outFile=$HOME_GEN/target/xmlListTelaComplexa.xml
  telaComplexaSourcePath=$HOME_GEN_URL/target/telas
  xmlClasses=$HOME_GEN/target/classes$PROJECT_NAME.xml
  mapasSourcePath=$HOME_MINDMAPS
  padroesFileName=$HOME_GEN/target/padroes$PROJECT_NAME.xml

  $EXEC_XSL_SAXON -xsl:$xslFile -s:$xmlFile -o:$outFile telaComplexaSourcePath=$telaComplexaSourcePath xmlClasses=$xmlClasses mapasSourcePath=$mapasSourcePath padroesFileName=$padroesFileName unity=$interface

  ENDTIME3=$(date +%s)
  echo '--> '
  echo "--> mm2telaComplexa.xsl executou em $(($ENDTIME3 - $STARTTIME3)) segundos..."
  echo '--> '

	STARTTIME7=$(date +%s)

	echo '--> '
	echo '--> Converte o XML de tela complexa para XML Sync'
	echo '--> '

	xslFile=$HOME_GEN/src/main/java/v2/telaComplexa2Sync.xsl
	xmlFile=$HOME_GEN/target/xmlListTelaComplexa.xml
	outFile=$HOME_GEN/target/xmlListTelaComplexa_sync.xml
	syncTelaComplexaPath=$HOME_GEN_URL/target/sync
	xmlClasses=$HOME_GEN/target/classes$PROJECT_NAME.xml
	xmlListTelaSimplesCustomizada=$HOME_GEN/target/xmlListTelaSimplesCustomizada.xml

	$EXEC_XSL_SAXON -xsl:$xslFile -s:$xmlFile -o:$outFile syncTelaComplexaPath=$syncTelaComplexaPath xmlClasses=$xmlClasses xmlListTelaSimplesCustomizada=$xmlListTelaSimplesCustomizada

	ENDTIME7=$(date +%s)
	echo '--> '
	echo "--> telaComplexa2Sync.xsl executou em $(($ENDTIME7 - $STARTTIME7)) segundos..."
	echo '--> '
fi

ENDTIME=$(date +%s)
echo '--> '
echo "--> XML de INTERFACES gerado em $(($ENDTIME - $STARTTIME)) segundos."
echo '--> '
