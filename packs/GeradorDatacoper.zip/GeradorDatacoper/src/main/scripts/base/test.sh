#!/bin/bash

source generateInclude.sh "$@"

STARTTIME=$(date +%s)

source base.sh

echo "[INFO] ---"
echo "[INFO] Iniciando testes unitários..."
echo "[INFO] ---"

params=""
for c in $*
do
    if [ "$c" = "--test-host" ] || [ "$c" = "-th" ]; then
		STACK="--test-host"
        continue
    elif [ "$STACK" = "--test-host" ]; then
        params="${params} -Dserver.host=${c}"
        unset STACK
    elif [ "$c" = "--test-port" ] || [ "$c" = "-tp" ]; then
        STACK="--test-port"
        continue
    elif [ "$STACK" = "--test-port" ]; then
        params="${params} -Dserver.port=${c}"
        unset STACK
    elif [ "$c" = "--test-app" ] || [ "$c" = "-ta" ]; then
        STACK="--test-app"
        continue
    elif [ "$STACK" = "--test-app" ]; then
        params="${params} -Dserver.app=${c}"
        unset STACK
    elif [ "$c" = "--test-user" ] || [ "$c" = "-tu" ]; then
        STACK="--test-user"
        continue
    elif [ "$STACK" = "--test-user" ]; then
        params="${params} -Duser.login=${c}"
        unset STACK
    fi
done

cd $RESOURCE_PROJECT;

if [ -z $execTarget ]; then
	  mvn test -T1C surefire-report:report -Darchaius.configurationSource.additionalUrls=$execProperties
else
    echo "[INFO] Target: "$execTarget
    mvn test -T1C surefire-report:report -Dtest=$execTarget $params
fi

if [ $? -ne 0 ]; then
   echo "[ERRO] ---"
   echo "[ERRO] --- Não foi possível compilar a aplicação DS"
   echo "[ERRO] ---"
   exit 1
fi

ENDTIME=$(date +%s)
echo '--> '
echo "--> Testes unitários executou em $(($ENDTIME - $STARTTIME)) segundos..."
echo '--> '
