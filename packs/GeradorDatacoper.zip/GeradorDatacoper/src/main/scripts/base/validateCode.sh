#!/bin/bash

# ABORT EXECUTION WITH CTRL + C
trap ctrl_c INT

function ctrl_c() {
	echo '--> '
	echo "--> Encerrando processo..."
	echo '--> '
	exit 1
}

STARTTIME=$(date +%s)

source base.sh

indent=false
for c in $*
do
  if [ "$c" = "--target" ]; then
    CMD="--target"
    continue
  elif [ "$CMD" = "--target" ]; then
    unset CMD
    target=$c
  fi
done

if [[ "$JAVAEXEC" == "" ]]; then
   JAVAEXEC="java -Xms256m -Xmx2G "
fi

echo '--> '
echo '--> TesteJustino - dicionario2validateCode.xsl'
echo '--> '

xslFile=$HOME_GEN/src/main/java/v2/dicionario2validateCode.xsl
xmlFile=$HOME_GEN/target/classes$PROJECT_NAME.xml
outFile=$HOME_GEN/target/validaCodigo.txt

$EXEC_XSL_SAXON -xsl:$xslFile -s:$xmlFile -o:$outFile classeAlvo=$classeAlvo 

ENDTIME=$(date +%s)
echo '--> '
echo "--> dicionario2validateCode.xsl executou em $(($ENDTIME - $STARTTIME)) segundos..."
echo '--> '
