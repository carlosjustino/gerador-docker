#!/bin/bash

# ABORT EXECUTION WITH CTRL + C
trap ctrl_c INT

function ctrl_c() {
	echo '--> '
	echo "--> Encerrando processo..."
	echo '--> '
	exit 1
}

# SHELL OPTIONS
for c in $*
do
  if [ "$c" = "--indent" ] || [ "$c" = "-i" ]; then
		if command -v js-beautify >/dev/null 2>&1 2>/dev/null; then
			indent=true
		fi
	fi
done

source base.sh

STARTTIME3=$(date +%s)
echo '--> '
echo '--> Converte o XML de tela complexa para HTML, tela complexa List - telaComplexa2List.xsl'
echo '--> '

xslFile=$HOME_GEN/src/main/java/v2/telaComplexa2List.xsl
xmlFile=$HOME_GEN/target/xmlListTelaComplexa.xml
outFile=$HOME_GEN/target/htmlTelaComplexaList.lst
xmlClasses=$HOME_GEN/target/classes$PROJECT_NAME.xml
xmlListTelaSimplesCustomizada=$HOME_GEN/target/xmlListTelaSimplesCustomizada.xml
htmlTelaComplexaSourcePath=$HOME_JNG_URL/app/tpls

$EXEC_XSL_SAXON -xsl:$xslFile -s:$xmlFile -o:$outFile htmlTelaComplexaSourcePath=$htmlTelaComplexaSourcePath xmlClasses=$xmlClasses xmlListTelaSimplesCustomizada=$xmlListTelaSimplesCustomizada sistemaOperacional=$OS

if [ ! -z "$indent" ]; then
  echo '--> '
  echo '--> Identando arquivos HTML Tela Complexa - List'
  echo '--> '
  listaArq=''
  count=0
  for arquivo in `cat $HOME_GEN/target/htmlTelaComplexaList.lst`; do
     ((count++))
     listaArq="$listaArq $arquivo"
     if [ $count -eq 100 ]; then
  		js-beautify -q --type html -r -m 0 -f $listaArq > /dev/null &
  		listaArq=''
  		count=0
     fi
  done
  js-beautify -q --type html -r -m 0 -f $listaArq > /dev/null &
fi

ENDTIME3=$(date +%s)
echo '--> '
echo "--> telaComplexa2List.xsl executou em $(($ENDTIME3 - $STARTTIME3)) segundos..."
echo '--> '
