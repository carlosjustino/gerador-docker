#!/bin/bash

# ABORT EXECUTION WITH CTRL + C
trap ctrl_c INT

function ctrl_c() {
	echo '--> '
	echo "--> Encerrando processo..."
	echo '--> '
	exit 1
}

STARTTIME=$(date +%s)

source base.sh

echo '--> '
echo '--> Converte o mapa do menu para os States - menu2classesReferenciadas.xsl'
echo '--> '

sGrafo="Grafo"
stateSourcePath=$HOME_JNG_URL/app/states
xmlClasses=$HOME_GEN/target/classes$PROJECT_NAME.xml
bigXmlClasses=$HOME_GEN/target/bigClasses$PROJECT_NAME.xml
xmlSourcePath=$HOME_GEN_URL/target/
xmlGrafo=$HOME_GEN/target/classes$PROJECT_NAME$sGrafo.xml
xslFile=$HOME_GEN/src/main/java/v2/menu2classesReferenciadas.xsl
xmlFile=$HOME_GEN/target/menuPrincipalSistema.xml
outFile=$HOME_GEN/target/classesReferenciadas.xml

$EXEC_XSL_SAXON -xsl:$xslFile -s:$xmlFile -o:$outFile stateSourcePath=$stateSourcePath bigXmlClasses=$bigXmlClasses xmlClasses=$xmlClasses xmlSourcePath=$xmlSourcePath xmlGrafo=$xmlGrafo
if [ $? -ne 0 ]; then
      exit 1
   fi
echo '--> '
echo '--> Converte o mapa do menu para os States - menuPrincipalSistemaMM2State.xsl'
echo '--> '

stateSourcePath=$HOME_JNG_URL/app/states
xmlClasses=$HOME_GEN/target/classes$PROJECT_NAME.xml
xmlRefs=$HOME_GEN/target/classesReferenciadas.xml
xmlSourcePath=$HOME_GEN_URL/target/
xslFile=$HOME_GEN/src/main/java/v2/menuPrincipalSistemaMM2State.xsl
xmlFile=$HOME_GEN/target/menuPrincipalSistema.xml
outFile=$HOME_JNG/states.jag

$EXEC_XSL_SAXON -xsl:$xslFile -s:$xmlFile -o:$outFile stateSourcePath=$stateSourcePath xmlClasses=$xmlClasses xmlSourcePath=$xmlSourcePath xmlRefs=$xmlRefs
if [ $? -ne 0 ]; then
      exit 1
   fi
ENDTIME=$(date +%s)
echo '--> '
echo "--> geraStates.sh executou em $(($ENDTIME - $STARTTIME)) segundos."
echo '--> '
