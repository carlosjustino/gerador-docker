#!/bin/bash

# ABORT EXECUTION WITH CTRL + C
trap ctrl_c INT

function ctrl_c() {
	echo '--> '
	echo "--> Encerrando processo..."
	echo '--> '
	exit 1
}

STARTTIME=$(date +%s)

source base.sh

indent=false
for c in $*
do
  if [ "$c" = "--target" ]; then
    CMD="--target"
    continue
  elif [ "$CMD" = "--target" ]; then
    unset CMD
    target=$c
  elif [ "$c" = "--indent" ] || [ "$c" = "-i" ]; then
    CMD="--indent"
    continue
  elif [ "$CMD" = "--indent" ]; then
    unset CMD
    indent=$c
  fi
done

if [[ "$JAVAEXEC" == "" ]]; then
   JAVAEXEC="java -Xms256m -Xmx2G "
fi

echo '--> '
echo '--> Converte o dicionario de classes para SQL Index - createIndex.xsl'
echo '--> '

xslFile=$HOME_GEN/src/main/java/v2/createIndex.xsl
xmlFile=$HOME_GEN/target/classes$PROJECT_NAME.xml
outFile=$HOME_GEN/target/sqlCreateIndex.sql

$EXEC_XSL_SAXON -xsl:$xslFile -s:$xmlFile -o:$outFile classeAlvo=$classeAlvo tipo=FK

ENDTIME=$(date +%s)
echo '--> '
echo "--> createIndex.xsl executou em $(($ENDTIME - $STARTTIME)) segundos..."
echo '--> '
