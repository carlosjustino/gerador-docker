#!/bin/bash

# ABORT EXECUTION WITH CTRL + C
trap ctrl_c INT

function ctrl_c() {
	echo '--> '
	echo "--> Encerrando processo..."
	echo '--> '
	exit 1
}

# SHELL OPTIONS
for c in $*
do
  if [ "$c" = "--indent" ] || [ "$c" = "-i" ]; then
		if command -v js-beautify >/dev/null 2>&1 2>/dev/null; then
			export indent=true
		fi
	fi
done

source base.sh
if [ ! -z "$indent" ]; then
    echo '--> '
	echo '--> Identando arquivos HTML Tela Complexa - View - htmlTelaComplexaView.lst'
	echo '--> '
	listaArq=''
	count=0
    if [ -f $HOME_GEN/target/htmlTelaComplexaView.lst ]; then
        for arquivo in `cat $HOME_GEN/target/htmlTelaComplexaView.lst`; do
           ((count++))
           listaArq="$listaArq $arquivo"
           if [ $count -eq 100 ]; then
                js-beautify -q --type html -r -m 0 -f $listaArq > /dev/null
                listaArq=''
                count=0
           fi
        done

        js-beautify -q --type html -r -m 0 -f $listaArq > /dev/null
    fi

    echo '--> '
    echo '--> Identando arquivos JavaScripts - app/factory'
    echo '--> '
    listaArq=''
    count=0

    for arquivo in `find $HOME_JNG/app/factory -type f -name "*.js"`; do
        ((count++))
        listaArq="$listaArq $arquivo"
        if [ $count -eq 100 ]; then
            js-beautify -q -f $listaArq -r > /dev/null
            listaArq=''
            count=0
        fi
    done
    js-beautify -q -f $listaArq -r > /dev/null

    echo '--> '
    echo '--> Identando arquivos JavaScripts - evtTelaComplexa.lst '
    echo '--> '
    listaArq=''
    count=0
    if [ -f $HOME_GEN/target/evtTelaComplexa.lst ]; then
        for arquivo in `cat $HOME_GEN/target/evtTelaComplexa.lst`; do
           ((count++))
           listaArq="$listaArq $arquivo"
           if [ $count -eq 100 ]; then
                js-beautify -q -f $listaArq -r > /dev/null
                listaArq=''
                count=0
           fi
        done
        js-beautify -q -f $listaArq -r > /dev/null
    fi
    echo '--> '
    echo '--> Identando arquivos HTML Tela Complexa - Editor - htmlTelaComplexaEditor.lst '
    echo '--> '
    listaArq=''
    count=0
    if [ -f $HOME_GEN/target/htmlTelaComplexaEditor.lst ]; then
        for arquivo in `cat $HOME_GEN/target/htmlTelaComplexaEditor.lst`; do
           ((count++))
           listaArq="$listaArq $arquivo"
           if [ $count -eq 100 ]; then
                js-beautify -q --type html -r -m 0 -f $listaArq > /dev/null
                listaArq=''
                count=0
           fi
        done
        js-beautify -q --type html -r -m 0 -f $listaArq > /dev/null
    fi

    echo '--> '
    echo '--> Identando arquivos JavaScripts - vltTelaComplexa.lst'
    echo '--> '
    listaArq=''
    count=0
    if [ -f $HOME_GEN/target/vltTelaComplexa.lst ]; then
        for arquivo in `cat $HOME_GEN/target/vltTelaComplexa.lst`; do
           ((count++))
           listaArq="$listaArq $arquivo"
           if [ $count -eq 100 ]; then
                js-beautify -q -f $listaArq -r > /dev/null
                listaArq=''
                count=0
           fi
        done
        js-beautify -q -f $listaArq -r > /dev/null
    fi
    echo '--> '
    echo '--> Identando arquivos HTML Tela Complexa - List - htmlTelaComplexaList.lst'
    echo '--> '
    listaArq=''
    count=0
    if [ -f $HOME_GEN/target/htmlTelaComplexaList.lst ]; then
        for arquivo in `cat $HOME_GEN/target/htmlTelaComplexaList.lst`; do
         ((count++))
         listaArq="$listaArq $arquivo"
         if [ $count -eq 100 ]; then
            js-beautify -q --type html -r -m 0 -f $listaArq > /dev/null
            listaArq=''
            count=0
         fi
        done
        js-beautify -q --type html -r -m 0 -f $listaArq > /dev/null
    fi
    echo '--> '
    echo '--> Identando arquivos JavaScripts - fnTelaComplexa.lst'
    echo '--> '
    listaArq=''
    count=0
    if [ -f $HOME_GEN/target/fnTelaComplexa.lst ]; then
        for arquivo in `cat $HOME_GEN/target/fnTelaComplexa.lst`; do
           ((count++))
           listaArq="$listaArq $arquivo"
           if [ $count -eq 100 ]; then
                js-beautify -q -f $listaArq -r > /dev/null
                listaArq=''
                count=0
           fi
        done
        js-beautify -q -f $listaArq -r > /dev/null
    fi
fi