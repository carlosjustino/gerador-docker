#!/bin/bash

# ABORT EXECUTION WITH CTRL + C
trap ctrl_c INT

function ctrl_c() {
	echo '--> '
	echo "--> Encerrando processo..."
	echo '--> '
	exit 1
}

# SHELL OPTIONS
for c in $*
do
  if [ "$c" = "--indent" ] || [ "$c" = "-i" ]; then
		if command -v js-beautify >/dev/null 2>&1 2>/dev/null; then
			indent=true
		fi
	fi
done

source base.sh

STARTTIME5=$(date +%s)
echo '--> '
echo '--> Converte o XML de tela complexa para HTML, tela complexa View - telaComplexa2View.xsl'
echo '--> '

xslFile=$HOME_GEN/src/main/java/v2/telaComplexa2View.xsl
xmlFile=$HOME_GEN/target/xmlListTelaComplexa.xml
outFile=$HOME_GEN/target/htmlTelaComplexaView.lst
xmlListTelaSimplesCustomizada=$HOME_GEN/target/xmlListTelaSimplesCustomizada.xml
xmlClasses=$HOME_GEN/target/classes$PROJECT_NAME.xml
htmlTelaComplexaSourcePath=$HOME_JNG_URL/app/tpls

$JAVAEXEC -jar $HOME_SAXON/saxon9he.jar -xsl:$xslFile -s:$xmlFile -o:$outFile htmlTelaComplexaSourcePath=$htmlTelaComplexaSourcePath xmlClasses=$xmlClasses xmlListTelaSimplesCustomizada=$xmlListTelaSimplesCustomizada sistemaOperacional=$OS

if [ ! -z "$indent" ]; then
	echo '--> '
	echo '--> Identando arquivos HTML Tela Complexa - View'
	echo '--> '
	listaArq=''
	count=0
	for arquivo in `cat $HOME_GEN/target/htmlTelaComplexaView.lst`; do
	   ((count++))
	   listaArq="$listaArq $arquivo"
	   if [ $count -eq 100 ]; then
			js-beautify -q --type html -r -m 0 -f $listaArq > /dev/null &
			listaArq=''
			count=0
	   fi
	done
	js-beautify -q --type html -r -m 0 -f $listaArq > /dev/null &
fi

ENDTIME5=$(date +%s)
echo '--> '
echo "--> telaComplexa2View.xsl executou em $(($ENDTIME5 - $STARTTIME5)) segundos..."
echo '--> '
