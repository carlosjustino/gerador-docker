#!/bin/bash

# ABORT EXECUTION WITH CTRL + C
trap ctrl_c INT

function ctrl_c() {
	echo '--> '
	echo "--> Encerrando processo..."
	echo '--> '
	exit 1
}

source base.sh

STARTTIME=$(date +%s)

echo '--> '
echo '--> Gera classes Java dos testes unitarios - testeUnitario2java.xsl'
echo '--> '

xslFile=$HOME_GEN/src/main/java/v2/testeUnitario2java.xsl
xmlFile=$HOME_GEN/target/testeUnitario.xml
outFile=$HOME_GEN/target/unitTestFiles.lst
xmlClasses=$HOME_GEN/target/classes$PROJECT_NAME.xml
javaSourcePath=$HOME_REST_API_URL/src/test/java

$EXEC_XSL_SAXON -xsl:$xslFile -s:$xmlFile -o:$outFile javaSourcePath=$javaSourcePath xmlClasses=$xmlClasses

ENDTIME=$(date +%s)
echo '--> '
echo "--> testeUnitario2java.xsl executou em $(($ENDTIME - $STARTTIME)) segundos..."
echo '--> '
