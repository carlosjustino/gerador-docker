#!/bin/bash

# ABORT EXECUTION WITH CTRL + C
trap ctrl_c INT

function ctrl_c() {
	echo '--> '
	echo "--> Encerrando processo..."
	echo '--> '
	exit 1
}

source base.sh

STARTTIME=$(date +%s)

echo '--> '
echo '--> Converte o XML de tela complexa para Classes JAVA ListarPageObjects - telaComplexa2ListarPageObjects.xsl'
echo '--> '

xslFile=$HOME_GEN/src/main/java/v2/telaComplexa2ListarPageObjects.xsl
xmlFile=$HOME_GEN/target/xmlListTelaComplexa.xml
outFile=$HOME_GEN/target/listarPageObjects.lst
pageObjectsSourcePath=$HOME_PAGE_OBJECTS_URL
xmlRotinas=$HOME_GEN/target/xmlRotinas.xml
xmlClasses=$HOME_GEN/target/classes$PROJECT_NAME.xml
xmlListTelaSimplesCustomizada=$HOME_GEN/target/xmlListTelaSimplesCustomizada.xml

$EXEC_XSL_SAXON -xsl:$xslFile -s:$xmlFile -o:$outFile pageObjectsSourcePath=$pageObjectsSourcePath xmlClasses=$xmlClasses xmlRotinas=$xmlRotinas xmlListTelaSimplesCustomizada=$xmlListTelaSimplesCustomizada sistemaOperacional=$OS

ENDTIME=$(date +%s)
echo '--> '
echo "--> telaComplexa2ListarPageObjects.xsl executou em $(($ENDTIME - $STARTTIME)) segundos..."
echo '--> '
