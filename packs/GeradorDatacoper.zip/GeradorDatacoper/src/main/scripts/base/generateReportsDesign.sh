#!/bin/bash

# ABORT EXECUTION WITH CTRL + C
trap ctrl_c INT

function ctrl_c() {
	echo '--> '
	echo "--> Encerrando processo..."
	echo '--> '
	exit 1
}

source base.sh

# SHELL OPTIONS
for c in $*
do
  if [ "$c" = "--indent" ] || [ "$c" = "-i" ]; then
		if command -v js-beautify >/dev/null 2>&1 2>/dev/null; then
			indent=true
		fi
	fi
done

STARTTIME4=$(date +%s)
echo '--> '
echo '--> Converte o XML de tela complexa para report design - relatorio2Design.xsl'
echo '--> '

xslFile=$HOME_GEN/src/main/java/v2/relatorio2Design.xsl
xmlFile=$HOME_GEN/target/xmlListRelatorio.xml
outFile=$HOME_GEN/target/designRelatorio.lst
xmlClasses=$HOME_GEN/target/classes$PROJECT_NAME.xml
rptdesignSourcePath=$SVN_RPTDESIGN_URL

$EXEC_XSL_SAXON -xsl:$xslFile -s:$xmlFile -o:$outFile rptdesignSourcePath=$rptdesignSourcePath xmlClasses=$xmlClasses sistemaOperacional=$OS

ENDTIME4=$(date +%s)
echo '--> '
echo "--> relatorio2Design.xsl executou em $(($ENDTIME4 - $STARTTIME4)) segundos..."
echo '--> '
