#!/bin/bash

# ABORT EXECUTION WITH CTRL + C
trap ctrl_c INT

function ctrl_c() {
	echo '--> '
	echo "--> Encerrando processo..."
	echo '--> '
	exit 1
}

source base.sh

# SHELL OPTIONS
for c in $*
do
  if [ "$c" = "--indent" ] || [ "$c" = "-i" ]; then
		if command -v js-beautify >/dev/null 2>&1 2>/dev/null; then
			indent=true
		fi
	fi
done

STARTTIME=$(date +%s)

echo '--> '
echo '--> Converte o XML das funcoes de relatorios para JavaScript - relatorio2Javascript.xsl'
echo '--> '

xslFile=$HOME_GEN/src/main/java/v2/relatorio2Javascript.xsl
xmlFile=$HOME_GEN/target/xmlListRelatorio_sync.xml
outFile=$HOME_GEN/target/jsRelatorio.lst
javascriptSourcePath=$SVN_RPTDESIGN_URL/rptscripts
xmlClasses=$HOME_GEN/target/classes$PROJECT_NAME.xml
profileFile=C:/Apps/javascriptRelatorio.html

$EXEC_XSL_SAXON -xsl:$xslFile -s:$xmlFile -o:$outFile javascriptSourcePath=$javascriptSourcePath xmlClasses=$xmlClasses sistemaOperacional=$OS

if [ ! -z "$indent" ]; then
  echo '--> '
  echo '--> Identando arquivos JavaScripts'
  echo '--> '

  listaArq=''
  count=0
  for arquivo in `cat $HOME_GEN/target/jsRelatorio.lst`; do
     ((count++))
     listaArq="$listaArq $arquivo"
     if [ $count -eq 100 ]; then
  		js-beautify -q -f $listaArq -r > /dev/null &
  		listaArq=''
  		count=0
     fi
  done
  js-beautify -q -f $listaArq -r > /dev/null &
fi

ENDTIME=$(date +%s)
echo '--> '
echo "--> relatorio2Javascript.xsl executou em $(($ENDTIME - $STARTTIME)) segundos..."
echo '--> '
