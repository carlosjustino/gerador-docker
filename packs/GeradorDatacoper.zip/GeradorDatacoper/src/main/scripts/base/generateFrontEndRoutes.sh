#!/bin/bash

# ABORT EXECUTION WITH CTRL + C
trap ctrl_c INT

function ctrl_c() {
	echo '--> '
	echo "--> Encerrando processo..."
	echo '--> '
	exit 1
}

STARTTIME=$(date +%s)

source base.sh

echo '--> '
echo '--> Converte o dicionario de classes para route.jag - dicionario2routeJaggery.xsl'
echo '--> '

jngPath=$HOME_JNG_URL
xslFile=$HOME_GEN/src/main/java/v2/dicionario2routeJaggery.xsl
xmlFile=$HOME_GEN/target/classes$PROJECT_NAME.xml
outFile=$HOME_JNG/jaggery.conf

$EXEC_XSL_SAXON -xsl:$xslFile -s:$xmlFile -o:$outFile jngPath=$jngPath

ENDTIME=$(date +%s)
echo '--> '
echo "--> dicionario2routeJaggery.xsl executou em $(($ENDTIME - $STARTTIME)) segundos..."
echo '--> '
