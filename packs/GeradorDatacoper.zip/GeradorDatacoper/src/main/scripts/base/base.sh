#!/bin/bash

if [[ -e $MY_WORKSPACE ]]; then

   # CONFIG PROJECT PREFIX
   export PROJECT_NAME="AgroRevenda"

   export s="/"
   export MAPS="Mapas"
   export GEN="GeradorDatacoper"
   export APPS="Apps"
   export CORE="core"
   export GERADORSQL="GeradorSQL"
   export BUSINESS="business"
   export RESOURCES="resources"
   export JNG="JNG"
   export JNG_VERSION="1"
   export JNG_VERSION_PREFIX="_"

   # CONFIG DATABASE
   ### substituir bancoDados por DB_NAME
   export DB_NAME=agroRevendaDB

   # CONFIG LOGS ( true=sim / false=nao )
   export GENERATE_ERRORS="sim"

   # CONFIG BLOCK-UI ( true / false )
   export ACTIVATE_BLOCKUI="true"

   # CONFIG JVM
   export JAVAEXEC="java -Xms128m -Xmx2G "

   # CONFIG SAXON
   export SAXONEXEC="${HOME_SAXON}/saxon9he.jar"

   # CONFIG WORKSPACE
   subst_sys='s~\\~/~g'
   sedWorkspace=`sed -e $subst_sys <<< $MY_WORKSPACE`
   WORKSPACE=${sedWorkspace%%/${GEN}*}

   # CONFIG PROJECT VARS
   if [[ $WORKSPACE == *":"* ]]; then
     wpath=${WORKSPACE#*:}
     drive=${WORKSPACE%:*}
     driveLower="${drive,,}"
     CYGWORKSPACE=/cygdrive/$driveLower/$wpath
     export GEN_PROJECT=$CYGWORKSPACE/$GEN
     export SQL_PROJECT=$CYGWORKSPACE/$GERADORSQL
     export RESOURCE_PROJECT=$CYGWORKSPACE/resources
     export CORE_PROJECT=$CYGWORKSPACE/$CORE
     export BUSINESS_PROJECT=$CYGWORKSPACE/$BUSINESS
     export RESOURCES_PROJECT=$CYGWORKSPACE/$RESOURCES
	 export APPS_PROJECT=$CYGWORKSPACE/$APPS
   else
     export GEN_PROJECT=$WORKSPACE/$GEN
     export RESOURCE_PROJECT=$WORKSPACE/resources
     export CORE_PROJECT=$WORKSPACE/$CORE
     export BUSINESS_PROJECT=$WORKSPACE/$BUSINESS
     export RESOURCES_PROJECT=$WORKSPACE/$RESOURCES
	 export APPS_PROJECT=$WORKSPACE/$APPS
	 export SQL_PROJECT=$WORKSPACE/$GERADORSQL
   fi

   # CONFIG HOME VARS
   export HOME_GEN=$WORKSPACE$s$GEN
   export HOME_MINDMAPS=$WORKSPACE$s$MAPS
   export HOME_REST_API=$WORKSPACE$s$RESOURCES
   export HOME_JNG=$WORKSPACE$s$PROJECT_NAME$JNG
   export HOME_APPS=$WORKSPACE$s$APPS
   export HOME_ECLIPSE=`sed -e $subst_sys <<< $HOME_ECLIPSE`

   export HOME_BUSINESS=$WORKSPACE$s$BUSINESS
   export HOME_CORE=$WORKSPACE$s$CORE
   export HOME_GERADORSQL=$WORKSPACE$s$GERADORSQL

   # CONFIG DEPLOY VARS
   export WSO2_DEPLOY=$HOME_WSO2/repository/deployment/server
   export BACKEND_DEPLOY=$WSO2_DEPLOY/webapps
   export FRONTEND_DEPLOY=$WSO2_DEPLOY/jaggeryapps
   export REPORTS_DEPLOY=$WSO2_DEPLOY/webapps/birt/report

   # CONFIG FREEMIND IDE
   export HOME_FREEMIND_SRC=$HOME_FREEMIND/datacoper
   export HOME_FREEMIND_ICONS=$HOME_FREEMIND/icons

   # CONFIG SERVER
   export SERVER_DEPLOYMENT=${WSO2_DEPLOY}/webapps/${RESOURCES}
   export SERVER_TMP="${HOME_WSO2}/tmp"
   export SERVER_LOGS="${HOME_WSO2}/repository/logs"
   export SERVER_ERROR_LOGS="${HOME_WSO2}/hs*.log"
   export SERVER_ERROR_DUMPS="${HOME_WSO2}/*.mdmp"

   # CONFIG SVN VARS
   export SVN_JNG=`cd $HOME_JNG&&pwd`
   export SVN_RPTDESIGN=`cd $HOME_MINDMAPS/relatorios/rptdesign&&pwd`

   # ADD FILE TYPE
   if [[ "`uname | grep CYGWIN`" != "" ]]; then
      export OS="WINDOWS"
      export EXEC_XSL_SAXON="${JAVAEXEC} -jar -Dline.separator=$'\n' ${SAXONEXEC}"
      export EXEC_XSL_XALAN="${JAVAEXEC} -cp"
      export HOME_GEN_URL=file:///$HOME_GEN
      export HOME_JNG_URL=file:///$HOME_JNG
      export HOME_REST_API_URL=file:///$HOME_REST_API
	  export HOME_APPS_URL=file:///$HOME_APPS
	  export HOME_BUSINESS_URL=file:///$HOME_BUSINESS
	  export HOME_CORE_URL=file:///$HOME_CORE
	  export HOME_GERADORSQL_URL=file:///$HOME_GERADORSQL

      str_len=${#SVN_RPTDESIGN}
      export SVN_RPTDESIGN_URL=file:///$drive:${SVN_RPTDESIGN:11:str_len}

      # CONFIG PAGE OBJECTS
      if [ ! -z $HOME_PAGE_OBJECTS ]; then
        export HOME_PAGE_OBJECTS_URL=file:///$HOME_PAGE_OBJECTS
      fi

      if [ ! -z $HOME_TEST_PROJECT ]; then
        export HOME_TEST_PROJECT_URL=file:///$HOME_TEST_PROJECT
      fi
   else
      export OS="LINUX"
      export EXEC_XSL_SAXON="${JAVAEXEC} -jar ${SAXONEXEC}"
      export EXEC_XSL_XALAN="${JAVAEXEC} -cp"
      export HOME_GEN_URL=file://$HOME_GEN
      export HOME_JNG_URL=file://$HOME_JNG
      export HOME_REST_API_URL=file://$HOME_REST_API
      export SVN_RPTDESIGN_URL=file://$SVN_RPTDESIGN
	  export HOME_APPS_URL=file://$HOME_APPS
	  export HOME_BUSINESS_URL=file://$HOME_BUSINESS
	  export HOME_CORE_URL=file://$HOME_CORE
      export HOME_GERADORSQL_URL=file://$HOME_GERADORSQL

      # CONFIG PAGE OBJECTS
      if [ ! -z $HOME_PAGE_OBJECTS ]; then
        export HOME_PAGE_OBJECTS_URL=file://$HOME_PAGE_OBJECTS
      fi

      if [ ! -z $HOME_TEST_PROJECT ]; then
        export HOME_TEST_PROJECT_URL=file://$HOME_TEST_PROJECT
      fi
   fi

   # ETL
   export LOCALETL=$HOME_MINDMAPS/etl
   export LOCALETLWINDOWS=$HOME_MINDMAPS/etl

   #FREEMIND
   if [ ! -d "${HOME_FREEMIND_SRC}" ]; then
      export HOME_FREEMIND_SRC="${USERPROFILE}"/.freemind/datacoper
      export HOME_FREEMIND_ICONS="${USERPROFILE}"/.freemind/icons
   fi
else
   echo '[ERROR] Vari�veL MY_WORKSPACE n�o foi definida...'
   exit 1
fi
