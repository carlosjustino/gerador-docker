#!/bin/bash

# ABORT EXECUTION WITH CTRL + C
trap ctrl_c INT

function ctrl_c() {
	echo '--> '
	echo "--> Encerrando processo..."
	echo '--> '
	exit 1
}

STARTTIME=$(date +%s)

source base.sh

echo '--> '
echo "--> Deseja atualizar os mapas? (s/n)"
echo '--> '
read -n 1 -t 5 atualizar &&
echo ''
if [[ "${atualizar}" == "s" ||  "${atualizar}" == "S" ]]; then
   echo "--> Atualizando mapas..."
   cd $HOME_MINDMAPS&&svn update
else
   echo "--> Os mapas não foram atualizados"
fi

cd $HOME_GEN&&echo 'Atualizando '$HOME_GEN&&svn update
#cd $HOME_DOMAIN&&echo 'Atualizando '$HOME_DOMAIN&&svn update
cd $HOME_CORE&&echo 'Atualizando '$HOME_CORE&&svn update
cd $HOME_BUSINESS&&echo 'Atualizando '$HOME_BUSINESS&&svn update
cd $HOME_REST_API&&echo 'Atualizando '$HOME_REST_API&&svn update
cd $HOME_JNG&&echo 'Atualizando '$HOME_JNG&&svn update
cd $HOME_FREEMIND_SRC&&echo 'Atualizando '$HOME_FREEMIND_SRC&&svn update
cd $HOME_FREEMIND_ICONS&&echo 'Atualizando '$HOME_FREEMIND_ICONS&&svn update

ENDTIME=$(date +%s)
echo '--> '
echo "--> A atualização executou em $(($ENDTIME - $STARTTIME)) segundos..."
echo '--> '
