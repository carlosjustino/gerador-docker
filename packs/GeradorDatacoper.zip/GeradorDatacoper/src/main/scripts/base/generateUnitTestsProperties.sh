#!/bin/bash

# ABORT EXECUTION WITH CTRL + C
trap ctrl_c INT

function ctrl_c() {
	echo '--> '
	echo "--> Encerrando processo..."
	echo '--> '
	exit 1
}

source base.sh

STARTTIME=$(date +%s)

echo '--> '
echo '--> Gera arquivo properties dos testes unitarios - testeUnitario2properties.xsl'
echo '--> '

xslFile=$HOME_GEN/src/main/java/v2/testeUnitario2properties.xsl
xmlFile=$HOME_GEN/target/testeUnitario.xml
outFile=$HOME_GEN/target/var.properties

$EXEC_XSL_SAXON -xsl:$xslFile -s:$xmlFile -o:$outFile

ENDTIME=$(date +%s)
echo '--> '
echo "--> testeUnitario2properties.xsl executou em $(($ENDTIME - $STARTTIME)) segundos..."
echo '--> '
