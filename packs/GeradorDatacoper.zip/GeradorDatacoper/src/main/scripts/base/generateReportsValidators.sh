#!/bin/bash

# ABORT EXECUTION WITH CTRL + C
trap ctrl_c INT

function ctrl_c() {
	echo '--> '
	echo "--> Encerrando processo..."
	echo '--> '
	exit 1
}

source base.sh

# SHELL OPTIONS
for c in $*
do
  if [ "$c" = "--indent" ] || [ "$c" = "-i" ]; then
		if command -v js-beautify >/dev/null 2>&1 2>/dev/null; then
			indent=true
		fi
	fi
done

STARTTIME=$(date +%s)
echo '--> '
echo '--> Converte o XML de relatorio para JavaScript Validators - telaComplexa2Validators.xsl'
echo '--> '

xslFile=$HOME_GEN/src/main/java/v2/telaComplexa2Validators.xsl
xmlFile=$HOME_GEN/target/xmlListRelatorio_sync.xml
outFile=$HOME_GEN/target/vltRelatorio.lst
validatorsSourcePath=$HOME_JNG_URL/app/validators
xmlClasses=$HOME_GEN/target/classes$PROJECT_NAME.xml

$EXEC_XSL_SAXON -xsl:$xslFile -s:$xmlFile -o:$outFile validatorsSourcePath=$validatorsSourcePath xmlClasses=$xmlClasses sistemaOperacional=$OS ativarBlockUI=$ACTIVATE_BLOCKUI

if [ ! -z "$indent" ]; then
  echo '--> '
  echo '--> Identando arquivos JavaScripts'
  echo '--> '

  listaArq=''
  for arquivo in `cat $HOME_GEN/target/vltRelatorio.lst`;
  do
     listaArq="$listaArq $arquivo"
  done
  js-beautify -q -f $listaArq -r
fi

ENDTIME=$(date +%s)
echo '--> '
echo "--> telaComplexa2Validators.xsl executou em $(($ENDTIME - $STARTTIME)) segundos..."
echo '--> '
