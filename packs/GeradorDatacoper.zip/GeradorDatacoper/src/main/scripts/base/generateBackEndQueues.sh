#!/bin/bash

# ABORT EXECUTION WITH CTRL + C
trap ctrl_c INT

function ctrl_c() {
	echo '--> '
	echo "--> Encerrando processo..."
	echo '--> '
	exit 1
}

STARTTIME=$(date +%s)

source base.sh

indent=false
for c in $*
do
  if [ "$c" = "--target" ]; then
    CMD="--target"
    continue
  elif [ "$CMD" = "--target" ]; then
    unset CMD
    target=$c
  elif [ "$c" = "--indent" ] || [ "$c" = "-i" ]; then
    CMD="--indent"
    continue
  elif [ "$CMD" = "--indent" ]; then
    unset CMD
    indent=$c
  fi
done

echo '--> '
echo '--> Converte o dicionario para codigo java, FILAS - dicionario2queue.xsl'
echo '--> '

javaSourcePath=$HOME_APPS_URL
xslFile=$HOME_GEN/src/main/java/v2/dicionario2queue.xsl
xmlFile=$HOME_GEN/target/classes$PROJECT_NAME.xml
outFile=$HOME_TEMP/queueSource.lst

$EXEC_XSL_SAXON -xsl:$xslFile -s:$xmlFile -o:$outFile javaSourcePath=$javaSourcePath sistemaOperacional=$OS classeAlvo=$target
if [ $? -ne 0 ]; then
   exit 1
fi

ENDTIME=$(date +%s)
echo '--> '
echo "--> dicionario2queue.xsl executou em $(($ENDTIME - $STARTTIME)) segundos..."
echo '--> '
