package com.datacoper.gerador.dictionary;

import com.datacoper.gerador.GenUtility;
import com.datacoper.gerador.Manager;
import com.datacoper.gerador.Processor;
import com.datacoper.gerador.Transformation;
import org.apache.commons.io.FileUtils;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.events.Attribute;
import javax.xml.stream.events.StartElement;
import javax.xml.stream.events.XMLEvent;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;
import java.io.File;
import java.io.FileInputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

public class GenClassMapDictionary implements Transformation {

   private String mapTarget = "ND" ;
   private boolean concluido = false;
    public GenClassMapDictionary(String maps){
        this.mapTarget = maps;
    }


    @Override
    public void doTransformation() throws Exception {
           doTransformationClassMaps();
    }


    private void doTransformationClassMaps() throws Exception {

        String xsltFile = GenUtility.HOME_GEN + "/src/main/java/v2/mm2classList.xsl";
        String xmlFile=System.getenv("HOME_MINDMAPS") + "/"+ GenUtility.PROJECT_NAME +".mm";
        String outFile= GenUtility.HOME_GEN + "/target/classesGear"+ GenUtility.PROJECT_NAME+".xml";

        StringBuilder sbParam = new StringBuilder();
        sbParam.append("mapas=");
        sbParam.append(mapTarget);
        sbParam.append(" ");
        sbParam.append("mapaPrincipal=");
        sbParam.append(GenUtility.PROJECT_NAME +".mm");
        new Processor().run(xsltFile,xmlFile,outFile,sbParam.toString());
        concluido = true;
    }

    public String getListClass() throws Exception {
        StringBuilder retorno = new StringBuilder();
        if (!concluido) doTransformationClassMaps();

        String outFile= GenUtility.HOME_GEN + "/target/classesGear"+ GenUtility.PROJECT_NAME+".xml";
        DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
        Document doc = builder.parse(outFile);

        XPathFactory xpathFactory = XPathFactory.newInstance();

        XPathExpression expr =
                xpathFactory.newXPath().compile("/classes/classe");
        NodeList nodes = (NodeList) expr.evaluate(doc, XPathConstants.NODESET);
        for (int i = 0; i < nodes.getLength(); i++) {
            retorno.append(nodes.item(i).getAttributes().getNamedItem("nome").getNodeValue());
            if (i +1 < nodes.getLength()) retorno.append(",");
        }
        return retorno.toString();
    }


}
