package com.datacoper.gerador.dictionary;

import com.datacoper.gerador.GenUtility;
import com.datacoper.gerador.Processor;
import com.datacoper.gerador.Transformation;

import java.nio.file.Files;
import java.nio.file.Paths;

public class GenUsingMap implements Transformation {

   private String target = "ND" ;


    public GenUsingMap(String target){
        if (target != null) this.target = target;
    }


    @Override
    public void doTransformation() throws Exception {

        if (target==null || target.equals("ND")){
           throw new RuntimeException("Faltou parametro --target");
        }
        doTransformationUsingMap();
    }

    private void doTransformationUsingMap() throws Exception{
        String xsltFile = GenUtility.HOME_GEN + "/src/main/java/v2/dicionario2mapaUtilizacao.xsl";
        String xmlFile=GenUtility.XML_CLASSES;
        String outFile= GenUtility.HOME_GEN + "/target/" + GenUtility.PROJECT_NAME+".usingMap.aux.mm";
        String pathXml=System.getenv("HOME_GEN_URL") + "/target/xmlClasses";

        String mapaGerado=  GenUtility.HOME_GEN + "/target/UsingMap.mm";
        String strMapa = "<map version=\"1.0.1\"><node TEXT=\"GERANDO MAPA\"><node TEXT=\"AGUARDE\"></node></node></map>";
        Files.write(Paths.get(mapaGerado), strMapa.getBytes());

        StringBuilder sbParam = new StringBuilder();
        sbParam.append("buscarPor=");
        sbParam.append(target);
        sbParam.append(" ");
        sbParam.append("pathXml=");
        sbParam.append(pathXml);
        new Processor().run(xsltFile,xmlFile,outFile,sbParam.toString());

        GenUtility.moveFile(outFile, mapaGerado);

    }



}
