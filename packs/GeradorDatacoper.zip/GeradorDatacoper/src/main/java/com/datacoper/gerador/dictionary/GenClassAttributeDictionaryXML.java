package com.datacoper.gerador.dictionary;

import com.datacoper.bean.ClasseAtributoTipo;
import com.datacoper.gerador.ConfigUtils;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class GenClassAttributeDictionaryXML {

    private List<ClasseAtributoTipo> listaClasseAtributoTipo = new ArrayList<>();

    public GenClassAttributeDictionaryXML(List<ClasseAtributoTipo> listaClasseAtributoTipo) {
        this.listaClasseAtributoTipo = listaClasseAtributoTipo;
    }

    public void gravaDicionarioEmDisco(String path) throws IOException {
        String xml = geraXMLDicionarioDeDados();

        gravaArquivoDicionarioTipoDeDadosEmDisco(xml, path);
    }

    private void gravaArquivoDicionarioTipoDeDadosEmDisco(String xml, String fileName) throws IOException {
        BufferedWriter writer = new BufferedWriter(new FileWriter(ConfigUtils.getInstance().getNormalizedPath(fileName)));
        writer.write(xml);
        writer.close();
    }

    private String geraXMLDicionarioDeDados() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("<classes>");
        Map<String, List<ClasseAtributoTipo>> listaClasseAtributoTipoAgrupado =
                listaClasseAtributoTipo.stream().collect(Collectors.groupingBy(w -> w.getNomeClasseCompleto()));

        listaClasseAtributoTipoAgrupado.entrySet().forEach(classe -> {
            stringBuilder.append(geraXMLDicionarioDeDadosClasse(classe));
        });

        stringBuilder.append("</classes>");
        return stringBuilder.toString();
    }

    private String geraXMLDicionarioDeDadosClasse(Map.Entry<String, List<ClasseAtributoTipo>> classe) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("<classe");

        stringBuilder.append(" nome=\"");
        stringBuilder.append(classe.getValue().get(0).getNomeClasse());
        stringBuilder.append("\"");

        stringBuilder.append(" pacote=\"");
        stringBuilder.append(classe.getValue().get(0).getNomePacote());
        stringBuilder.append("\"");

        stringBuilder.append(">");

        stringBuilder.append("<atributos>");
        classe.getValue().forEach(cat -> stringBuilder.append(geraXMLDicionarioDadosClasseAtributo(cat)));
        stringBuilder.append("</atributos>");

        stringBuilder.append("</classe>");

        return stringBuilder.toString();
    }

    private String geraXMLDicionarioDadosClasseAtributo(ClasseAtributoTipo cat) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("<atributo");

        stringBuilder.append(" nome=\"");
        stringBuilder.append(cat.getNomeAtributo());
        stringBuilder.append("\"");

        stringBuilder.append(" tipo=\"");
        stringBuilder.append(cat.getTipoAtributo());
        stringBuilder.append("\"");

        //stringBuilder.append(" tipoJava=\"");
        //stringBuilder.append(cat.getTipoAtributoJava());
        //stringBuilder.append("\"");

        stringBuilder.append(">");

        stringBuilder.append("</atributo>");

        return stringBuilder.toString();
    }

}
