package com.datacoper.gerador.backend;

import com.datacoper.gerador.Processor;
import com.datacoper.gerador.Transformation;

import java.util.concurrent.Callable;

import static com.datacoper.gerador.GenUtility.HOME_GEN;
import static com.datacoper.gerador.GenUtility.XML_CLASSES;

public class GenBackEndConstructors implements Transformation , Callable<Transformation> {

    String target = "ND";

    public GenBackEndConstructors(String target){
        if (target != null) this.target = target;
    }


    @Override
    public void doTransformation() throws Exception {
        doTransformationBackEndConstructors();
    }

    private void doTransformationBackEndConstructors() throws Exception{

        String javaSourcePath=System.getenv("HOME_BUSINESS_URL") + "/src/main/java";

        String xsltFile = HOME_GEN + "/src/main/java/v2/dicionario2constructor.xsl";
        String xmlFile=XML_CLASSES;
        String outFile=System.getenv("HOME_TEMP") + "/constructorSource.lst";
        String pathXml=System.getenv("HOME_GEN_URL") + "/target/xmlClasses";

        StringBuilder sbParam = new StringBuilder();
        sbParam.append("javaSourcePath=");
        sbParam.append(javaSourcePath);
        sbParam.append(" ");
        sbParam.append("sistemaOperacional=");
        sbParam.append(System.getenv("OS"));
        sbParam.append(" ");
        sbParam.append("classeAlvo=");
        sbParam.append(target);
        sbParam.append(" ");
        sbParam.append("pathXml=");
        sbParam.append(pathXml);
        new Processor().run(xsltFile,xmlFile,outFile,sbParam.toString());

    }

    @Override
    public Transformation call() throws Exception {
        doTransformation();
        return this;
    }
}
