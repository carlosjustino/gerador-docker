package com.datacoper.gerador.thread;

import net.sf.saxon.expr.XPathContext;
import net.sf.saxon.om.Item;
import net.sf.saxon.om.NodeInfo;
import net.sf.saxon.trans.XPathException;

import java.util.Arrays;
import java.util.concurrent.*;

public class DCFixedThreadPool extends ThreadPoolExecutor {

    public DCFixedThreadPool(int nThreads){
        this(nThreads, nThreads,
                0L, TimeUnit.MILLISECONDS,
                new LinkedBlockingQueue<Runnable>());
    }

    public DCFixedThreadPool(int corePoolSize, int maximumPoolSize, long keepAliveTime,
                             TimeUnit unit, BlockingQueue<Runnable> workQueue) {
        super(corePoolSize, maximumPoolSize, keepAliveTime, unit, workQueue);
    }

    @Override
    public void afterExecute(Runnable r, Throwable t) {
        super.afterExecute(r, t);

        if (t == null && r instanceof Future<?>) {
            try {
                Object result = ((Future<?>) r).get();
            } catch (CancellationException e) {
                t = e;
            } catch (ExecutionException e) {
                t = e.getCause();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            } catch (Exception e) {
                t = e;
            }
        }
        if (t != null) {
            System.err.println("[ERRO] - Erro na execucao da fila de Thread! " );
            if (!printXPathException(t, false)){
                t.printStackTrace();
            }
            System.exit(1);
        }
    }

    boolean printXPathException(Throwable t, boolean segundaVez){
        boolean gerouSaida = false;
        if (t instanceof XPathException) {
            gerouSaida = true;
            XPathException xPathException = ((XPathException) t);
            XPathContext cxt = xPathException.getXPathContext();
            if (cxt != null) {
                System.err.println("ErrorCode: " +                 cxt.getCurrentException().getErrorCodeLocalPart());
                System.err.println("ErrorCodeQName: " +                 cxt.getCurrentException().getErrorCodeQName());
                System.err.println("ErrorCodeNamespace: " +                 cxt.getCurrentException().getErrorCodeNamespace());
                System.err.println("ErrorObject: " +                 cxt.getCurrentException().getErrorObject());
                System.err.println("HostLanguage: " +                 cxt.getCurrentException().getHostLanguage());
                Item item = cxt == null ? null : cxt.getContextItem();
                if (item instanceof NodeInfo) {
                    System.err.println("Line Error: " +  ((NodeInfo) item).getLineNumber());
                }
                cxt.getCurrentException().printStackTrace();
            } else{
                System.err.println("LocalizedMessage: " +  xPathException.getLocalizedMessage());
                System.err.println("Message: " +  xPathException.getMessage());
                if (xPathException.getLocator() != null) {
                    System.err.println("ColumnNumber: " + xPathException.getLocator().getColumnNumber());
                    System.err.println("LineNumber: " + xPathException.getLocator().getLineNumber());
                    System.err.println("PublicID: " + xPathException.getLocator().getPublicId());
                    System.err.println("SystemID: " + xPathException.getLocator().getSystemId());
                }
                if (xPathException.getErrorCodeLocalPart() != null) System.err.println("ErrorCode: " +  xPathException.getErrorCodeLocalPart());
                if (xPathException.getErrorCodeQName() != null) System.err.println("ErrorCodeQName: " +  xPathException.getErrorCodeQName());
                if (xPathException.getErrorCodeNamespace() != null) System.err.println("ErrorCodeNamespace: " +  xPathException.getErrorCodeNamespace());
                if (xPathException.getErrorObject() != null) System.err.println("ErrorObject: " +  xPathException.getErrorObject());
                if (xPathException.getHostLanguage() != null) System.err.println("HostLanguage: " +  xPathException.getHostLanguage());
                xPathException.printStackTrace();
                printXPathException(xPathException.getCause(), true);
            }
        } else {
            if (!segundaVez) gerouSaida = printXPathException(t.getCause(), true);
        }
        return gerouSaida;
    }
}
