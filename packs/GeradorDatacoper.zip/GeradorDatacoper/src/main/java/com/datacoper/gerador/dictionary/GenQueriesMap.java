package com.datacoper.gerador.dictionary;

import com.datacoper.gerador.GenUtility;
import com.datacoper.gerador.Processor;
import com.datacoper.gerador.Transformation;

import java.nio.file.Files;
import java.nio.file.Paths;

public class GenQueriesMap implements Transformation {

   private String target = "ND" ;


    public GenQueriesMap(String target){
        if (target != null) this.target = target;
    }


    @Override
    public void doTransformation() throws Exception {

        doTransformationQueriesMap();
    }

    private void doTransformationQueriesMap() throws Exception{
        String xsltFile = GenUtility.HOME_GEN + "/src/main/java/v2/dicionario2testeConsultas.xsl";
        String xmlFile=GenUtility.XML_CLASSES;
        String outFile= GenUtility.HOME_GEN + "/target/" + GenUtility.PROJECT_NAME+".queriesMap.aux.mm";

        String mapaGerado=  GenUtility.HOME_GEN + "/target/QueriesMap.mm";
        String strMapa = "<map version=\"1.0.1\"><node TEXT=\"GERANDO MAPA\"><node TEXT=\"AGUARDE\"></node></node></map>";
        Files.write(Paths.get(mapaGerado), strMapa.getBytes());

        StringBuilder sbParam = new StringBuilder();
        sbParam.append("classeAlvo=");
        sbParam.append(target);
        new Processor().run(xsltFile,xmlFile,outFile,sbParam.toString());

        GenUtility.moveFile(outFile, mapaGerado);

    }



}
