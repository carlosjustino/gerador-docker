package com.datacoper.bean;

import java.util.AbstractMap;
import java.util.List;

public class Pacote {

    private String link;
    private String simpleName;
    private String compoundName;
    private List<AbstractMap.SimpleEntry> classes;

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getSimpleName() {
        return simpleName;
    }

    public void setSimpleName(String simpleName) {
        this.simpleName = simpleName;
    }

    public String getCompoundName() {
        return compoundName;
    }

    public void setCompoundName(String compoundName) {
        this.compoundName = compoundName;
    }

    public List<AbstractMap.SimpleEntry> getClasses() {
        return classes;
    }

    public void setClasses(List<AbstractMap.SimpleEntry> classes) {
        this.classes = classes;
    }
}
