package com.datacoper.gerador.backend;

import com.datacoper.gerador.Processor;
import com.datacoper.gerador.Transformation;

import java.util.concurrent.Callable;

import static com.datacoper.gerador.GenUtility.HOME_GEN;
import static com.datacoper.gerador.GenUtility.XML_CLASSES;

public class GenBackEndRestApiManager implements Transformation, Callable<Transformation> {

    String target = "ND";

    public GenBackEndRestApiManager(String target){
        if (target != null) this.target = target;
    }


    @Override
    public void doTransformation() throws Exception {
        doTransformationBackEndRest();
    }

    private void doTransformationBackEndRest() throws Exception{

        String pathXml=System.getenv("HOME_GEN_URL") + "/target/xmlApiManager";

        String xsltFile = HOME_GEN + "/src/main/java/v2/dicionario2restApiManager.xsl";
        String xmlFile=XML_CLASSES;
        String outFile=System.getenv("HOME_TEMP") + "/restApiManagerSource.lst";

        StringBuilder sbParam = new StringBuilder();
        sbParam.append("pathXml=");
        sbParam.append(pathXml);
        
        sbParam.append(" ");
        sbParam.append("sistemaOperacional=");
        sbParam.append(System.getenv("OS"));
        sbParam.append(" ");
        sbParam.append("classeAlvo=");
        sbParam.append(target);
        new Processor().run(xsltFile,xmlFile,outFile,sbParam.toString());

    }


    @Override
    public Transformation call() throws Exception {
        doTransformation();
        return this;
    }
}
