package com.datacoper.gerador.dictionary;

import com.datacoper.gerador.Processor;
import com.datacoper.gerador.Transformation;

import static com.datacoper.gerador.GenUtility.HOME_GEN;
import static com.datacoper.gerador.GenUtility.XML_CLASSES;

public class GenUnitTestsDictionary implements Transformation {


    public GenUnitTestsDictionary(){
    }


    @Override
    public void doTransformation() throws Exception {
        doTransformationUnitTestsDictionary();
    }


    private void doTransformationUnitTestsDictionary() throws Exception{
        String xsltFile = HOME_GEN + "/src/main/java/v2/mm2testeUnitario.xsl";
        String xmlFile=XML_CLASSES;
        String outFile=HOME_GEN + "/target/testeUnitario.xml";

        String testesSourcePath= System.getenv("HOME_GEN_URL") + "/target/testes";
        String mapasSourcePath=System.getenv("HOME_MINDMAPS");

        StringBuilder sbParam = new StringBuilder();
        sbParam.append("testesSourcePath=");
        sbParam.append(testesSourcePath);
        sbParam.append(" ");
        sbParam.append("mapasSourcePath=");
        sbParam.append(mapasSourcePath);
        sbParam.append(" ");
        sbParam.append("xmlClasses=");
        sbParam.append(XML_CLASSES);

        new Processor().run(xsltFile,xmlFile,outFile,sbParam.toString());

    }


}
