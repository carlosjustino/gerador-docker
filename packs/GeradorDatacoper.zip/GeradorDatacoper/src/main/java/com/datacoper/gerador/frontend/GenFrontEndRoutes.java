package com.datacoper.gerador.frontend;

import com.datacoper.gerador.GenUtility;
import com.datacoper.gerador.Processor;
import com.datacoper.gerador.Transformation;

import java.util.concurrent.Callable;

public class GenFrontEndRoutes implements Transformation  , Callable<Transformation> {

    public GenFrontEndRoutes(){
    }

    @Override
    public void doTransformation() throws Exception {
        doTransformationRouteJaggery();
    }

    @Override
    public Transformation call() throws Exception {
        doTransformation();
        return this;
    }

    private void doTransformationRouteJaggery() throws Exception{
        String xslFile = GenUtility.HOME_GEN + "/src/main/java/v2/dicionario2routeJaggery.xsl";
        String xmlFile = GenUtility.XML_CLASSES;
        String outFile = GenUtility.HOME_JNG + "/jaggery.conf";

        String jngPath = System.getenv("HOME_JNG_URL");

        StringBuilder sbParam = new StringBuilder();
        sbParam.append("jngPath=");
        sbParam.append(jngPath);

        new Processor().run(xslFile,xmlFile,outFile,sbParam.toString());

    }

}
