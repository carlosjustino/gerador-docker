package com.datacoper.gerador.dictionary;

import com.datacoper.gerador.GenUtility;
import com.datacoper.gerador.Processor;
import com.datacoper.gerador.Transformation;

import java.nio.file.Files;
import java.nio.file.Paths;

public class GenTemplateReferenceMap implements Transformation {

   private String target = "ND" ;


    public GenTemplateReferenceMap(String target){
        if (target != null) this.target = target;
    }


    @Override
    public void doTransformation() throws Exception {

        if (target==null || target.equals("ND")){
           throw new RuntimeException("Faltou parametro --target");
        }
        doTransformationTemplateReferenceMap();


    }


    private void doTransformationTemplateReferenceMap() throws Exception{

        String xsltFile = GenUtility.HOME_GEN + "/src/main/java/v2/mm2dicionario.xsl";
        String xmlFile=System.getenv("HOME_MINDMAPS") + "/"+ GenUtility.PROJECT_NAME +".mm";
        String outFile= GenUtility.HOME_GEN + "/target/" + GenUtility.PROJECT_NAME+".classeTemplates.mm";
        String pathXml=System.getenv("HOME_GEN_URL") + "/target/xmlClasses";

        String mapaGerado=  "/target/classe_" + target +".templates.mm";
        String strMapa = "<map version=\"1.0.1\"><node TEXT=\"GERANDO MAPA\"><node TEXT=\"AGUARDE\"></node></node></map>";
        Files.write(Paths.get(GenUtility.HOME_GEN +mapaGerado), strMapa.getBytes());

        StringBuilder sbParam = new StringBuilder();
        sbParam.append("padroesFileName=");
        sbParam.append(GenUtility.XML_PADROES);
        sbParam.append(" ");
        sbParam.append("tiposFileName=");
        sbParam.append(GenUtility.XML_TIPODADOS);
        sbParam.append(" ");
        sbParam.append("geraErros=");
        sbParam.append(System.getenv("GENERATE_ERRORS"));
        sbParam.append(" ");
        sbParam.append("classeAlvo=");
        sbParam.append(target);
        sbParam.append(" ");
        sbParam.append("pathXml=");
        sbParam.append(pathXml);
        sbParam.append(" ");
        sbParam.append("geraMapaTemplatesParaClasseAlvo=");
        sbParam.append("S");
        sbParam.append(" ");
        sbParam.append("mapaGerado=");
        sbParam.append(System.getenv("HOME_GEN_URL") + mapaGerado);
        new Processor().run(xsltFile,xmlFile,outFile,sbParam.toString());

    }



}
