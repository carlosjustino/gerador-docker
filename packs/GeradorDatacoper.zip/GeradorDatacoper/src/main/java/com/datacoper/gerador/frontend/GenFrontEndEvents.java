package com.datacoper.gerador.frontend;

import com.datacoper.gerador.Processor;
import com.datacoper.gerador.Transformation;

import java.util.concurrent.Callable;

import static com.datacoper.gerador.GenUtility.HOME_GEN;
import static com.datacoper.gerador.GenUtility.XML_CLASSES;

public class GenFrontEndEvents implements Transformation  , Callable<Transformation> {

    public GenFrontEndEvents(){
    }

    @Override
    public void doTransformation() throws Exception {
        doTransformationTelaComplexaEvents();
    }

    @Override
    public Transformation call() throws Exception {
        doTransformation();
        return this;
    }

    private void doTransformationTelaComplexaEvents() throws Exception{

        String xslFile= HOME_GEN + "/src/main/java/v2/telaComplexa2Events.xsl";
        String xmlFile= HOME_GEN + "/target/xmlListTelaComplexa_sync.xml";
        String outFile= HOME_GEN + "/target/evtTelaComplexa.lst";

        String eventsSourcePath= System.getenv("HOME_JNG_URL") + "/app/events";


        StringBuilder sbParam = new StringBuilder();
        sbParam.append("eventsSourcePath=");
        sbParam.append(eventsSourcePath);
        sbParam.append(" ");
        sbParam.append("xmlClasses=");
        sbParam.append(XML_CLASSES);
        sbParam.append(" ");
        sbParam.append("sistemaOperacional=");
        sbParam.append(System.getenv("OS"));
        sbParam.append(" ");
        sbParam.append("ativarBlockUI=");
        sbParam.append(System.getenv("ACTIVATE_BLOCKUI"));


        new Processor().run(xslFile,xmlFile,outFile,sbParam.toString());

    }

}
