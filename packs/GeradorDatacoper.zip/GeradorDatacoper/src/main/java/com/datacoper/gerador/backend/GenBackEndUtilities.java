package com.datacoper.gerador.backend;

import com.datacoper.gerador.*;
import com.datacoper.gerador.Processor;
import com.datacoper.gerador.thread.DCFixedThreadPool;
import net.sf.saxon.s9api.*;

import javax.xml.transform.stream.StreamSource;
import java.io.File;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;

import static com.datacoper.gerador.GenUtility.HOME_GEN;
import static com.datacoper.gerador.GenUtility.XML_CLASSES;

public class GenBackEndUtilities implements Transformation, Callable<Transformation> {

    String target = "ND";

    public GenBackEndUtilities(String target){
        if (target != null) this.target = target;
    }

    @Override
    public void doTransformation() throws Exception {
        if (target != null && !target.equals("ND")) doTransformationBackEndUtilities(target);
        else doTransformationBackEndUtilitiesThread();
    }

    private void doTransformationBackEndUtilitiesThread() throws Exception{
        ExecutorService executorBackEnd = new DCFixedThreadPool(10);

        net.sf.saxon.s9api.Processor processor = new net.sf.saxon.s9api.Processor(false);

        XsltCompiler compiler = processor.newXsltCompiler();

        compiler.setErrorListener(new DatacoperSaxonErrorListener());
        compiler.setGenerateByteCode(true);
        compiler.setTargetEdition("HE");

        XdmNode doc = processor.newDocumentBuilder().build(new StreamSource(new File(XML_CLASSES)));
        XdmSequenceIterator iter = doc.axisIterator(Axis.DESCENDANT, new QName("classe"));
        String javaSourcePath=System.getenv("HOME_BUSINESS_URL") + "/src/main/java";

        String xsltFile = HOME_GEN + "/src/main/java/v2/dicionario2utility.xsl";
        String xmlFile=XML_CLASSES;

        String pathXml=System.getenv("HOME_GEN_URL") + "/target/xmlClasses";



        GenUtility.printInfo("Inicio " + GenUtility.currentDateTime() + " ["+ GenUtility.getNomeArquivoXslt(xsltFile) +"]");
        long tempoInicial = System.currentTimeMillis();

        File sourceFile = new File(xsltFile);
        StreamSource streamSource = new StreamSource(sourceFile);
        streamSource.setSystemId(sourceFile);
        XsltExecutable exp = compiler.compile(streamSource);
        XdmNode source = processor.newDocumentBuilder().build(new StreamSource(new File(xmlFile)));

        while (iter.hasNext()) {
            XdmNode classe = (XdmNode) iter.next();
            String classetarget = classe.getAttributeValue(new QName("nome"));

            executorBackEnd.execute(new Runnable() {
                                        @Override
                                        public void run() {
                                            try {
                                                Xslt30Transformer trans = exp.load30();
                                                Map<QName, XdmValue> params = new HashMap<>();
                                                trans.setGlobalContextItem(source);
                                                String outFile=System.getenv("HOME_TEMP") + "/utilitySource"+classetarget+".lst";
                                                Serializer out = processor.newSerializer(new File(outFile));
                                                StringBuilder sbParam = new StringBuilder();
                                                sbParam.append("javaSourcePath=");
                                                sbParam.append(javaSourcePath);
                                                sbParam.append(" ");
                                                sbParam.append("sistemaOperacional=");
                                                sbParam.append(System.getenv("OS"));
                                                sbParam.append(" ");
                                                sbParam.append("classeAlvo=");
                                                sbParam.append(classetarget);
                                                sbParam.append(" showInfo=NAO ");
                                                sbParam.append("pathXml=");
                                                sbParam.append(pathXml);
                                                if (sbParam != null && !sbParam.toString().equals("")){
                                                    String[] pars =sbParam.toString().split(" ");
                                                    for (int x=0 ; x < pars.length; x++){
                                                        String param = pars[x].substring(0, pars[x].indexOf("="));
                                                        String value = pars[x].substring(pars[x].indexOf("=") + 1);
                                                        XdmValue v = new XdmAtomicValue(value);
                                                        QName name = new QName(param);
                                                        params.put(name,v);
                                                    }
                                                    trans.setStylesheetParameters(params);
                                                }
                                                trans.applyTemplates(source,out);
                                            } catch (Exception e) {
                                                e.printStackTrace();
                                                System.exit(1);
                                            }
                                        }
                                    });
        }

        executorBackEnd.shutdown();
        while (!executorBackEnd.isTerminated()) {
            Thread.sleep(10);
        }
        long tempoFinal = System.currentTimeMillis();
        System.out.printf("--- Tempo total ["+ GenUtility.getNomeArquivoXslt(xsltFile) +"]: %.3f ms%n", (tempoFinal - tempoInicial) / 1000d);
    }



    private void doTransformationBackEndUtilities(String target) throws Exception{

        String javaSourcePath=System.getenv("HOME_BUSINESS_URL") + "/src/main/java";

        String xsltFile = HOME_GEN + "/src/main/java/v2/dicionario2utility.xsl";
        String xmlFile=XML_CLASSES;
        String outFile=System.getenv("HOME_TEMP") + "/utilitySource.lst";
        String pathXml=System.getenv("HOME_GEN_URL") + "/target/xmlClasses";

        StringBuilder sbParam = new StringBuilder();
        sbParam.append("javaSourcePath=");
        sbParam.append(javaSourcePath);
        sbParam.append(" ");
        sbParam.append("sistemaOperacional=");
        sbParam.append(System.getenv("OS"));
        sbParam.append(" ");
        sbParam.append("classeAlvo=");
        sbParam.append(target);
        sbParam.append(" ");
        sbParam.append("pathXml=");
        sbParam.append(pathXml);
        new Processor().run(xsltFile,xmlFile,outFile,sbParam.toString());

    }


    @Override
    public GenBackEndUtilities call() throws Exception {
        doTransformation();
        return this;
    }
}
