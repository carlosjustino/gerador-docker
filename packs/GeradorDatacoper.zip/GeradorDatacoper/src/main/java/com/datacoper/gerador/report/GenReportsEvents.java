package com.datacoper.gerador.report;

import com.datacoper.gerador.Processor;
import com.datacoper.gerador.Transformation;

import static com.datacoper.gerador.GenUtility.HOME_GEN;
import static com.datacoper.gerador.GenUtility.XML_CLASSES;

public class GenReportsEvents implements Transformation {


    public GenReportsEvents(){

    }

    @Override
    public void doTransformation() throws Exception {
        doTransformationReportEvents();
    }

    private void doTransformationReportEvents() throws Exception{
        String xslFile= HOME_GEN + "/src/main/java/v2/telaComplexa2Events.xsl";
        String xmlFile= HOME_GEN + "/target/xmlListRelatorio_sync.xml";
        String outFile= HOME_GEN + "/target/evtRelatorio.lst";
        String eventsSourcePath=System.getenv("HOME_JNG_URL") + "/app/events";

        StringBuilder sbParam = new StringBuilder();
        sbParam.append("eventsSourcePath=");
        sbParam.append(eventsSourcePath);
        sbParam.append(" ");
        sbParam.append("xmlClasses=");
        sbParam.append(XML_CLASSES);
        sbParam.append(" ");
        sbParam.append("sistemaOperacional=");
        sbParam.append(System.getenv("OS"));
        sbParam.append(" ");
        sbParam.append("ativarBlockUI=");
        sbParam.append(System.getenv("ACTIVATE_BLOCKUI"));

        new Processor().run(xslFile,xmlFile,outFile,sbParam.toString());

    }

}
