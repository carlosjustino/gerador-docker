package com.datacoper.gerador.dictionary;

import com.datacoper.gerador.GenUtility;
import com.datacoper.gerador.Processor;
import com.datacoper.gerador.Transformation;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;

public class GenFrontEndReportsDictionary implements Transformation {

   private String target = "ND" ;
   private boolean deleteXmlFiles = false;
    private boolean eraseFiles = false;
   private String empty1="<arquivos/>";
   private String empty2="<lista/>";

    public GenFrontEndReportsDictionary(){
        String target = System.getenv("reportName");

        if (target != null) this.target = target;

        this.deleteXmlFiles = GenUtility.getVariable("deleteXmlFilesReport");
        this.eraseFiles = GenUtility.getVariable("eraseFiles");
    }

    @Override
    public void doTransformation() throws Exception {
        if (eraseFiles) {
            doEraseListInterfaceFiles();
            doCreateEmptyFiles();
        }

        doTransformationListaRelatorio();
        doTransformationRelatorio();
        doTransformationRelatorioSync();
    }

    private void doEraseListInterfaceFiles() throws Exception{
        GenUtility.deleteFile(new File(GenUtility.HOME_GEN+"/target/listaTelaComplexa.xml"));
        GenUtility.deleteFile(new File(GenUtility.HOME_GEN+"/target/xmlListTelaComplexa.xml"));
        GenUtility.deleteFile(new File(GenUtility.HOME_GEN+"/target/xmlListTelaComplexa_sync.xml"));
        GenUtility.deleteFile(new File(GenUtility.HOME_GEN+"/target/xmlListTelaSimplesCustomizada.xml"));
        GenUtility.deleteFile(new File(GenUtility.HOME_GEN+"/target/listaRelatorio.xml"));
        GenUtility.deleteFile(new File(GenUtility.HOME_GEN+"/target/xmlListRelatorio.xml"));
        GenUtility.deleteFile(new File(GenUtility.HOME_GEN+"/target/xmlListRelatorio_sync.xml"));

        if (deleteXmlFiles){
            GenUtility.deleteFile(new File(GenUtility.HOME_GEN+"/target/relatorios"));
            new File(GenUtility.HOME_GEN+"/target/relatorios").mkdir();
        }

    }

    private void doCreateEmptyFiles() throws Exception {
        Files.write(Paths.get(GenUtility.HOME_GEN + "/target/listaTelaComplexa.xml"), empty1.getBytes());
        Files.write(Paths.get(GenUtility.HOME_GEN + "/target/xmlListTelaComplexa_sync.xml" ), empty1.getBytes());
        Files.write(Paths.get(GenUtility.HOME_GEN + "/target/xmlListTelaSimplesCustomizada.xml" ), empty1.getBytes());
        Files.write(Paths.get(GenUtility.HOME_GEN + "/target/listaTelaComplexa.xml"), empty2.getBytes());
        Files.write(Paths.get(GenUtility.HOME_GEN + "/target/xmlListRelatorio.xml"), empty1.getBytes());
        Files.write(Paths.get(GenUtility.HOME_GEN + "/target/xmlListRelatorio_sync.xml"), empty1.getBytes());
        Files.write(Paths.get(GenUtility.HOME_GEN + "/target/listaRelatorio.xml"), empty2.getBytes());

    }

    private void doTransformationListaRelatorio() throws Exception{

        String xslt = GenUtility.HOME_GEN + "/src/main/java/v2/mm2listaRelatorio.xsl";
        String xmlFile=System.getenv("HOME_MINDMAPS") + "/MenuPrincipalSistema.mm";
        String outFile= GenUtility.HOME_GEN + "/target/listaRelatorio.xml";

        StringBuilder sbParam = new StringBuilder();

        sbParam.append("unity=");
        sbParam.append(target);

        new Processor().run(xslt,xmlFile,outFile,sbParam.toString());

    }

    public void doTransformationRelatorio() throws Exception {

        String xslt = GenUtility.HOME_GEN + "/src/main/java/v2/mm2relatorio.xsl";
        String xmlFile= GenUtility.HOME_GEN + "/target/listaRelatorio.xml";
        String outFile= GenUtility.HOME_GEN + "/target/xmlListRelatorio.xml";
        String relatorioSourcePath= System.getenv("HOME_GEN_URL") + "/target";

        StringBuilder sbParam = new StringBuilder();
        sbParam.append("relatorioSourcePath=");
        sbParam.append(relatorioSourcePath);
        sbParam.append(" ");

        sbParam.append("xmlClasses=");
        sbParam.append(GenUtility.XML_CLASSES);
        sbParam.append(" ");

        sbParam.append("mapasSourcePath=");
        sbParam.append(System.getenv("HOME_MINDMAPS"));
        sbParam.append(" ");


        sbParam.append("padroesFileName=");
        sbParam.append(GenUtility.XML_PADROES);
        sbParam.append(" ");

        sbParam.append("tiposFileName=");
        sbParam.append(GenUtility.XML_TIPODADOS);
        sbParam.append(" ");

        new Processor().run(xslt,xmlFile,outFile,sbParam.toString());

    }

    public void doTransformationRelatorioSync() throws Exception {
        String xslFile = GenUtility.HOME_GEN + "/src/main/java/v2/relatorio2Sync.xsl";
        String xmlFile = GenUtility.HOME_GEN + "/target/xmlListRelatorio.xml";
        String outFile = GenUtility.HOME_GEN + "/target/xmlListRelatorio_sync.xml";

        String syncRelatorioPath = System.getenv("HOME_GEN_URL") + "/target/sync";
        StringBuilder sbParam = new StringBuilder();
        sbParam.append("syncRelatorioPath=");
        sbParam.append(syncRelatorioPath);
        sbParam.append(" ");
        sbParam.append("xmlClasses=");
        sbParam.append(GenUtility.XML_CLASSES);

        new Processor().run(xslFile, xmlFile, outFile, sbParam.toString());


    }

}
