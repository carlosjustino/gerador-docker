package com.datacoper.gerador.backend;

import com.datacoper.bean.MindMapNode;
import com.datacoper.bean.MindMapNodeAttribute;
import com.datacoper.bean.Pacote;
import com.datacoper.gerador.ConfigUtils;
import com.datacoper.gerador.GenUtility;
import com.datacoper.parser.MindMapParserUtil;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;
import sun.security.krb5.Config;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.File;
import java.io.IOException;
import java.util.*;

public class GenPackageList {

    public List<String> listAddedClasses = new ArrayList<>();

    public List<Pacote> geraListaPacotesByPath(String pathToApplicationPackagesFile) throws ParserConfigurationException, SAXException, IOException {
        pathToApplicationPackagesFile = ConfigUtils.getInstance().getNormalizedPath(pathToApplicationPackagesFile);
        List<Pacote> listaPacotes = new ArrayList<>();

        List<MindMapNode> applicationPackagesFileParsed = getMindMapNodesFromPath(pathToApplicationPackagesFile);

        for(MindMapNode thePackage : applicationPackagesFileParsed) {
            Pacote pacoteSoFar = new Pacote();
            pacoteSoFar.setCompoundName("");
            pacoteSoFar.setLink(pathToApplicationPackagesFile.substring(0, pathToApplicationPackagesFile.lastIndexOf(File.separator) + 1));
            pacoteSoFar.setClasses(new ArrayList<>());
            listaPacotes.addAll(geraListaPackages(thePackage, pacoteSoFar));
        }

        return listaPacotes;
    }

    private List<MindMapNode> getMindMapNodesFromPath(String pathToApplicationPackagesFile) throws ParserConfigurationException, SAXException, IOException {
        File applicationPackagesFile = new File(ConfigUtils.getInstance().getNormalizedPath(pathToApplicationPackagesFile));
        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
        Document doc = dBuilder.parse(applicationPackagesFile);
        return MindMapParserUtil.fromXMLDocumentToListMindMapNode(doc);
    }

    private List<Pacote> geraListaPackages(MindMapNode parsedMap, Pacote pacoteBefore) throws ParserConfigurationException, IOException, SAXException {
        List<Pacote> listaRetorno = new ArrayList<>();
        String packageNameSoFar = pacoteBefore != null ? pacoteBefore.getCompoundName() : "";
        String linkSoFar = pacoteBefore != null ? pacoteBefore.getLink().substring(0, pacoteBefore.getLink().lastIndexOf(File.separator) + 1) : "";

        List<MindMapNode> packages = getPackagesAndClassNodes(parsedMap);

        for(MindMapNode theParsedPackage : packages) {

            switch (theParsedPackage.getAtributoIcon()) {
                case "package":
                    percorrePackage(listaRetorno, packageNameSoFar, linkSoFar, theParsedPackage);
                    break;
                case "package_link":
                    percorrePackageLink(pacoteBefore, listaRetorno, linkSoFar, theParsedPackage);
                    break;
                case "table":
                case "table_abstract":
                case "container":
                case "container_adapter":
                case "container_integration":
                case "containerDW":
                    String classLink = linkSoFar + theParsedPackage.getAtributoTEXT();
                    if (listAddedClasses.contains(classLink)) continue;
                    pacoteBefore.getClasses().add(new AbstractMap.SimpleEntry(theParsedPackage.getAtributoTEXT(), theParsedPackage));
                    listAddedClasses.add(classLink);
                    break;
            }
        }

        return listaRetorno;
    }

    private List<MindMapNode> getPackagesAndClassNodes(MindMapNode parsedMap) {
        List<MindMapNode> packages = packages = MindMapParserUtil.findNodesDownByIcon(
                Arrays.asList(parsedMap),
                Arrays.asList("package",
                        "package_link",
                        "table",
                        "table_abstract",
                        "container",
                        "container_adapter",
                        "containerDW",
                        "container_integration"),
                true);

        return packages;
    }

    private void percorrePackage(List<Pacote> listaRetorno, String packageNameSoFar, String linkSoFar, MindMapNode theParsedPackage) throws ParserConfigurationException, SAXException, IOException {
        Pacote pacote = new Pacote();
        pacote.setClasses(new ArrayList<>());
        pacote.setSimpleName(theParsedPackage.getAtributoTEXT());
        pacote.setCompoundName(packageNameSoFar + ("".equals(packageNameSoFar) ? "" : ".") + theParsedPackage.getAtributoTEXT());

        Optional<MindMapNodeAttribute> link = theParsedPackage.getAtributes().stream().filter(x -> "LINK".equals(x.getName())).findFirst();

        if (link.isPresent()) {
            pacote.setLink(ConfigUtils.getInstance().getNormalizedPath(linkSoFar + link.get().getValue()));

            List<MindMapNode> applicationPackagesFileParsed = getMindMapNodesFromPath(pacote.getLink());

            for(MindMapNode parsed : applicationPackagesFileParsed)
                listaRetorno.addAll(geraListaPackages(parsed, pacote));
        } else {
            pacote.setLink(linkSoFar);
            for (MindMapNode filho : theParsedPackage.getFilhos())
                listaRetorno.addAll(geraListaPackages(filho, pacote));
        }
        listaRetorno.add(pacote);
    }

    private void percorrePackageLink(Pacote pacoteBefore, List<Pacote> listaRetorno, String linkSoFar, MindMapNode theParsedPackage) throws ParserConfigurationException, SAXException, IOException {
        Optional<MindMapNodeAttribute> link;
        link = theParsedPackage.getAtributes().stream().filter(x -> "LINK".equals(x.getName())).findFirst();
        if (link.isPresent()) {
            String finalLink = ConfigUtils.getInstance().getNormalizedPath(linkSoFar + link.get().getValue());
            pacoteBefore.setLink(finalLink);
            List<MindMapNode> applicationPackageLinkFilesParsed = getMindMapNodesFromPath(finalLink);

            for(MindMapNode parsed : applicationPackageLinkFilesParsed)
                listaRetorno.addAll(geraListaPackages(parsed, pacoteBefore));
        }
    }
}
