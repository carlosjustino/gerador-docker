package com.datacoper.gerador;

import com.datacoper.gerador.backend.*;
import com.datacoper.gerador.backend.unittest.GenUnitTestsClass;
import com.datacoper.gerador.backend.unittest.GenUnitTestsProperties;
import com.datacoper.gerador.dictionary.*;
import com.datacoper.gerador.frontend.*;
import com.datacoper.gerador.frontend.unittest.GenTestMenuPrincipalSistema;
import com.datacoper.gerador.frontend.unittest.GenTestPageObjectsList;
import com.datacoper.gerador.frontend.unittest.GenTestPageObjectsManter;
import com.datacoper.gerador.frontend.unittest.GenTestPageObjectsView;
import com.datacoper.gerador.report.*;
import com.datacoper.gerador.test.GenRunCucumberTest;
import com.datacoper.gerador.thread.DCFixedThreadPool;

import java.io.File;
import java.io.IOException;
import java.nio.file.CopyOption;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;

import static com.datacoper.gerador.GenUtility.HOME_GERADORSQL;
import static com.datacoper.gerador.GenUtility.USER_TMP;
import static com.datacoper.gerador.ZipUtils.unzip;


public class Manager {


    private static Manager manager= null;

    private boolean frontEndGenerate = false;
    private boolean backEndGenerate = false;

    private boolean all = false;
    private boolean backend = false;
    private boolean frontend = false;

    private boolean templatesMap=false;
    private boolean usingMap=false;

    private boolean reports=false;
    private boolean syncBoth=false;
    private boolean syncFrontEnd=false;
    private boolean syncReports=false;

    private boolean tests=false;
    private boolean unitTests=false;

    // # BACK-END VARS
    private boolean classDictionary=false;
    private boolean utility=false;
    private boolean referrer=false;
    private boolean container=false;
    private boolean query=false;
    private boolean domainbackend=false;
    private boolean constructor=false;
    private boolean restContainer=false;
    private boolean rest=false;
    private boolean listener=false;
    private boolean ddl=false;
    private boolean containerIntegration=false;
    private boolean persistenceXml=false;
    private boolean containerDW=false;
    private boolean compile=false;
    private boolean useGradle=false;
    private boolean hotDeploy=false;
    private boolean compileChanges=false;
    private boolean queue=false;
    private boolean validateClassDictionary=false;
    private boolean storedProcedure=false;
    private boolean restApiManager=false;

    // # FRONT-END VARS
    private boolean ginterface=false;
    private boolean menu=false;
    private boolean routes=false;
    private boolean factory=false;
    private boolean states=false;
    private boolean list=false;
    private boolean editor=false;
    private boolean view=false;
    private boolean controller=false;
    private boolean events=false;
    private boolean functions=false;
    private boolean validators=false;

    // # REPORTS VARS
    private boolean report=false;
    private boolean reportEditor=false;
    private boolean reportView=false;
    private boolean reportDesign=false;
    private boolean reportController=false;
    private boolean reportEvents=false;
    private boolean reportFunctions=false;
    private boolean reportValidators=false;
    private boolean reportJavascript=false;
    private boolean reportState=false;

    // # TESTS VARS

    private boolean unitTest=false;
    private boolean unitClass=false;
    private boolean unitProperties=false;
    private boolean test=false;
    private boolean poList=false;
    private boolean poMantain=false;
    private boolean poView=false;
    private boolean runCucumberTest=false;

    private boolean executeTests= false;
    private String execTarget=null;
    private String target=null;
    private String execMapTarget=null;
    private boolean queriesMap = false;
    private boolean snitchMap = false;
    private boolean validateCode=false;


    private boolean freemind=false;

    private Manager(){

    }

    public static Manager getInstance(){
        if (manager == null){
            manager = new Manager();
        }
        return manager;
    }

    public void preencheVariaveis(){
        useGradle = GenUtility.getVariable("useGradle");
        all = GenUtility.getVariable("all");
        backend = GenUtility.getVariable("backEnd");
        frontend = GenUtility.getVariable("frontEnd");

        templatesMap= GenUtility.getVariable("templatesMap");


        reports= GenUtility.getVariable("reports");
        syncBoth= GenUtility.getVariable("syncBoth");
        syncFrontEnd= GenUtility.getVariable("syncFrontEnd");
        syncReports= GenUtility.getVariable("syncReports");

        tests= GenUtility.getVariable("tests");
        unitTests= GenUtility.getVariable("unitTests");

        // # BACK-END VARS
        classDictionary= GenUtility.getVariable("classDictionary");
        validateClassDictionary= GenUtility.getVariable("validateClassDictionary");
        utility= GenUtility.getVariable("utility");
        storedProcedure=GenUtility.getVariable("storedProcedure");
        referrer= GenUtility.getVariable("referrer");
        container= GenUtility.getVariable("container");
        query= GenUtility.getVariable("query");
        domainbackend= GenUtility.getVariable("domainbackend");
        constructor= GenUtility.getVariable("constructor");
        restContainer= GenUtility.getVariable("restContainer");
        rest= GenUtility.getVariable("rest");
        restApiManager= GenUtility.getVariable("restApiManager");
        listener= GenUtility.getVariable("listener");
        ddl= GenUtility.getVariable("ddl");
        queue= GenUtility.getVariable("queue");

        containerIntegration= GenUtility.getVariable("containerIntegration");
        persistenceXml= GenUtility.getVariable("persistenceXml");
        containerDW= GenUtility.getVariable("containerDW");

        compile= GenUtility.getVariable("compile");
        hotDeploy= GenUtility.getVariable("hotDeploy");
        compileChanges= GenUtility.getVariable("compileChanges");

        // # FRONT-END VARS
        ginterface= GenUtility.getVariable("interface");
        menu= GenUtility.getVariable("menu");
        routes= GenUtility.getVariable("routes");
        factory= GenUtility.getVariable("factory");
        states= GenUtility.getVariable("states");
        list= GenUtility.getVariable("list");
        editor= GenUtility.getVariable("editor");
        view= GenUtility.getVariable("view");
        controller= GenUtility.getVariable("controller");
        events= GenUtility.getVariable("events");
        functions= GenUtility.getVariable("functions");
        validators= GenUtility.getVariable("validators");

        // # REPORTS VARS
        report= GenUtility.getVariable("report");
        reportEditor= GenUtility.getVariable("reportEditor");
        reportView= GenUtility.getVariable("reportView");
        reportDesign= GenUtility.getVariable("reportDesign");
        reportController= GenUtility.getVariable("reportController");
        reportEvents= GenUtility.getVariable("reportEvents");
        reportFunctions= GenUtility.getVariable("reportFunctions");
        reportValidators= GenUtility.getVariable("reportValidators");
        reportJavascript= GenUtility.getVariable("reportJavascript");
        reportState= GenUtility.getVariable("reportState");

        // # TESTS VARS
        unitTest= GenUtility.getVariable("unitTest");
        unitClass= GenUtility.getVariable("unitClass");
        unitProperties= GenUtility.getVariable("unitProperties");
        test= GenUtility.getVariable("test");
        poList= GenUtility.getVariable("poList");
        poMantain= GenUtility.getVariable("poMantain");
        poView= GenUtility.getVariable("poView");
        runCucumberTest= GenUtility.getVariable("runCucumberTest");

        usingMap= GenUtility.getVariable("usingMap");
        queriesMap=GenUtility.getVariable("queriesMap");
        snitchMap=GenUtility.getVariable("snitchMap");
        execTarget=System.getenv("execTarget");
        target=System.getenv("target");
        execMapTarget=System.getenv("execMapTarget");
        executeTests= GenUtility.getVariable("executeTests");

        validateCode= GenUtility.getVariable("validateCode");
        freemind=GenUtility.getVariable("freemindaction");
        if (all || persistenceXml|| backend || queue || utility || referrer || container || containerIntegration || query || domainbackend || containerDW || constructor || restContainer || rest || listener || restApiManager ){
            setBackEndGenerate(true);
        }
        if (all || frontend || report || ginterface || menu || routes || list || editor || view || controller || events || functions || validators || factory || states || reportState || reportDesign || reportEditor || reportView || reportController || reportJavascript || reportEvents || reportFunctions || reportValidators){
            setFrontEndGenerate(true);
        }

    }


    public void choices() throws Exception {
        long tempoInicial = System.currentTimeMillis();
        preencheVariaveis();
        ExecutorService executorServiceBackEnd = new DCFixedThreadPool(3);
        List<Callable<Transformation>> callableTasksBackEnd = new ArrayList<>();
        ExecutorService executorServiceFrontEnd = new DCFixedThreadPool(3);
        List<Callable<Transformation>> callableTasksFrontEnd = new ArrayList<>();

        buscaClassesMapas();

        copyVersionProjects();


        if (all || backend || frontend || reports || classDictionary) {
            GenClassDictionary genClassDictionary = new GenClassDictionary();
            genClassDictionary.setTarget(target);
            genClassDictionary.doTransformation();
        }
        if (persistenceXml) {
            callableTasksBackEnd.add(new GenPersistenceXML());
        }
        if (all || backend || utility) {
            callableTasksBackEnd.add(new GenBackEndUtilities(target));
        }
        if (all || backend || storedProcedure) {
            callableTasksBackEnd.add(new GenBackEndStoredProcedures());
        }
        if (all || backend || container) {
            callableTasksBackEnd.add(new GenBackEndContainer(target));
        }
        if (all || backend || query) {
            callableTasksBackEnd.add(new GenBackEndQueries(target));
        }
        if (all || backend || restContainer) {
            callableTasksBackEnd.add(new GenBackEndRestContainer(target));
        }

        if (all || backend || restApiManager){
            callableTasksBackEnd.add(new GenBackEndRestApiManager(target));
        }

        if (all || backend || rest) {
            callableTasksBackEnd.add(new GenBackEndRest(target));
        }
        if (all || backend || queue) {
            callableTasksBackEnd.add(new GenBackEndQueues(target));
        }

        if (all || backend || referrer) {
            callableTasksBackEnd.add(new GenBackEndReferrer(target));
        }

        if (all || backend || containerIntegration) {
            callableTasksBackEnd.add(new GenBackEndContainerIntegration(target));
        }

        if (all || backend || domainbackend) {
            callableTasksBackEnd.add(new GenBackEndDomain(target));
        }

        if (all || backend || containerDW) {
            callableTasksBackEnd.add(new GenBackEndContainerDW(target));
        }

        if (all || backend || constructor) {
            callableTasksBackEnd.add(new GenBackEndConstructors(target));
        }


        if (all || backend || listener) {
            callableTasksBackEnd.add(new GenBackEndListeners(target));
        }

        if (ddl) {
            callableTasksBackEnd.add(new GenBackEndDataDefinition(target));
        }


        executorServiceBackEnd.invokeAll(callableTasksBackEnd);
        executorServiceBackEnd.shutdown();
        while (!executorServiceBackEnd.isTerminated()) {
            Thread.sleep(100);
        }
        if (all || backend || validateClassDictionary || classDictionary) {
            new GenClassDictionaryValidator(target).doTransformation();
        }

        if (compile || hotDeploy || compileChanges) {
            compileProject();
        }


        if (all || frontend || ginterface) {
            new GenFrontEndDictionary().doTransformation();
        }

        if (all || reports || report) {
            new GenFrontEndReportsDictionary().doTransformation();
        }

        if (all || frontend || reports || menu) {
            new GenFrontEndMenu().doTransformation();
        }

        if (all || frontend || routes) {
            callableTasksFrontEnd.add(new GenFrontEndRoutes());
        }
        if (all || frontend || list){
            callableTasksFrontEnd.add(new GenFrontEndList());
        }

        if (all || frontend || editor) {
            callableTasksFrontEnd.add(new GenFrontEndEditor());
        }

        if (all || frontend || view) {
            callableTasksFrontEnd.add(new GenFrontEndView());
        }

        if (all || frontend || controller) {
            callableTasksFrontEnd.add(new GenFrontEndController());
        }

        if (all || frontend || events) {
            callableTasksFrontEnd.add(new GenFrontEndEvents());
        }

        if (all || frontend || functions) {
            callableTasksFrontEnd.add(new GenFrontEndFunctions());
        }
        if (all || frontend || validators) {
            callableTasksFrontEnd.add(new GenFrontEndValidators());
        }
        if (all || frontend || factory) {
            callableTasksFrontEnd.add(new GenFrontEndFactory(target));
        }

        if (all || frontend || states || reports || reportState) {
            callableTasksFrontEnd.add(new GenFrontEndHtmlStates());
        }

        executorServiceFrontEnd.invokeAll(callableTasksFrontEnd);
        executorServiceFrontEnd.shutdown();

        while (!executorServiceFrontEnd.isTerminated()) {
            Thread.sleep(100);
        }

        if (all || reports || reportDesign) {
            new GenReportsDesign().doTransformation();
        }

        if (all || reports || reportEditor) {
            new GenReportsEditor().doTransformation();
        }

        if (all || reports || reportView){
            new GenReportsView().doTransformation();
        }

        if (all || reports || reportController) {
            new GenReportsController().doTransformation();
        }

        if (all || reports || reportJavascript) {
            new GenReportsJavascript().doTransformation();
        }


        if (all || reports || reportEvents) {
            new GenReportsEvents().doTransformation();
        }

        if (all || reports || reportFunctions) {
            new GenReportsFunctions().doTransformation();
        }

        if (all || reports || reportValidators) {
            new GenReportsValidators().doTransformation();
        }

        if (unitTests || unitTest) {
                new GenUnitTestsDictionary().doTransformation();
        }

        if (unitTests || unitClass) {
            new GenUnitTestsClass().doTransformation();
        }
        if ( unitTests || unitProperties) {
            new GenUnitTestsProperties().doTransformation();
        }

        if (executeTests) {
            execUnitTest();
        }

        if (tests || test) {
              new GenTestMenuPrincipalSistema().doTransformation();
              new GenFrontEndDictionary().doTransformation();
        }

        if (tests || poList) {
            new GenTestPageObjectsList().doTransformation();
        }


        if (tests || poMantain) {
            new GenTestPageObjectsManter().doTransformation();
        }

        if (tests || poView) {
            new GenTestPageObjectsView().doTransformation();
        }

        if (runCucumberTest){
            new GenRunCucumberTest().doTransformation();
        }

        if (templatesMap) {
            new GenTemplateReferenceMap(target).doTransformation();
        }

        if (usingMap) {
            new GenUsingMap(target).doTransformation();
        }
        if (queriesMap) {
            new GenQueriesMap(target).doTransformation();
        }
        if (snitchMap) {
            new GenSnitchMap(target).doTransformation();
        }
        if (validateCode){
            new GenBackEndValidationCode(target).doTransformation();
        }

        long tempoFinal = System.currentTimeMillis();
        System.out.printf("-- Tempo total execucao: %.3f ms%n", (tempoFinal - tempoInicial) / 1000d);

    }

    private void copyVersionProjects() {
        String resources = System.getenv("HOME_REST_API");
        File fileVersion = new File(resources + "/src/main/resources/project.properties" );
        File frontEnd = new File(System.getenv("HOME_JNG") + "/project.properties");
        File frontReports = new File(System.getenv("HOME_MINDMAPS") + "/relatorios/rptdesign/project.properties");
        try {
            Files.copy(fileVersion.toPath(), frontEnd.toPath(), StandardCopyOption.REPLACE_EXISTING);
        }catch (IOException e) {
            e.printStackTrace();
        }
        try {
            Files.copy(fileVersion.toPath(), frontReports.toPath(), StandardCopyOption.REPLACE_EXISTING);
        }catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void buscaClassesMapas() throws Exception {
        if (execMapTarget != null && !execMapTarget.equals("")) {
            GenClassMapDictionary genClassMapDictionary = new GenClassMapDictionary(execMapTarget);
            target = genClassMapDictionary.getListClass();
        }
    }

    private void compileProject() throws Exception{
        String business = System.getenv("BUSINESS");
        String core = System.getenv("CORE");
        String resources = System.getenv("RESOURCES");
        String file = System.getenv("SERVER_DEPLOYMENT");
        file = file.replaceAll("\\/cygdrive\\/c","C:");


        String pastaWso2Deploy = System.getenv("WSO2_DEPLOY").replaceAll("\\/cygdrive\\/c","C:");
        File filePastaWso2Deploy = new File(pastaWso2Deploy);
        File resourcesServerWar = new File(file + ".war");
        File resourcesServerPasta = new File(file);

        if (hotDeploy == false && compileChanges == false && filePastaWso2Deploy.exists()) {

            if (resourcesServerWar.exists()) {
                GenUtility.printInfo("--> Apagando arquivo "+ resourcesServerWar .getAbsolutePath());
                if (GenUtility.deleteFile(resourcesServerWar )) GenUtility.printInfo("--> Arquivo apagado");
                else GenUtility.printErro("Erro ao apagar o arquivo..");
            }

        }


        if (hotDeploy || compileChanges){
        /*    GenUtility.printErro("Utilize o GRADLE...");
            GenUtility.printErro("Utilize o GRADLE...");
            GenUtility.printErro("Utilize o GRADLE...");
            GenUtility.printErro("Utilize o GRADLE...");
            GenUtility.printErro("Utilize o GRADLE...");
*/
           //Descompacta
            File jarBusinessClasses = new File(file+ "/WEB-INF/lib/"
                    + business
                    +"-1.0.jar");
            if (jarBusinessClasses.exists()){
                unzip(jarBusinessClasses, new File(file + "/WEB-INF/classes"));
                //remove .jar
                GenUtility.deleteFile(jarBusinessClasses);
            }
            File jarCoreClasses = new File(file+ "/WEB-INF/lib/"
                    + core
                    +"-1.0.jar");
            if (jarCoreClasses.exists()){
                unzip(jarCoreClasses, new File(file + "/WEB-INF/classes"));
                //remove .jar
                GenUtility.deleteFile(jarCoreClasses);
            }

        }

        compileCore();
        compileBusiness();
        compileResources();

        if (compile){
            if (resourcesServerPasta.exists()) {
                GenUtility.printInfo("--> Apagando pasta "+ resourcesServerPasta.getAbsolutePath());
                if (GenUtility.deleteFile(resourcesServerPasta)) GenUtility.printInfo("--> Pasta apagada");
                else GenUtility.printErro("Erro ao apagar a pasta..");
            }
            GenUtility.printInfo("Copiando arquivo " + resources + " para a pasta do WSO2.");
            Files.copy(Paths.get(System.getenv("HOME_REST_API") + "/target/" + resources + ".war"),
                    Paths.get(resourcesServerWar.getAbsolutePath()), StandardCopyOption.REPLACE_EXISTING);
        }
        // faz sync
        // ficou no cygwin
    }

    private void compileCore() throws Exception{
        if (useGradle){
            invokeGradle(System.getenv("HOME_CORE"), false);
        }else{
            File pom = new File(System.getenv("HOME_CORE") + "/pom.xml");
            invokeMaven(pom);
        }

    }

    private void compileBusiness() throws Exception{

        if (useGradle){
            invokeGradle(System.getenv("HOME_BUSINESS"), false);
        }else{
            File pom = new File(System.getenv("HOME_BUSINESS") + "/pom.xml");
            invokeMaven(pom);
        }

    }

    private void compileResources() throws Exception{
        if (useGradle){
            invokeGradle(System.getenv("HOME_REST_API"), true);
        }else{
            File pom = new File(System.getenv("HOME_REST_API") + "/pom.xml");
            invokeMaven(pom);
        }

    }

    public void compileGeradorSQL() throws Exception{
        boolean old = compileChanges;
        if (useGradle){
            invokeGradle(HOME_GERADORSQL, false);
        }else {
            try {
                File pom = new File(HOME_GERADORSQL + "/pom.xml");
                compileChanges = true;
                //move persistence.xml para outra pasta
                File persistence = new File(GenUtility.HOME_CORE + "/src/main/resources/META-INF/persistence.xml");
                if (persistence.exists()) {
                    GenUtility.moveFile(persistence.getAbsolutePath(), USER_TMP + "/persistence.xml");
                }
                File deletar = new File(GenUtility.HOME_CORE + "/target/classes/META-INF/persistence.xml");
                if (deletar.exists()) {
                    GenUtility.deleteFile(deletar);
                }
                deletar = new File(GenUtility.HOME_CORE + "/target/core.jar");
                if (deletar.exists()) {
                    GenUtility.deleteFile(deletar);
                }
                compileCore();
                compileBusiness();
                invokeMaven(pom);
                compileChanges = old;
            }catch (Exception ex) {
                throw ex;
            }finally {
                //copia persistence novamente
                File persistence = new File(USER_TMP + "/persistence.xml");
                if (persistence.exists()){
                    GenUtility.moveFile(persistence.getAbsolutePath(),GenUtility.HOME_CORE + "/src/main/resources/META-INF/persistence.xml");
                }
            }

        }
    }

    private void invokeGradle(String dir, boolean war )throws Exception{
        if (hotDeploy) {
            GenUtility.invokeGradle(dir, "", "compileJava");
        }else if (compileChanges){
            if (war)
                GenUtility.invokeGradle(dir,"", "copyWar");
            else
                GenUtility.invokeGradle(dir,"", "install");
        } else{
            if (war)
                GenUtility.invokeGradle(dir,"", "clean","copyWar");
            else
                GenUtility.invokeGradle(dir,"", "clean","install");

        }
    }

    private void invokeMaven(File pom)throws Exception{
        if (hotDeploy) {
            GenUtility.invokeMaven(pom, "-XX:+TieredCompilation -XX:TieredStopAtLevel=1 -DskipTests=true", "compile");
        }else if (compileChanges){
            GenUtility.invokeMaven(pom , "-XX:+TieredCompilation -XX:TieredStopAtLevel=1 -DskipTests=true", "compile", "install");
        } else{
            GenUtility.invokeMaven(pom, "-XX:+TieredCompilation -XX:TieredStopAtLevel=1 -DskipTests=true", "clean","install");
        }
    }

    private void exectTestDS(String options) throws Exception{
        File pom = new File(System.getenv("HOME_REST_API") + "/pom.xml");
        GenUtility.invokeMaven(pom, "surefire-report:report -Dignore.collections=true " + options, "test");
    }
    private void execUnitTest() throws Exception{
        File SERVER_DEPLOYMENT_WAR = new File(System.getenv("SERVER_DEPLOYMENT") +".war");
        if (executeTests  && SERVER_DEPLOYMENT_WAR.exists()) {
            System.out.println("[INFO] ---");
            System.out.println("[INFO] Iniciando testes unitários...");
                    System.out.println("[INFO] ---");
        } else {
            System.out.println("[ERRO] ---");
            System.out.println("[ERRO] --- Antes de iniciar os testes é necessário compilar e executar o sistema");
            System.out.println("[ERRO] ---");
            return;
        }

        if ( execTarget == null){
            exectTestDS("-Darchaius.configurationSource.additionalUrls=" + System.getenv("execProperties"));
        } else {
            System.out.println("[INFO] Target: " + execTarget);
            exectTestDS("-Dtest=" + execTarget + " " + System.getenv("params"));
        }
    }


    public boolean isFrontEndGenerate() {
        return frontEndGenerate;
    }

    public boolean isFreemindAction() {
        return freemind;
    }

    public void setFrontEndGenerate(boolean frontEndGenerate) {
        this.frontEndGenerate = frontEndGenerate;
    }

    public boolean isBackEndGenerate() {
        return backEndGenerate;
    }

    public void setBackEndGenerate(boolean backEndGenerate) {
        this.backEndGenerate = backEndGenerate;
    }
}
