package com.datacoper.gerador.dictionary;

import com.datacoper.bean.ClasseAtributoTipo;
import com.datacoper.bean.MindMapNode;
import com.datacoper.bean.Pacote;
import com.datacoper.gerador.*;
import com.datacoper.gerador.backend.GenPackageList;
import org.apache.commons.io.FileUtils;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.List;

public class GenClassDictionary implements Transformation {

    private String target = "ND" ;
    private boolean mountGraph = false;
    private List<Pacote> listaPacotes = new ArrayList<>();
    private List<ClasseAtributoTipo> listaClasseAtributo = new ArrayList<>();

    public GenClassDictionary(){
        this.mountGraph = GenUtility.getVariable("mountGraph");
    }

    public String getTarget() {
        return target;
    }

    public void setTarget(String target) {
        if (target != null) this.target = target;
    }

    public boolean isMountGraph() {
        return mountGraph;
    }

    private List<Pacote> getListaPacotes() throws Exception {
        if (listaPacotes.isEmpty()) {
            String mmPrincipal = System.getenv("HOME_MINDMAPS") + File.separator + GenUtility.PROJECT_NAME +".mm";
 //           mmPrincipal = "C:\\Projetos\\AgroRevenda\\ambientes\\desenvolvimento\\Mapas\\AgroRevenda.mm";
            listaPacotes = new GenPackageList().geraListaPacotesByPath(mmPrincipal);

            int nrClasses = listaPacotes.stream().map(Pacote::getClasses).mapToInt(List::size).sum();
            GenUtility.printInfoColorless("Quantidade de classes: " + nrClasses);
        }

        return listaPacotes;
    }

    private List<ClasseAtributoTipo> getListaClasseAtributo() throws Exception {
        if (listaClasseAtributo.isEmpty()) {
            listaClasseAtributo = new GenClassAttributeDictionary(getListaPacotes()).geraDicionarioTipoDadosCompleto();
            GenUtility.printInfoColorless("Quantidade total de atributos: " + listaClasseAtributo.size());
        }

        return listaClasseAtributo;
    }

    @Override
    public void doTransformation() throws Exception {

        if (target != null && target.equals("gerarTipoDados")){
            doTransformationTipoDados();
        } else {
            if (target==null || target.equals("ND") || Files.notExists(Paths.get(GenUtility.XML_TIPODADOS )) ) {
                doTransformationTipoDados();
            }

            if (target == null || target.equals("ND") || Files.notExists(Paths.get(GenUtility.XML_PADROES))) {
                doTransformationPadroes();
            }

            if (target == null || target.equals("ND") || Files.notExists(Paths.get(GenUtility.XML_CLASSEATRIBUTOS))) {
                doTransformationClasseAtributos();
            }

            doTransformationDicionario();
            if (isMountGraph() && Manager.getInstance().isFrontEndGenerate()) {
                doTransformationDicionarioSimplificado();
                doTransformationDicionarioGrafo();
            }
            //doTransformationDicionarioNew();
        }
    }

    private void doTransformationDicionarioNew() throws Exception {
        LocalDateTime inicio = LocalDateTime.now();
        GenUtility.printInfo("Inicio " + GenUtility.currentDateTime() + " [doTransformationDicionarioNew]");

        String xml = new GenClassDictionaryXML(getListaPacotes(), getListaClasseAtributo()).gerarXml(target);

        String outFile = GenUtility.HOME_GEN + "/target/classes"+ GenUtility.PROJECT_NAME+"_NEW.xml";
        //outFile = "C:\\Projetos\\AgroRevenda\\ambientes\\desenvolvimento\\GeradorDatacoper\\target\\classesAgroRevenda_NEW.xml";
        ConfigUtils.getInstance().writeStringToDisk(xml, outFile);

        GenUtility.printInfoColorless("Tempo Total [doTransformationDicionarioNew]: " + ChronoUnit.MILLIS.between(inicio, LocalDateTime.now()) + " milisegundos");
    }

//    public static void main(String[] args) {
//        try {
//            new GenClassDictionary().doTransformation();
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

    private void doTransformationClasseAtributos() throws Exception {

        LocalDateTime inicio = LocalDateTime.now();
        GenUtility.printInfo("Inicio " + GenUtility.currentDateTime() + " [doTransformationClasseAtributos]");

        new GenClassAttributeDictionaryXML(getListaClasseAtributo()).gravaDicionarioEmDisco(GenUtility.XML_CLASSEATRIBUTOS);

        GenUtility.printInfoColorless("Tempo Total [doTransformationClasseAtributos]: " + ChronoUnit.MILLIS.between(inicio, LocalDateTime.now()) + " milisegundos");
    }

    private void doTransformationTipoDados() throws Exception{
        String xslFile = GenUtility.HOME_GEN + "/src/main/java/v2/mm2tipoDados.xsl";
        String xmlFile=System.getenv("HOME_MINDMAPS") + "/tipoDados.mm";
        String outFile= GenUtility.XML_TIPODADOS;

        new Processor().run(xslFile,xmlFile,outFile,null);

    }

    private void doTransformationPadroes() throws Exception{
        String xslFile = GenUtility.HOME_GEN + "/src/main/java/mm2padroes.xsl";
        String xmlFile=System.getenv("HOME_MINDMAPS") + "/Padroes.mm";
        String outFile= GenUtility.XML_PADROES;

        new Processor().run(xslFile,xmlFile,outFile,null);

    }

    private void doTransformationDicionario() throws Exception{


        String xsltFile = GenUtility.HOME_GEN + "/src/main/java/v2/mm2dicionario.xsl";
        String xmlFile=System.getenv("HOME_MINDMAPS") + "/"+ GenUtility.PROJECT_NAME +".mm";
        String outFile= GenUtility.HOME_GEN + "/target/classes"+ GenUtility.PROJECT_NAME+".xml";
        String pathXml=System.getenv("HOME_GEN_URL") + "/target/xmlClasses";
        File pastaXmlClasses = new File(GenUtility.HOME_GEN + "/target/xmlClasses");
        if ((target==null || target.equals("ND")) && pastaXmlClasses.exists()){
            FileUtils.forceDelete(pastaXmlClasses);
            FileUtils.forceMkdir(pastaXmlClasses);
        }
        StringBuilder sbParam = new StringBuilder();
        sbParam.append("padroesFileName=");
        sbParam.append(GenUtility.XML_PADROES);
        sbParam.append(" ");
        sbParam.append("tiposFileName=");
        sbParam.append(GenUtility.XML_TIPODADOS);
        sbParam.append(" ");
        sbParam.append("tipoFullFileName=");
        sbParam.append(GenUtility.XML_CLASSEATRIBUTOS);
        sbParam.append(" ");
        sbParam.append("geraErros=");
        sbParam.append(System.getenv("GENERATE_ERRORS"));
        sbParam.append(" ");
        sbParam.append("classeAlvo=");
        sbParam.append(target);
        sbParam.append(" ");
        sbParam.append("pathXml=");
        sbParam.append(pathXml);
        new Processor().run(xsltFile,xmlFile,outFile,sbParam.toString());

    }

    private void doTransformationDicionarioSimplificado() throws Exception{
        String xsltFile = GenUtility.HOME_GEN + "/src/main/java/v2/dicionario2simplificado.xsl";
        String xmlFile= GenUtility.XML_CLASSES;
        String outFile= GenUtility.HOME_GEN + "/target/classes"+ GenUtility.PROJECT_NAME+"Simplificado.xml";

        new Processor().run(xsltFile,xmlFile,outFile,null);

    }

    private void doTransformationDicionarioGrafo(String target) throws Exception{
        String xsltFile = GenUtility.HOME_GEN + "/src/main/java/v2/dicionario2grafo.xsl";
        String xmlFile= GenUtility.HOME_GEN + "/target/classes"+ GenUtility.PROJECT_NAME+"Simplificado.xml";
        String outFile= GenUtility.HOME_GEN + "/target/classes"+ GenUtility.PROJECT_NAME+"Grafo.xml";

        String parametros = null;
        if (target != null && !target.equals("ND")) parametros="unity="+target;
        new Processor().run(xsltFile,xmlFile,outFile,parametros);

    }

    private void doTransformationDicionarioGrafo() throws Exception {
        LocalDateTime inicio = LocalDateTime.now();
        GenUtility.printInfo("Inicio " + GenUtility.currentDateTime() + " [doTransformationDicionarioGrafo]");

        String outFileName = GenUtility.HOME_GEN + "/target/classes"+ GenUtility.PROJECT_NAME+"Grafo.xml";
        new GenGrafoDictionary(getListaClasseAtributo()).gravaDicionarioGrafoEmDisco(outFileName);


        GenUtility.printInfoColorless("Tempo Total [doTransformationDicionarioGrafo]: " + ChronoUnit.MILLIS.between(inicio, LocalDateTime.now()) + " milisegundos");
    }

}
