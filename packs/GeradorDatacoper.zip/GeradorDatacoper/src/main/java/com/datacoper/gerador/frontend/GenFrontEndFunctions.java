package com.datacoper.gerador.frontend;

import com.datacoper.gerador.Processor;
import com.datacoper.gerador.Transformation;

import java.util.concurrent.Callable;

import static com.datacoper.gerador.GenUtility.HOME_GEN;
import static com.datacoper.gerador.GenUtility.XML_CLASSES;

public class GenFrontEndFunctions implements Transformation  , Callable<Transformation> {

    public GenFrontEndFunctions(){
    }

    @Override
    public void doTransformation() throws Exception {
        doTransformationTelaComplexaEvents();
    }

    @Override
    public Transformation call() throws Exception {
        doTransformation();
        return this;
    }

    private void doTransformationTelaComplexaEvents() throws Exception{

        String xslFile= HOME_GEN + "/src/main/java/v2/telaComplexa2Functions.xsl";
        String xmlFile= HOME_GEN + "/target/xmlListTelaComplexa_sync.xml";
        String outFile= HOME_GEN + "/target/fnTelaComplexa.lst";

        String functionsSourcePath= System.getenv("HOME_JNG_URL") + "/app/functions";

        StringBuilder sbParam = new StringBuilder();
        sbParam.append("functionsSourcePath=");
        sbParam.append(functionsSourcePath);
        sbParam.append(" ");
        sbParam.append("xmlClasses=");
        sbParam.append(XML_CLASSES);
        sbParam.append(" ");
        sbParam.append("sistemaOperacional=");
        sbParam.append(System.getenv("OS"));
        sbParam.append(" ");
        sbParam.append("ativarBlockUI=");
        sbParam.append(System.getenv("ACTIVATE_BLOCKUI"));


        new Processor().run(xslFile,xmlFile,outFile,sbParam.toString());

    }

}
