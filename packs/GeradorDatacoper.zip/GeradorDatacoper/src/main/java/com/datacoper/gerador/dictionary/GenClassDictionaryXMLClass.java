package com.datacoper.gerador.dictionary;

import com.datacoper.bean.ClasseAtributoTipo;
import com.datacoper.bean.MindMapNode;
import com.datacoper.bean.Pacote;
import com.datacoper.parser.MindMapParserUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class GenClassDictionaryXMLClass {

    private List<Pacote> listaPacotes = new ArrayList<>();
    private List<ClasseAtributoTipo> listaClasseAtributoTipoCompleta = new ArrayList<>();

    public GenClassDictionaryXMLClass(List<Pacote> listaPacotes, List<ClasseAtributoTipo> listaClasseAtributoTipoCompleta) {
        this.listaPacotes = listaPacotes;
        this.listaClasseAtributoTipoCompleta = listaClasseAtributoTipoCompleta;
    }

    public String geraXmlDicionarioClasse(String recuoAnterior, String pacote, MindMapNode classe) {
        StringBuilder stringClasse = new StringBuilder();
        String recuoAtual = recuoAnterior + "\t";

        stringClasse.append(recuoAtual);
        stringClasse.append("<classe");

        stringClasse.append(geraXmlDicionarioClasseAtributosElementoClasse(pacote, classe));

        stringClasse.append(">\n");

        MindMapNode nodeInterface = classe.childByTextEquals("interface");
        if (nodeInterface != null) {
            stringClasse.append(new GenClassDictionaryXMLClassFilters().geraDicionarioFiltrosSeletores(recuoAtual, nodeInterface));
        }

        MindMapNode objeto = classe.childByTextEquals("objeto");
        if (objeto != null) {

            stringClasse.append(new GenClassDictionaryXMLClassConstants().geraDicionarioConstantes(objeto));

            stringClasse.append(new GenClassDictionaryXMLClassIndexes(listaClasseAtributoTipoCompleta).geraDicionarioIndices(recuoAtual, objeto));

            stringClasse.append(new GenClassDictionaryXMLClassAttribute(listaClasseAtributoTipoCompleta).geraDicionarioAtributos(pacote, classe, objeto));

            stringClasse.append(new GenClassDictionaryXMLClassFunctions(listaClasseAtributoTipoCompleta).geraDicionarioFuncoes(recuoAtual, objeto));

            stringClasse.append(new GenClassDictionaryXMLClassEvents(listaClasseAtributoTipoCompleta).geraDicionarioEventos(recuoAtual, objeto));
        }

        MindMapNode nodeClasse = classe.childByTextEquals("classe");
        if (nodeClasse != null) {
            stringClasse.append(new GenClassDictionaryXMLClassServices(listaClasseAtributoTipoCompleta).geraDicionarioServicos(recuoAtual, nodeClasse));

            stringClasse.append(new GenClassDictionaryXMLClassUtilities(listaClasseAtributoTipoCompleta).geraDicionarioUtilitarios(recuoAtual, nodeClasse));

            stringClasse.append(new GenClassDictionaryXMLClassConstructors(listaClasseAtributoTipoCompleta).geraDicionarioConstrutores(recuoAtual, nodeClasse));
        }

        stringClasse.append(recuoAtual);
        stringClasse.append("</classe>\n");

        return stringClasse.toString();
    }

    private String geraXmlDicionarioClasseAtributosElementoClasse(String pacote, MindMapNode classe) {
        StringBuilder stringAtributosClasse = new StringBuilder();

        String className = classe.getAtributoTEXT();
        String classNameFirstLower = className.substring(0, 1).toLowerCase() + className.substring(1);

        stringAtributosClasse.append(" gerarOrdem=\"");
        stringAtributosClasse.append("container_adapter".equals(classe.getAtributoIcon()) ? "S" : "N");
        stringAtributosClasse.append("\"");

        stringAtributosClasse.append(" xmlRootElement_name=\"");
        if (classe.childByTextEquals("XmlRootElement") != null
                && classe.childByTextEquals("XmlRootElement").childByTextEquals("name") != null
                && !classe.childByTextEquals("XmlRootElement").childByTextEquals("name").getFilhos().isEmpty())
            stringAtributosClasse.append(classe.childByTextEquals("XmlRootElement").childByTextEquals("name").getFilhos().get(0).getAtributoTEXT());
        else
            stringAtributosClasse.append(classNameFirstLower);
        stringAtributosClasse.append("\"");

        stringAtributosClasse.append(" xmlRootElement_namespace=\"");
        if (classe.childByTextEquals("XmlRootElement") != null
                && classe.childByTextEquals("XmlRootElement").childByTextEquals("namespace") != null
                && !classe.childByTextEquals("XmlRootElement").childByTextEquals("namespace").getFilhos().isEmpty())
            stringAtributosClasse.append(classe.childByTextEquals("XmlRootElement").childByTextEquals("namespace").getFilhos().get(0).getAtributoTEXT());
        else
            stringAtributosClasse.append("NONE");
        stringAtributosClasse.append("\"");

        stringAtributosClasse.append(" container=\"");
        switch (classe.getAtributoIcon()) {
            case "container":
            case "container_adapter":
                stringAtributosClasse.append("S");
            case "containerDW":
                stringAtributosClasse.append("DW");
            default:
                stringAtributosClasse.append("N");
        }
        stringAtributosClasse.append("\"");

        stringAtributosClasse.append(" extra_adapters=\"");
        stringAtributosClasse.append("container_adapter".equals(classe.getAtributoIcon()) ? "S" : "N");
        stringAtributosClasse.append("\"");

        stringAtributosClasse.append(" cacheable=\"");
        if (classe.childByTextEquals("objeto") != null && classe.childByTextEquals("objeto").childByTextEquals("@Cacheable(true)") != null)
            stringAtributosClasse.append("Y");
        else
            stringAtributosClasse.append("N");
        stringAtributosClasse.append("\"");

        stringAtributosClasse.append(" pacote=\"");
        stringAtributosClasse.append(MindMapParserUtil.getPackagePrefix(classe));
        stringAtributosClasse.append(pacote);
        stringAtributosClasse.append("\"");

        stringAtributosClasse.append(" pacoteBase=\"");
        if (pacote.indexOf(".") < 0)
            stringAtributosClasse.append(pacote);
        else
            stringAtributosClasse.append(pacote.substring(0, pacote.indexOf(".")));
        stringAtributosClasse.append("\"");

        stringAtributosClasse.append(" nome=\"");
        stringAtributosClasse.append(className);
        stringAtributosClasse.append("\"");

        stringAtributosClasse.append(" nomeCompleto=\"");
        stringAtributosClasse.append(MindMapParserUtil.getPackagePrefix(classe));
        stringAtributosClasse.append(pacote);
        stringAtributosClasse.append(".");
        stringAtributosClasse.append(className);
        stringAtributosClasse.append("\"");

        stringAtributosClasse.append(" telaSimples=\"");
        stringAtributosClasse.append("\"");

        return stringAtributosClasse.toString();
    }
}
