package com.datacoper.gerador.backend.unittest;

import com.datacoper.gerador.Processor;
import com.datacoper.gerador.Transformation;

import static com.datacoper.gerador.GenUtility.HOME_GEN;
import static com.datacoper.gerador.GenUtility.XML_CLASSES;

public class GenUnitTestsClass implements Transformation {


    public GenUnitTestsClass(){
    }


    @Override
    public void doTransformation() throws Exception {
        doTransformationUnitTestsClass();
    }


    private void doTransformationUnitTestsClass() throws Exception{
        String xsltFile = HOME_GEN + "/src/main/java/v2/testeUnitario2java.xsl";
        String xmlFile=HOME_GEN + "/target/testeUnitario.xml";
        String outFile=HOME_GEN + "/target/unitTestFiles.lst";
        String javaSourcePath= System.getenv("HOME_REST_API_URL") + "/src/test/java";

        StringBuilder sbParam = new StringBuilder();
        sbParam.append("javaSourcePath=");
        sbParam.append(javaSourcePath);
        sbParam.append(" ");
        sbParam.append("xmlClasses=");
        sbParam.append(XML_CLASSES);

        new Processor().run(xsltFile,xmlFile,outFile,sbParam.toString());

    }


}
