package com.datacoper.bean;

import com.datacoper.gerador.GenUtility;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MindMapNode {

    private String nodeName = "";
    private String nodeValue = "";
    private MindMapNode pai;
    private List<MindMapNode> filhos;
    private List<MindMapNodeAttribute> atributes;
    private String atributoTEXT;
    private String atributoIcon;

    private List<MindMapNode> allDescendantsAsSiblings;
    private List<MindMapNode> allAscendantsAsSiblings;

    public List<MindMapNode> allDescendantsAsSiblings() {

        if (allDescendantsAsSiblings == null) {
            allDescendantsAsSiblings = new ArrayList<>();

            if (getFilhos() != null && !getFilhos().isEmpty()) {
                for (MindMapNode filho : getFilhos()) {
                    allDescendantsAsSiblings.add(filho);
                    allDescendantsAsSiblings.addAll(filho.allDescendantsAsSiblings());
                }
            }
        }

        return allDescendantsAsSiblings;
    }

    public List<MindMapNode> allAscendantsAsSiblings() {

        if (allAscendantsAsSiblings == null) {
            allAscendantsAsSiblings = new ArrayList<>();

            if (getPai() != null) {
                allAscendantsAsSiblings.add(getPai());
                allAscendantsAsSiblings.addAll(getPai().allAscendantsAsSiblings());
            }
        }

        return allAscendantsAsSiblings;
    }



    public MindMapNode childByTextEquals(String text) {
        return  childByText(text, "equals");
    }

    public MindMapNode childByTextStartsWith(String text) {
        return  childByText(text, "startsWith");
    }

    private MindMapNode childByText(String text, String tipoBusca) {
        MindMapNode retorno = null;

        switch (tipoBusca){
            case "startsWith":
                if (allDescendantsAsSiblings().stream().anyMatch(x -> x.getAtributoTEXT() != null && x.getAtributoTEXT().startsWith(text)))
                    retorno = allDescendantsAsSiblings().stream().filter(x -> x.getAtributoTEXT() != null && x.getAtributoTEXT().startsWith(text)).findAny().get();
                break;
            default:
                if (allDescendantsAsSiblings().stream().anyMatch(x -> text.equals(x.getAtributoTEXT())))
                    retorno = allDescendantsAsSiblings().stream().filter(x -> text.equals(x.getAtributoTEXT())).findAny().get();
                break;
        }

        return retorno;
    }

    public MindMapNode ascendantByTextEquals(String text) {
        return  ascendantByText(text, "equals");
    }

    public MindMapNode ascendantByTextStartsWith(String text) {
        return  ascendantByText(text, "startsWith");
    }

    public MindMapNode ascendantByTextEndsWith(String text) {
        return  ascendantByText(text, "endsWith");
    }

    private MindMapNode ascendantByText(String text, String tipoBusca) {
        MindMapNode retorno = null;

        switch (tipoBusca){
            case "startsWith":
                if (allAscendantsAsSiblings().stream().anyMatch(x -> x.getAtributoTEXT() != null && x.getAtributoTEXT().startsWith(text)))
                    retorno = allAscendantsAsSiblings().stream().filter(x -> x.getAtributoTEXT() != null && x.getAtributoTEXT().startsWith(text)).findAny().get();
                break;
            case "endsWith":
                if (allAscendantsAsSiblings().stream().anyMatch(x -> x.getAtributoTEXT() != null && x.getAtributoTEXT().endsWith(text)))
                    retorno = allAscendantsAsSiblings().stream().filter(x -> x.getAtributoTEXT() != null && x.getAtributoTEXT().endsWith(text)).findAny().get();
                break;
            default:
                if (allAscendantsAsSiblings().stream().anyMatch(x -> text.equals(x.getAtributoTEXT())))
                    retorno = allAscendantsAsSiblings().stream().filter(x -> text.equals(x.getAtributoTEXT())).findAny().get();
                break;
        }

        return retorno;
    }

    public MindMapNode childByIcon(String... icons) {
        MindMapNode retorno = null;
        List<String> iconsList = Arrays.asList(icons);

        if (allDescendantsAsSiblings().stream().anyMatch(x -> Arrays.asList(icons).contains(x.getAtributoIcon())))
            retorno = allDescendantsAsSiblings().stream().filter(x -> iconsList.contains(x.getAtributoIcon())).findAny().get();

        return retorno;
    }


    public String getNodeName() {
        return nodeName;
    }

    public void setNodeName(String nodeName) {
        this.nodeName = nodeName;
    }

    public String getNodeValue() {
        return nodeValue;
    }

    public void setNodeValue(String nodeValue) {
        this.nodeValue = nodeValue;
    }

    public MindMapNode getPai() {
        return pai;
    }

    public void setPai(MindMapNode pai) {
        this.pai = pai;
    }

    public List<MindMapNode> getFilhos() {
        return filhos;
    }

    public void setFilhos(List<MindMapNode> filhos) {
        this.filhos = filhos;
    }

    public List<MindMapNodeAttribute> getAtributes() {
        return atributes;
    }

    public void setAtributes(List<MindMapNodeAttribute> atributes) {
        this.atributes = atributes;
    }

    public void addToAtributes(MindMapNodeAttribute aMindMapNodeAttribute) {
        if (this.atributes == null) this.atributes = new ArrayList<>();
        this.atributes.add(aMindMapNodeAttribute);
    }

    public String getAtributoTEXT() {
        return atributoTEXT;
    }

    public void setAtributoTEXT(String atributoTEXT) {
        this.atributoTEXT = atributoTEXT;
    }

    public String getAtributoIcon() {
        return atributoIcon;
    }

    public void setAtributoIcon(String atributoIcon) {
        this.atributoIcon = atributoIcon;
    }

    public String getLastFunctionCallFromAtributoTEXT() {
        if (getAtributoTEXT() != null && getAtributoTEXT().contains("(")) {

            String textoTratado = getAtributoTEXT();

            if (textoTratado.contains("=")) {
                String[] splited = textoTratado.split("=");
                textoTratado = splited[splited.length - 1];
            }

            if (textoTratado.contains("(")) {

                textoTratado = textoTratado.substring(0, textoTratado.indexOf("("));

                if (textoTratado.contains(".")) {
                    String[] splited = textoTratado.split("\\.");
                    textoTratado = splited[splited.length - 1];
                }

                textoTratado += "()";
                textoTratado = textoTratado.trim();

                //GenUtility.printInfoColorless("Texto Tratado: " + textoTratado + ", original: " + getAtributoTEXT());

                return textoTratado;
            }
        }

        return "";
    }

    public boolean nodePaiEhGetFirstElementSemWhere() {
        if ("getFirstElement()".equals(getPai().getLastFunctionCallFromAtributoTEXT()))
            return getPai().childByTextEquals("where") == null;

        return false;
    }
}
