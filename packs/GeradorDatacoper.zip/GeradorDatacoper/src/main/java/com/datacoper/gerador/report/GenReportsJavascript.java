package com.datacoper.gerador.report;

import com.datacoper.gerador.Processor;
import com.datacoper.gerador.Transformation;

import static com.datacoper.gerador.GenUtility.HOME_GEN;
import static com.datacoper.gerador.GenUtility.XML_CLASSES;

public class GenReportsJavascript implements Transformation {


    public GenReportsJavascript(){

    }

    @Override
    public void doTransformation() throws Exception {
        doTransformationReportJavascript();
    }

    private void doTransformationReportJavascript() throws Exception{
        String xslFile= HOME_GEN + "/src/main/java/v2/relatorio2Javascript.xsl";
        String xmlFile= HOME_GEN + "/target/xmlListRelatorio_sync.xml";
        String outFile= HOME_GEN + "/target/jsRelatorio.lst";
        String javascriptSourcePath= System.getenv("SVN_RPTDESIGN_URL") + "/rptscripts";

        StringBuilder sbParam = new StringBuilder();
        sbParam.append("javascriptSourcePath=");
        sbParam.append(javascriptSourcePath);
        sbParam.append(" ");
        sbParam.append("xmlClasses=");
        sbParam.append(XML_CLASSES);
        sbParam.append(" ");
        sbParam.append("sistemaOperacional=");
        sbParam.append(System.getenv("OS"));

        new Processor().run(xslFile,xmlFile,outFile,sbParam.toString());

    }

}
