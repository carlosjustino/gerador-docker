package com.datacoper.gerador;

public interface Processador {
    public void setProfile(boolean ativo);
    public boolean isProfile();
    public void setProfileFileName(String nome);
    public String getProfileFileName();
    public void run() throws Exception;
    public void reset();
    public void init(String arquivoXsl, String arquivoEntrada, String arquivoSaida, String parametros);
}
