package com.datacoper.gerador.frontend;

import com.datacoper.gerador.GenUtility;
import com.datacoper.gerador.Processor;
import com.datacoper.gerador.Transformation;

import java.io.File;
import java.io.IOException;
import java.nio.file.FileVisitOption;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Comparator;

public class GenFrontEndMenu implements Transformation {

    public GenFrontEndMenu(){
    }

    @Override
    public void doTransformation() throws Exception {
        doTransformationMenuXml();
        doTransformationMenuJson();
        doTransformationMenuHorizontalJson();
        doTransformationMenuPrincipalDB();
    }

    private void doTransformationMenuXml() throws Exception{
        String xslFile = GenUtility.HOME_GEN + "/src/main/java/v2/mm2menuXml.xsl";
        String xmlFile=System.getenv("HOME_MINDMAPS") + "/MenuPrincipalSistema.mm";
        String outFile= GenUtility.HOME_GEN + "/target/menuPrincipalSistema.xml";
        String xmlTelaSourcePath= GenUtility.HOME_GEN + "/target";

        StringBuilder sbParam = new StringBuilder();
        sbParam.append("classesXMLFile=");
        sbParam.append(GenUtility.XML_CLASSES);

        sbParam.append(" ");

        sbParam.append("xmlTelaSourcePath=");
        sbParam.append(xmlTelaSourcePath);

        new Processor().run(xslFile,xmlFile,outFile,sbParam.toString());

    }

    private void doTransformationMenuJson() throws Exception{
        String xslFile= GenUtility.HOME_GEN + "/src/main/java/v2/mm2menuJson.xsl";
        String xmlFile= GenUtility.HOME_GEN + "/target/menuPrincipalSistema.xml";
        String outFile= GenUtility.HOME_JNG + "/app/menu/menuPrincipalSistema.json";
        String mapasSourcePath= System.getenv("HOME_MINDMAPS");

        StringBuilder sbParam = new StringBuilder();
        sbParam.append("classesXMLFile=");
        sbParam.append(GenUtility.XML_CLASSES);
        sbParam.append(" ");
        sbParam.append("mapasSourcePath=");
        sbParam.append(mapasSourcePath);
        sbParam.append(" ");
        sbParam.append("sistemaOperacional=");
        sbParam.append(System.getenv("OS"));

        new Processor().run(xslFile,xmlFile,outFile,sbParam.toString());

    }

    private void doTransformationMenuHorizontalJson() throws Exception{
        String xslFile= GenUtility.HOME_GEN + "/src/main/java/v2/menuXml2menuHorizontalJson.xsl";
        String xmlFile= GenUtility.HOME_GEN + "/target/menuPrincipalSistema.xml";
        String outFile= GenUtility.HOME_JNG + "/app/menu/menuHorizontalSistema.json";

        new Processor().run(xslFile,xmlFile,outFile,null);

    }

    private void doTransformationMenuPrincipalDB() throws Exception{
        doRemoveRotinaMenuAntigo();

        String xslFile= GenUtility.HOME_GEN + "/src/main/java/v2/menuPrincipalSistema2db.xsl";
        String xmlFile= GenUtility.HOME_GEN + "/target/menuPrincipalSistema.xml";
        String outFile= GenUtility.HOME_GEN + "/src/main/scripts/banco/rotinaMenu";
        LocalDateTime agora = LocalDateTime.now();
        DateTimeFormatter formatador = DateTimeFormatter
                .ofPattern("yyyy-MM-dd-HH-mm-ss");
        outFile += agora.format(formatador) + ".sql";

        new Processor().run(xslFile,xmlFile,outFile,null);

    }

    private void doRemoveRotinaMenuAntigo() throws Exception{
        System.out.println("---> Removendo arquivos de menus antigos. ");
        Path rootPath = Paths.get(GenUtility.HOME_GEN + "/src/main/scripts/banco");
        try {
            Files.walk(rootPath, FileVisitOption.FOLLOW_LINKS)
                    .sorted(Comparator.reverseOrder())
                    .map(Path::toFile)
                    .filter(File::isFile)
                    .filter(f -> f.getName().startsWith("rotinaMenu"))
                    .peek(System.out::println)
                    .forEach(File::delete);
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println("---> Fim da remocao dos arquivos de menus antigos. ");
    }
}
