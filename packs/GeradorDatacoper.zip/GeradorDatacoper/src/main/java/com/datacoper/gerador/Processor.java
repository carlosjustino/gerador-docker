package com.datacoper.gerador;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

public class Processor {

    private ProcessaXSLTXalan processaXSLTXalan= null;
    private ProcessaXSLTSaxon processaXSLTSaxon= null;
    private Processador processador = null;

    public Processor (){
        processador = null;
    }

    public void runProfile(String arquivoXsl, String arquivoEntrada, String arquivoSaida, String parametros) throws Exception {
        run(arquivoXsl,arquivoEntrada,arquivoSaida,parametros,true);
    }

    public void run(String arquivoXsl, String arquivoEntrada, String arquivoSaida, String parametros) throws Exception {
        run(arquivoXsl,arquivoEntrada,arquivoSaida,parametros,false);
    }

    private void run(String arquivoXsl, String arquivoEntrada, String arquivoSaida, String parametros, boolean profile) throws Exception {
        try {
            if (arquivoXsl.indexOf("mm2padroes.xsl") > 0) {
                processaXSLTXalan = new ProcessaXSLTXalan();
                processaXSLTXalan.init(arquivoXsl, arquivoEntrada, arquivoSaida, null);
                processador = processaXSLTXalan;
            } else {
                processaXSLTSaxon = new ProcessaXSLTSaxon();
                processaXSLTSaxon.init(arquivoXsl, arquivoEntrada, arquivoSaida, parametros);
                processador = processaXSLTSaxon;
            }
            processador.setProfile(profile);
            if (profile){
                String profileFileName = "none.html";
                if (arquivoXsl.contains("/")) {
                    profileFileName = arquivoXsl.substring(arquivoXsl.lastIndexOf("/") + 1);
                }else if (arquivoXsl.contains("\\")) {
                    profileFileName = arquivoXsl.substring(arquivoXsl.lastIndexOf("\\") + 1);
                }
                if (profileFileName.contains(".xsl")){
                    profileFileName = profileFileName.substring(0,profileFileName.indexOf(".xsl"));
                    profileFileName += ".html";
                }
                if (Files.exists(Paths.get(GenUtility.HOME_GEN_TARGET + "/" + profileFileName)) && Files.size(Paths.get(GenUtility.HOME_GEN_TARGET + "/" + profileFileName)) > 1){
                     Files.move(Paths.get(GenUtility.HOME_GEN_TARGET + "/" + profileFileName), Paths.get(GenUtility.HOME_GEN_TARGET + "/old" + profileFileName), StandardCopyOption.REPLACE_EXISTING);
                }
                Files.deleteIfExists(Paths.get(GenUtility.HOME_GEN_TARGET + "/" + profileFileName.substring(0,profileFileName.indexOf(".html")) + "Timing.txt" ));

                processador.setProfileFileName(GenUtility.HOME_GEN_TARGET + "/" + profileFileName);
            }
            processador.run();
            processador = null;
        } catch (Exception ex){
            System.out.println("--- arquivoXsl: " + arquivoXsl);
            System.out.println("--- arquivoEntrada: " + arquivoEntrada);
            System.out.println("--- arquivoSaida: " + arquivoSaida);
            System.out.println("--- parametros: " + parametros);
            throw ex;
        }
    }

}
