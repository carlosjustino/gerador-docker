package com.datacoper.gerador.backend;

import com.datacoper.gerador.Processor;
import com.datacoper.gerador.Transformation;

import java.util.concurrent.Callable;

import static com.datacoper.gerador.GenUtility.HOME_GEN;
import static com.datacoper.gerador.GenUtility.XML_CLASSES;

public class GenBackEndDomain implements Transformation , Callable<Transformation> {

    String target = "ND";

    public GenBackEndDomain(String target){
        if (target != null) this.target = target;

    }


    @Override
    public void doTransformation() throws Exception {
        doTransformationBackEndDomain();
    }

    private void doTransformationBackEndDomain() throws Exception{

        String javaSourcePath=System.getenv("HOME_CORE_URL") + "/src/main/java";

        String resourceSourcePath=System.getenv("HOME_CORE_URL") + "/src/main/resources";

        String xsltFile = HOME_GEN + "/src/main/java/v2/dicionario2jpa.xsl";
        String xmlFile=XML_CLASSES;
        String outFile=System.getenv("HOME_TEMP") + "/domainSource.lst";

        StringBuilder sbParam = new StringBuilder();
        sbParam.append("javaSourcePath=");
        sbParam.append(javaSourcePath);
        sbParam.append(" ");
        sbParam.append("resourceSourcePath=");
        sbParam.append(resourceSourcePath);
        sbParam.append(" ");
        sbParam.append("sistemaOperacional=");
        sbParam.append(System.getenv("OS"));
        sbParam.append(" ");
        sbParam.append("classeAlvo=");
        sbParam.append(target);
        new Processor().run(xsltFile,xmlFile,outFile,sbParam.toString());

    }

    @Override
    public Transformation call() throws Exception {
        doTransformation();
        return this;
    }
}
