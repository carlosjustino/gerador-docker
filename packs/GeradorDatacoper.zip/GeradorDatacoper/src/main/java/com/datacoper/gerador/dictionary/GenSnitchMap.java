package com.datacoper.gerador.dictionary;

import com.datacoper.gerador.GenUtility;
import com.datacoper.gerador.Processor;
import com.datacoper.gerador.Transformation;

import java.nio.file.Files;
import java.nio.file.Paths;

public class GenSnitchMap implements Transformation {

   private String target = "ND" ;


    public GenSnitchMap(String target){
        if (target != null) this.target = target;
    }

    @Override
    public void doTransformation() throws Exception {

        doTransformationSnitchMap();
    }

    private void doTransformationSnitchMap() throws Exception{
        String xsltFile = GenUtility.HOME_GEN + "/src/main/java/v2/dicionario2dedoDuro.xsl";
        String xmlFile=GenUtility.XML_CLASSES;
        String outFile= GenUtility.HOME_GEN + "/target/" + GenUtility.PROJECT_NAME+".snitchMap.aux.mm";

        String mapaGerado=  GenUtility.HOME_GEN + "/target/SnitchMap.mm";
        String strMapa = "<map version=\"1.0.1\"><node TEXT=\"GERANDO MAPA\"><node TEXT=\"AGUARDE\"></node></node></map>";
        Files.write(Paths.get(mapaGerado), strMapa.getBytes());

        StringBuilder sbParam = new StringBuilder();
        sbParam.append("classeAlvo=");
        sbParam.append(target);
        new Processor().run(xsltFile,xmlFile,outFile,sbParam.toString());

        GenUtility.moveFile(outFile, mapaGerado);

    }



}
