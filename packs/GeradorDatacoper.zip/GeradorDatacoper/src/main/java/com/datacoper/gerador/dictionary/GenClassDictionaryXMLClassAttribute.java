package com.datacoper.gerador.dictionary;

import com.datacoper.bean.ClasseAtributoTipo;
import com.datacoper.bean.MindMapNode;
import com.datacoper.parser.MindMapParserUtil;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class GenClassDictionaryXMLClassAttribute {

    private List<ClasseAtributoTipo> listaClasseAtributoTipoCompleta = new ArrayList<>();
    private List<ClasseAtributoTipo> listaClasseAtributoTipoAux = new ArrayList<>();

    private final List<String> listaIconesAtributosValidos =
            Arrays.asList("tag_green", "tag_red", "tag_yellow", "link", "link_add", "link_ciclico", "link_delete", "folder_table", "folder_table_dependent");
    private final List<String> listaTiposAtributosNumericos =
            Arrays.asList("AnoMes","Arquivo","Longo","InteiroNegativo","InteiroPositivo","Inteiro","AutoIncremento","Sequencial","Monetario","DecimalNegativo","DecimalPositivo","Decimal");

    public GenClassDictionaryXMLClassAttribute(List<ClasseAtributoTipo> listaClasseAtributoTipoCompleta) {
        this.listaClasseAtributoTipoCompleta = listaClasseAtributoTipoCompleta;
    }


    public String geraDicionarioAtributos(String pacote, MindMapNode classe, MindMapNode objeto) {

        listaClasseAtributoTipoAux = listaClasseAtributoTipoCompleta.stream()
                .filter(x -> x.getNomeClasse().equals(classe.getAtributoTEXT())
                        && x.getNomePacote().equals(MindMapParserUtil.getPackagePrefix(classe) + pacote))
                .collect(Collectors.toList());

        StringBuilder stringAtributos = new StringBuilder();

        MindMapNode atributoNode = objeto.childByTextEquals("atributo");
        if (atributoNode != null && !atributoNode.getFilhos().isEmpty()) {
            List<MindMapNode> listaNodesAtributosValidos = atributoNode.getFilhos().stream()
                    .filter(x -> listaIconesAtributosValidos.contains(x.getAtributoIcon())).collect(Collectors.toList());
            for (MindMapNode atributo : listaNodesAtributosValidos) {
                stringAtributos.append(geraDicionarioAtributosAtributo(pacote, classe, objeto, atributo));
            }
        }

        return stringAtributos.toString();
    }

    private String geraDicionarioAtributosAtributo(String pacote, MindMapNode classe, MindMapNode objeto, MindMapNode atributo) {
        StringBuilder stringAtributo = new StringBuilder();
        String nomeAtributo = atributo.getAtributoTEXT().substring(0, atributo.getAtributoTEXT().indexOf(":"));
        String tagAtributo = "";
        boolean atributoSimples = false;
        switch (atributo.getAtributoIcon()){
            case "tag_green":
            case "tag_red":
                tagAtributo = "atributo";
                atributoSimples = true;
                break;
            case "tag_yellow":
                tagAtributo = "atributoCalculado";
                break;
            case "link":
            case "link_ciclico":
                tagAtributo = "referencia";
                break;
            case "link_add":
                tagAtributo = "composicao";
                break;
            case "link_delete":
                tagAtributo = "referenciaColecaoDependente";
                break;
            case "folder_table":
                tagAtributo = "colecao";
                break;
            case "folder_table_dependent":
                tagAtributo = "colecaoDependente";
                break;
        }

        ClasseAtributoTipo classeAtributoTipo = listaClasseAtributoTipoAux.stream()
                .filter(x -> x.getNomeAtributo().equals(nomeAtributo))
                .findAny().get();

        stringAtributo.append("\t\t<");
        stringAtributo.append(tagAtributo);

        stringAtributo.append(" nome=\"");
        stringAtributo.append(nomeAtributo);
        stringAtributo.append("\"");

        if (atributoSimples) {
            stringAtributo.append(" tipoNumerico=\"");
            stringAtributo.append(listaTiposAtributosNumericos.contains(classeAtributoTipo.getTipoAtributoSemPrecisao()) ? "S" : "N");
            stringAtributo.append("\"");
        }

        stringAtributo.append(" tipo=\"");
        stringAtributo.append(classeAtributoTipo.getTipoAtributo());
        stringAtributo.append("\"");

        stringAtributo.append(" attribute=\"");
        stringAtributo.append("S");
        stringAtributo.append("\"");

        MindMapNode nodeTick = atributo.childByIcon("tick");
        if (nodeTick != null) {
            stringAtributo.append(">\n");

            stringAtributo.append(new GenClassDictionaryXMLClassAttributeValidations(listaClasseAtributoTipoCompleta).geraDicionarioAtributosAtributoValidacao(nodeTick));

            stringAtributo.append("\t\t</");
            stringAtributo.append(tagAtributo);
            stringAtributo.append(">\n");
        } else {
            stringAtributo.append(" />\n");
        }

        return stringAtributo.toString();
    }
}
