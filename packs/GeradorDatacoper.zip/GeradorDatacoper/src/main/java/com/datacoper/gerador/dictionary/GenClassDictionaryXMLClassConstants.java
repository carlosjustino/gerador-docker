package com.datacoper.gerador.dictionary;

import com.datacoper.bean.MindMapNode;

public class GenClassDictionaryXMLClassConstants {

    public String geraDicionarioConstantes(MindMapNode objeto) {
        StringBuilder stringConstantes = new StringBuilder();
        MindMapNode constantes = objeto.childByTextEquals("constante");
        if (constantes != null) {
            stringConstantes.append("\t\t<constantes xmlns:xs=\"http://www.w3.org/2001/XMLSchema\"");
            if (constantes.getFilhos().isEmpty())
                stringConstantes.append(" />\n");
            else {
                stringConstantes.append(">\n");
                for (MindMapNode constante : constantes.getFilhos()) {
                    stringConstantes.append(geraDicionarioConstantesConstante(constante));
                }
                stringConstantes.append("\t\t</constantes>\n");
            }
        }

        return stringConstantes.toString();
    }

    private String geraDicionarioConstantesConstante(MindMapNode constante) {
        StringBuilder stringConstante = new StringBuilder();
        stringConstante.append("\t\t\t<constante");

        stringConstante.append(" nome=\"");
        stringConstante.append(constante.getAtributoTEXT() != null && constante.getAtributoTEXT().contains(":") ? constante.getAtributoTEXT().substring(0, constante.getAtributoTEXT().indexOf(":")) : constante.getAtributoTEXT());
        stringConstante.append("\"");

        stringConstante.append(" tipo=\"");
        stringConstante.append(constante.getAtributoTEXT() != null && constante.getAtributoTEXT().contains(":") ? constante.getAtributoTEXT().substring(constante.getAtributoTEXT().indexOf(":") + 1) : "Inteiro()");
        stringConstante.append("\"");

        stringConstante.append(" titulo=\"");
        MindMapNode label = constante.childByTextEquals("label");
        if (label != null && !label.getFilhos().isEmpty())
            stringConstante.append(label.getFilhos().get(0).getAtributoTEXT());
        stringConstante.append("\"");

        stringConstante.append(" aviso=\"");
        MindMapNode hint = constante.childByTextEquals("hint");
        if (hint != null && !hint.getFilhos().isEmpty())
            stringConstante.append(hint.getFilhos().get(0).getAtributoTEXT());
        stringConstante.append("\"");

        stringConstante.append(">");
        MindMapNode value = constante.childByTextEquals("value");
        if (value != null && !value.getFilhos().isEmpty())
            stringConstante.append(value.getFilhos().get(0).getAtributoTEXT());

        stringConstante.append("</constante>\n");

        return stringConstante.toString();
    }
}
