package com.datacoper.gerador.dictionary;

import com.datacoper.bean.ClasseAtributoTipo;
import com.datacoper.gerador.ConfigUtils;
import com.datacoper.gerador.GenUtility;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class GenGrafoDictionary {
    private Map<String, List<ClasseAtributoTipo>> listaClasseAtributoTipoAgrupado = new HashMap<>();
    private Map<String, String> mapClassePacote = new HashMap<>();
    private Map<String, List<String>> mapClasseReferencias = new HashMap<>();

    public GenGrafoDictionary(List<ClasseAtributoTipo> listaClasseTipoAtributo) {
        listaClasseAtributoTipoAgrupado = listaClasseTipoAtributo.stream().collect(Collectors.groupingBy(w -> w.getNomeClasseCompleto()));


        listaClasseAtributoTipoAgrupado.entrySet().forEach(classePacote -> {
            String classe = classePacote.getKey().split("\\.")[classePacote.getKey().split("\\.").length - 1];
            String pacote = classePacote.getKey().substring(0, classePacote.getKey().lastIndexOf("." + classe));
            mapClassePacote.put(classe, pacote);
        });
    }

    public void gravaDicionarioGrafoEmDisco(String fileName) throws IOException {
        String xml = montaXMLGrafo();
        gravaArquivoDisco(xml, fileName);
    }

    private String montaXMLGrafo() {
        StringBuilder xml = new StringBuilder();
        xml.append("<classes>\n");
        listaClasseAtributoTipoAgrupado.entrySet().forEach(classe -> {
            xml.append("<classe");

            xml.append(" nome=\"");
            xml.append(classe.getValue().get(0).getNomeClasse());
            xml.append("\"");

            xml.append(" pacote=\"");
            xml.append(classe.getValue().get(0).getNomePacote());
            xml.append("\"");

            xml.append(">\n");

            montaXMLReferenciasFull(new ArrayList<>(), classe.getKey()).stream().distinct().forEach(s -> xml.append(s));

            xml.append("</classe>\n");
        });
        xml.append("</classes>");

        return xml.toString();
    }

    private List<String> montaXMLReferenciasFull(List<String> classesAnteriores, String classe) {

        List<String> listaReferenciasRetorno = new ArrayList<>();

        String[] packagesSplit = classe.split("\\.");
        String nomeClasse = packagesSplit[packagesSplit.length - 1];
        String pacote = classe.substring(0, classe.lastIndexOf("." + nomeClasse));
        listaReferenciasRetorno.add(geraXMLReferencia(nomeClasse, pacote));

        listaReferenciasRetorno.addAll(montaXMLReferencias(classesAnteriores, classe));

        return listaReferenciasRetorno;
    }

    private List<String> montaXMLReferencias(List<String> classesAnteriores, String nomeClasseCompleto) {

        List<String> referenciaJaMontada = mapClasseReferencias.get(nomeClasseCompleto);
        if (referenciaJaMontada != null)
            return referenciaJaMontada;

        classesAnteriores.add(nomeClasseCompleto);

        List<String> listaReferenciasRetorno = new ArrayList<>();

        List<ClasseAtributoTipo> listaReferencias = listaClasseAtributoTipoAgrupado.get(nomeClasseCompleto);
        listaReferencias = listaReferencias.stream()
                .filter(x -> mapClassePacote.get(x.getTipoAtributoJava()) != null)
                .collect(Collectors.toList());

        listaReferencias.forEach(referenciaDireta -> {
            String nomeClasseReferencia = referenciaDireta.getTipoAtributo().replace("()", "").replace("[]", "");
            String pacoteReferencia = mapClassePacote.get(nomeClasseReferencia);

            if (pacoteReferencia != null) {
                listaReferenciasRetorno.add(geraXMLReferencia(nomeClasseReferencia, pacoteReferencia));

                String nomeClasseCompletoReferencia = pacoteReferencia + "." + nomeClasseReferencia;

                if (!referenciaDireta.isCiclico()
                        && !nomeClasseCompleto.equals(nomeClasseCompletoReferencia)
                        && !classesAnteriores.contains(nomeClasseCompletoReferencia)) {

                    listaReferenciasRetorno.addAll(montaXMLReferencias(classesAnteriores, nomeClasseCompletoReferencia));
                }
            }
        });

        mapClasseReferencias.put(nomeClasseCompleto, listaReferenciasRetorno);

        return listaReferenciasRetorno;
    }

    private String geraXMLReferencia (String classe, String pacote) {
        StringBuilder xml = new StringBuilder();
        xml.append("<referencia");

        xml.append(" nome=\"");
        xml.append(classe);
        xml.append("\"");

        xml.append(" pacote=\"");
        xml.append(pacote);
        xml.append("\"");

        xml.append(" />\n");

        return xml.toString();
    }

    private void gravaArquivoDisco(String xml, String fileName) throws IOException {
        BufferedWriter writer = new BufferedWriter(new FileWriter(ConfigUtils.getInstance().getNormalizedPath(fileName)));
        writer.write(xml);
        writer.close();
    }
}
