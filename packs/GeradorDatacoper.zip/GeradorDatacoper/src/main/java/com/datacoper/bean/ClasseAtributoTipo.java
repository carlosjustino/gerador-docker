package com.datacoper.bean;

import java.util.ArrayList;
import java.util.List;

public class ClasseAtributoTipo {

    private String nomeClasse;
    private String nomePacote;
    private String nomeAtributo;
    private String tipoAtributo;
    private boolean ciclico;

    public boolean isCiclico() {
        return ciclico;
    }

    public void setCiclico(boolean ciclico) {
        this.ciclico = ciclico;
    }

    public String getNomeClasse() {
        return nomeClasse;
    }

    public void setNomeClasse(String nomeClasse) {
        this.nomeClasse = nomeClasse;
    }

    public String getNomeAtributo() {
        return nomeAtributo;
    }

    public void setNomeAtributo(String nomeAtributo) {
        this.nomeAtributo = nomeAtributo;
    }

    public String getTipoAtributo() {
        return tipoAtributo;
    }

    public void setTipoAtributo(String tipoAtributo) {
        this.tipoAtributo = tipoAtributo;
    }

    public String getNomePacote() {
        return nomePacote;
    }

    public void setNomePacote(String nomePacote) {
        this.nomePacote = nomePacote;
    }

    public String getNomeClasseCompleto (){
        return getNomePacote() + "." + getNomeClasse();
    }

    public String getTipoAtributoJava() {
        if (getTipoAtributo().startsWith("Inteiro(")) return "Integer";
        else if (getTipoAtributo().startsWith("InteiroPositivo(")) return "Integer";
        else if (getTipoAtributo().startsWith("Sequencial(")) return "Integer";
        else if (getTipoAtributo().startsWith("Long(")) return "Long";
        else if (getTipoAtributo().startsWith("AutoIncremento(")) return "Long";
        else if (getTipoAtributo().startsWith("Decimal(")) return "Double";
        else if (getTipoAtributo().startsWith("DecimalPositivo(")) return "Double";
        else if (getTipoAtributo().startsWith("Monetario(")) return "Decimal";
        else if (getTipoAtributo().startsWith("Logico(")) return "Boolean";
        else if (getTipoAtributo().startsWith("Texto(")) return "String";
        else if (getTipoAtributo().startsWith("TextoLongo(")) return "String";
        else if (getTipoAtributo().startsWith("Nome(")) return "String";
        else if (getTipoAtributo().startsWith("Arquivo(")) return "Long";
        else if (getTipoAtributo().startsWith("Data(")) return "Date";
        else if (getTipoAtributo().startsWith("DataHora(")) return "Date";
        else if (getTipoAtributo().startsWith("DataContexto(")) return "Date";
        else if (getTipoAtributo().startsWith("DataServidor(")) return "Date";
        else if (getTipoAtributo().startsWith("DataHoraServidor(")) return "Date";
        else return getTipoAtributo().replace("()", "").replace("[]", "");
    }

    public String getTipoAtributoSemPrecisao() {
        if (getTipoAtributo().indexOf("(") > 0)
            return getTipoAtributo().substring(0, getTipoAtributo().indexOf("("));
        else if (getTipoAtributo().indexOf("[") > 0)
            return getTipoAtributo().substring(0, getTipoAtributo().indexOf("["));
        else return getTipoAtributo();
    }
}
