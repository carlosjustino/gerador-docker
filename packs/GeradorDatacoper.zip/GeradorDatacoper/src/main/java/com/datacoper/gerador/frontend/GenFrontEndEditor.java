package com.datacoper.gerador.frontend;

import com.datacoper.gerador.Processor;
import com.datacoper.gerador.Transformation;

import java.util.concurrent.Callable;

import static com.datacoper.gerador.GenUtility.HOME_GEN;
import static com.datacoper.gerador.GenUtility.XML_CLASSES;

public class GenFrontEndEditor implements Transformation, Callable<Transformation> {

    public GenFrontEndEditor(){
    }

    @Override
    public void doTransformation() throws Exception {
        doTransformationTelaComplexaEditor();
    }

    @Override
    public Transformation call() throws Exception {
        doTransformation();
        return this;
    }

    private void doTransformationTelaComplexaEditor() throws Exception{

        String xslFile= HOME_GEN + "/src/main/java/v2/telaComplexa2Editor.xsl";
        String xmlFile= HOME_GEN + "/target/xmlListTelaComplexa.xml";
        String outFile= HOME_GEN + "/target/htmlTelaComplexaEditor.lst";

        String xmlListTelaSimplesCustomizada= HOME_GEN + "/target/xmlListTelaSimplesCustomizada.xml";
        String htmlTelaComplexaSourcePath= System.getenv("HOME_JNG_URL") + "/app/tpls";

        StringBuilder sbParam = new StringBuilder();
        sbParam.append("htmlTelaComplexaSourcePath=");
        sbParam.append(htmlTelaComplexaSourcePath);
        sbParam.append(" ");
        sbParam.append("xmlClasses=");
        sbParam.append(XML_CLASSES);
        sbParam.append(" ");
        sbParam.append("xmlListTelaSimplesCustomizada=");
        sbParam.append(xmlListTelaSimplesCustomizada);
        sbParam.append(" ");
        sbParam.append("sistemaOperacional=");
        sbParam.append(System.getenv("OS"));

        new Processor().run(xslFile,xmlFile,outFile,sbParam.toString());

    }

}
