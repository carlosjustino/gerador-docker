package com.datacoper.gerador;

import net.sf.saxon.expr.XPathContext;
import net.sf.saxon.om.Item;
import net.sf.saxon.om.NodeInfo;
import net.sf.saxon.trans.XPathException;

import javax.xml.transform.ErrorListener;
import javax.xml.transform.SourceLocator;
import javax.xml.transform.TransformerException;
import java.util.Date;

public class DatacoperSaxonErrorListener implements ErrorListener{

    private boolean PRINT_ALL_EXCEPTION = GenUtility.getVariable("PRINT_ALL_EXCEPTION");
    @Override
    public void warning(TransformerException ex) throws TransformerException {
        //ex.printStackTrace();
        printLocation(ex.getLocator());
        printError(ex);
    }

    @Override
    public void error(TransformerException ex) throws TransformerException {
        System.err.println("Error " + new Date());
        printLocation(ex.getLocator());
        printError(ex);
    }

    @Override
    public void fatalError(TransformerException ex) throws TransformerException {
        System.err.println("Fatal Error" + new Date());
        printLocation(ex.getLocator());
        printError(ex);
    }


    private void printLocation(SourceLocator sourceLocator){
        if (sourceLocator != null) {
            System.err.println("Arquivo XSL: " + sourceLocator.getSystemId());
            System.err.println("PublicID: " + sourceLocator.getPublicId());
            System.err.println("ColumnNumber: " + sourceLocator.getColumnNumber());
            System.err.println("LineNumber: " + sourceLocator.getLineNumber());
        }
    }

    private void printError(TransformerException ex){
        System.err.println("Error Message: " + ex.getMessage());
        System.err.println("Localized Message: " + ex.getLocalizedMessage());
        if (PRINT_ALL_EXCEPTION) ex.printStackTrace();
    }

}
