package com.datacoper.gerador;

import net.sf.saxon.lib.StandardLogger;
import net.sf.saxon.lib.TraceListener;
import net.sf.saxon.s9api.Processor;
import net.sf.saxon.s9api.*;
import net.sf.saxon.trace.TimingCodeInjector;
import net.sf.saxon.trace.TimingTraceListener;

import javax.xml.transform.stream.StreamSource;
import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.HashMap;
import java.util.Map;

/*
 @autor Carlos Justino
 @date 08/09/2017
 */
public class ProcessaXSLTSaxon implements Processador {

    private String arquivoXsl;
    private String arquivoEntrada;
    private String arquivoSaida;
    private String parametros;
    private ConfigUtils instanceConfigUtils;
    private boolean profile = false;
    private String profileFileName = null;


    @Override
    public boolean isProfile() {
        return profile;
    }

    @Override
    public void setProfile(boolean profile) {
        this.profile = profile;
    }

    @Override
    public String getProfileFileName() {
        return profileFileName;
    }

    @Override
    public void setProfileFileName(String profileFileName) {
        this.profileFileName = profileFileName;
    }

    public ProcessaXSLTSaxon(){
        reset();
    }

    @Override
    public void init(String arquivoXsl, String arquivoEntrada, String arquivoSaida, String parametros) {
        this.arquivoXsl = arquivoXsl;
        this.arquivoEntrada = arquivoEntrada;
        this.arquivoSaida = arquivoSaida;
        this.parametros = parametros;
    }

    @Override
    public void reset(){
        this.instanceConfigUtils = ConfigUtils.getInstance();
        this.arquivoXsl = null;
        this.arquivoEntrada = null;
        this.arquivoSaida = null;
        this.parametros = null;
    }





    @Override
    public void run() throws Exception {
        Processor processor = new Processor(false);
        GenUtility.printInfo("Inicio " + GenUtility.currentDateTime() + " ["+ GenUtility.getNomeArquivoXslt(arquivoXsl) +"]");
        long tempoInicial = System.currentTimeMillis();
        if (instanceConfigUtils.isShowInfoXLSTFile()) System.out.println(" XSL: " + arquivoXsl);
        XsltCompiler compiler = processor.newXsltCompiler();
        //compiler.setCompileWithTracing(true);
        compiler.setErrorListener(new DatacoperSaxonErrorListener());
        compiler.setGenerateByteCode(true);
        compiler.setTargetEdition("HE");

        if (instanceConfigUtils.isShowInfoTimeCompileXLST()) System.out.println("-- Compilando XSL...");
        long tempoInicialComp = System.currentTimeMillis();

        if (isProfile()){
            TraceListener traceListener = new TimingTraceListener();
            processor.setConfigurationProperty("http://saxon.sf.net/feature/traceListener", traceListener);
            processor.setConfigurationProperty("http://saxon.sf.net/feature/linenumbering", Boolean.valueOf(true));
            processor.setConfigurationProperty("http://saxon.sf.net/feature/timing", Boolean.valueOf(true));
            compiler.getUnderlyingCompilerInfo().setCodeInjector(new TimingCodeInjector());
            if (getProfileFileName() != null ) {
                compiler.getUnderlyingCompilerInfo().getConfiguration().setStandardErrorOutput(new PrintStream(
                        new FileOutputStream(getProfileFileName().replace(".html", "Timing.txt"), true)));
                traceListener.setOutputDestination(new StandardLogger(new File(getProfileFileName())));
            }
        }
        File sourceFile = new File(arquivoXsl);
        StreamSource streamSource = new StreamSource(sourceFile);
        streamSource.setSystemId(sourceFile);
        XsltExecutable exp = compiler.compile(streamSource);
        XdmNode source = processor.newDocumentBuilder().build(new StreamSource(new File(arquivoEntrada)));
        Serializer out = processor.newSerializer(new File(arquivoSaida));
        Xslt30Transformer trans = exp.load30();
        Map<QName, XdmValue> params = new HashMap<>();
        trans.setGlobalContextItem(source);
        if (parametros != null && !parametros.equals("")){
            String[] pars =parametros.split(" ");
            for (int x=0 ; x < pars.length; x++){
                String param = pars[x].substring(0, pars[x].indexOf("="));
                String value = pars[x].substring(pars[x].indexOf("=") + 1);
                XdmValue v = new XdmAtomicValue(value);
                QName name = new QName(param);
                params.put(name,v);
            }
            trans.setStylesheetParameters(params);
        }

        long tempoFinalComp = System.currentTimeMillis();
        if (instanceConfigUtils.isShowInfoTimeCompileXLST()) System.out.printf("-- Tempo total Compilacao: %.3f ms%n", (tempoFinalComp - tempoInicialComp) / 1000d);
        trans.applyTemplates(source,out);
        long tempoFinal = System.currentTimeMillis();
        System.out.printf("--- Tempo total ["+ GenUtility.getNomeArquivoXslt(arquivoXsl) +" "+(params.getOrDefault("classeAlvo",new XdmAtomicValue("")))+"]: %.3f ms%n", (tempoFinal - tempoInicial) / 1000d);
    }




}
