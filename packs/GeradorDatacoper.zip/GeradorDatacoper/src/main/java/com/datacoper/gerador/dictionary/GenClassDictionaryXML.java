package com.datacoper.gerador.dictionary;

import com.datacoper.bean.ClasseAtributoTipo;
import com.datacoper.bean.MindMapNode;
import com.datacoper.bean.Pacote;
import com.datacoper.gerador.GenUtility;

import java.util.*;
import java.util.stream.Collectors;

public class GenClassDictionaryXML {

    private List<Pacote> listaPacotes = new ArrayList<>();
    private List<ClasseAtributoTipo> listaClasseAtributoTipoCompleta = new ArrayList<>();

    public GenClassDictionaryXML(List<Pacote> listaPacotes, List<ClasseAtributoTipo> listaClasseAtributoTipoCompleta) {
        this.listaPacotes = listaPacotes;
        this.listaClasseAtributoTipoCompleta = listaClasseAtributoTipoCompleta;
    }

    public String gerarXml(String target) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("<classes>\n");

        List<String> classesTarget = target != null && target != "ND" ? Arrays.asList(target.split(",")) : new ArrayList<>();
        logInfoClassesTarget(classesTarget);

        GenClassDictionaryXMLClass genClassDictionaryXMLClass = new GenClassDictionaryXMLClass(listaPacotes, listaClasseAtributoTipoCompleta);

        listaPacotes.forEach(pacote -> {
            for(AbstractMap.SimpleEntry classeEntry : pacote.getClasses()) {
                if (classesTarget.isEmpty() || classesTarget.contains(classeEntry.getKey()))
                    stringBuilder.append(genClassDictionaryXMLClass.geraXmlDicionarioClasse("", pacote.getCompoundName(), (MindMapNode) classeEntry.getValue()));
            }
        });
        stringBuilder.append("</classes>");

        return stringBuilder.toString();
    }

    private void logInfoClassesTarget(List<String> classesTarget) {
        if (classesTarget.isEmpty())
            return;

        String target = "";
        int contador = 0;
        for (String classe : classesTarget) {
            contador ++;
            if (contador < 4) {
                if (!"".equals(target))
                    target += ",";
                target += classe;
            }
        }

        if (classesTarget.size() > 3)
            target += " e mais " + (classesTarget.size() - 3);
        GenUtility.printInfoColorless("Gerando dicionario para a(s) classe(s): " + target);
    }
}
