package com.datacoper.gerador.backend;

import com.datacoper.gerador.Processor;
import com.datacoper.gerador.Transformation;

import java.util.concurrent.Callable;

import static com.datacoper.gerador.GenUtility.HOME_GEN;
import static com.datacoper.gerador.GenUtility.XML_CLASSES;

public class GenBackEndRestContainer implements Transformation , Callable<Transformation> {

    String target = "ND";

    public GenBackEndRestContainer(String target){
        if (target != null) this.target = target;
    }


    @Override
    public void doTransformation() throws Exception {
        doTransformationBackEndRestContainer();
    }

    private void doTransformationBackEndRestContainer() throws Exception{

        String javaSourcePath=System.getenv("HOME_REST_API_URL") + "/src/main/java";

        String xsltFile = HOME_GEN + "/src/main/java/v2/dicionario2restContainer.xsl";
        String xmlFile=XML_CLASSES;
        String outFile=System.getenv("HOME_TEMP") + "/containerRestSource.lst";

        StringBuilder sbParam = new StringBuilder();
        sbParam.append("javaSourcePath=");
        sbParam.append(javaSourcePath);

        sbParam.append(" ");
        sbParam.append("sistemaOperacional=");
        sbParam.append(System.getenv("OS"));
        sbParam.append(" ");
        sbParam.append("classeAlvo=");
        sbParam.append(target);
        new Processor().run(xsltFile,xmlFile,outFile,sbParam.toString());

    }

    @Override
    public Transformation call() throws Exception {
        doTransformation();
        return this;
    }

}
