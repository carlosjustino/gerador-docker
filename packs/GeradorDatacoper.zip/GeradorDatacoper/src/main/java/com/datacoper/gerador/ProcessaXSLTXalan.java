package com.datacoper.gerador;

import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

/*
 @autor Carlos Justino
 @date 08/09/2017
 */
public class ProcessaXSLTXalan implements Processador{

    private String arquivoXsl;
    private String arquivoEntrada;
    private String arquivoSaida;
    private ConfigUtils instanceConfigUtils;

    private boolean profile = false;
    private String profileFileName = null;

    @Override
    public boolean isProfile() {
        return profile;
    }

    @Override
    public void setProfile(boolean profile) {
        this.profile = profile;
    }

    @Override
    public String getProfileFileName() {
        return profileFileName;
    }

    @Override
    public void setProfileFileName(String profileFileName) {
        this.profileFileName = profileFileName;
    }


    public ProcessaXSLTXalan (){
        reset();
    }


    @Override
    public void init(String arquivoXsl, String arquivoEntrada, String arquivoSaida, String parametros) {
        this.arquivoXsl = arquivoXsl;
        this.arquivoEntrada = arquivoEntrada;
        this.arquivoSaida = arquivoSaida;
        //this.parametros = parametros;
    }

    @Override
    public void reset(){
        this.instanceConfigUtils = ConfigUtils.getInstance();
        this.arquivoXsl = null;
        this.arquivoEntrada = null;
        this.arquivoSaida = null;
        //this.parametros = null;
    }

    @Override
    public void run() throws Exception  {
        GenUtility.printInfo("Inicio " + GenUtility.currentDateTime() + " ["+ GenUtility.getNomeArquivoXslt(arquivoXsl) +"]");
        long tempoInicial = System.currentTimeMillis();
        System.setProperty("org.apache.xalan.extensions.bsf.BSFManager","org.apache.bsf.BSFManager");
        System.setProperty("javax.xml.transform.TransformerFactory", "org.apache.xalan.processor.TransformerFactoryImpl");
        TransformerFactory tFactory = TransformerFactory.newInstance();
        Transformer transformer = tFactory.newTransformer(new StreamSource(arquivoXsl));
        transformer.reset();
        transformer.transform
                (new StreamSource(arquivoEntrada),
                        new StreamResult(new java.io.FileOutputStream(arquivoSaida)));

        long tempoFinal = System.currentTimeMillis();
        System.out.printf("--- Tempo total ["+ GenUtility.getNomeArquivoXslt(arquivoXsl) +"]: %.3f ms%n", (tempoFinal - tempoInicial) / 1000d);
    }
}
