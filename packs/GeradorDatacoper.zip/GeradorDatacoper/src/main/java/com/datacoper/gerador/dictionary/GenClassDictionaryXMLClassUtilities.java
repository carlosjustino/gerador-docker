package com.datacoper.gerador.dictionary;

import com.datacoper.bean.ClasseAtributoTipo;
import com.datacoper.bean.MindMapNode;

import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.List;

public class GenClassDictionaryXMLClassUtilities {

    private List<ClasseAtributoTipo> listaClasseAtributoTipoCompleta = new ArrayList<>();

    public GenClassDictionaryXMLClassUtilities(List<ClasseAtributoTipo> listaClasseAtributoTipoCompleta) {
        this.listaClasseAtributoTipoCompleta = listaClasseAtributoTipoCompleta;
    }

    public String geraDicionarioUtilitarios(String recuoAnterior, MindMapNode nodeClasse) {
        StringBuilder stringUtilitarios = new StringBuilder();
        String recuoAtual = recuoAnterior + "\t";

        MindMapNode nodeUtilitarios = nodeClasse.childByTextEquals("utilitario");
        if (nodeUtilitarios != null) {
            stringUtilitarios.append(recuoAtual);
            stringUtilitarios.append("<utilitarios root=\"sim\">\n");

            List<MindMapNode> nodesUtilitarios = GenClassDictionaryXMLUtil.getListaMetodosFromNode(nodeUtilitarios);

            nodesUtilitarios.forEach(mindMapNode -> {
                stringUtilitarios.append(geraDicionarioUtilitario(recuoAtual, mindMapNode));
            });

            stringUtilitarios.append(recuoAtual);
            stringUtilitarios.append("</utilitarios>\n");
        }

        return stringUtilitarios.toString();
    }

    private String geraDicionarioUtilitario(String recuoAnterior, MindMapNode nodeUtilitario) {
        StringBuilder stringUtilitario = new StringBuilder();
        String recuoAtual = recuoAnterior + "\t";

        AbstractMap.SimpleEntry<String, String> utilitarioNomeRetorno = GenClassDictionaryXMLUtil.getNomeTipoAtributo(listaClasseAtributoTipoCompleta, nodeUtilitario.getAtributoTEXT());


        stringUtilitario.append(recuoAtual);
        stringUtilitario.append("<utilitario");

        stringUtilitario.append(" nome=\"");
        stringUtilitario.append(utilitarioNomeRetorno.getKey());
        stringUtilitario.append("\"");

        if (!"".equals(utilitarioNomeRetorno.getValue())) {
            stringUtilitario.append(" tipoRetorno=\"");
            stringUtilitario.append(utilitarioNomeRetorno.getValue());
            stringUtilitario.append("\"");
        }

        stringUtilitario.append(" revisado=\"");
        stringUtilitario.append("S");
        stringUtilitario.append("\"");

        stringUtilitario.append(" acesso=\"");
        stringUtilitario.append("private".equals(nodeUtilitario.getPai().getAtributoTEXT()) ? "private" : "public");
        stringUtilitario.append("\"");

        stringUtilitario.append(">\n");

        stringUtilitario.append(GenClassDictionaryXMLUtil.geraXmlInstrucao(recuoAtual, nodeUtilitario.getFilhos(), listaClasseAtributoTipoCompleta));

        stringUtilitario.append(recuoAtual);
        stringUtilitario.append("</utilitario>\n");

        return stringUtilitario.toString();
    }
}
