package com.datacoper.gerador.report;

import com.datacoper.gerador.Processor;
import com.datacoper.gerador.Transformation;

import static com.datacoper.gerador.GenUtility.HOME_GEN;
import static com.datacoper.gerador.GenUtility.XML_CLASSES;

public class GenReportsFunctions implements Transformation {


    public GenReportsFunctions(){

    }

    @Override
    public void doTransformation() throws Exception {
        doTransformationReportFunctions();
    }

    private void doTransformationReportFunctions() throws Exception{
        String xslFile= HOME_GEN + "/src/main/java/v2/telaComplexa2Functions.xsl";
        String xmlFile= HOME_GEN + "/target/xmlListRelatorio_sync.xml";
        String outFile= HOME_GEN + "/target/fnRelatorio";
        String functionsSourcePath=System.getenv("HOME_JNG_URL") + "/app/functions";

        StringBuilder sbParam = new StringBuilder();
        sbParam.append("functionsSourcePath=");
        sbParam.append(functionsSourcePath);
        sbParam.append(" ");
        sbParam.append("xmlClasses=");
        sbParam.append(XML_CLASSES);
        sbParam.append(" ");
        sbParam.append("sistemaOperacional=");
        sbParam.append(System.getenv("OS"));
        sbParam.append(" ");
        sbParam.append("ativarBlockUI=");
        sbParam.append(System.getenv("ACTIVATE_BLOCKUI"));

        new Processor().run(xslFile,xmlFile,outFile,sbParam.toString());

    }

}
