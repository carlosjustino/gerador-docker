package com.datacoper.gerador.backend;

import com.datacoper.gerador.Processor;
import com.datacoper.gerador.Transformation;

import java.util.concurrent.Callable;

import static com.datacoper.gerador.GenUtility.HOME_GEN;
import static com.datacoper.gerador.GenUtility.XML_CLASSES;

public class GenPersistenceXML implements Transformation, Callable<Transformation> {
    private boolean geradorSQL = false;

    public GenPersistenceXML(boolean geradorSQL){
        this.geradorSQL = geradorSQL;
    }
    public GenPersistenceXML(){
        this(false);
    }

    @Override
    public void doTransformation() throws Exception {
        doTransformationPersistenceXml();
    }

    private void doTransformationPersistenceXml() throws Exception{
        String xsltFile = HOME_GEN + "/src/main/java/v2/dicionario2persistenceXml.xsl";
        String xmlFile=XML_CLASSES;
        String outFile="/src/main/resources/META-INF/persistence.xml";
        if (geradorSQL){
            outFile= System.getenv("HOME_GERADORSQL") + outFile;
        }else{
            outFile= System.getenv("HOME_CORE") + outFile;
        }


        StringBuilder sbParam = new StringBuilder();
        sbParam.append("projectName=");
        sbParam.append(System.getenv("PROJECT_NAME"));
        sbParam.append(" ");
        sbParam.append("geradorSQL=");
        sbParam.append(Boolean.toString(geradorSQL));
        new Processor().run(xsltFile,xmlFile,outFile,sbParam.toString());

    }

    @Override
    public Transformation call() throws Exception {
        doTransformation();
        return this;
    }
}
