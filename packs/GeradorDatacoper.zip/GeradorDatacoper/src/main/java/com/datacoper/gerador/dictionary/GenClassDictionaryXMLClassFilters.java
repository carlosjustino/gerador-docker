package com.datacoper.gerador.dictionary;

import com.datacoper.bean.MindMapNode;

import java.util.List;
import java.util.stream.Collectors;

public class GenClassDictionaryXMLClassFilters {

    public String geraDicionarioFiltrosSeletores(String recuoAnterior, MindMapNode nodeInterface) {
        StringBuilder stringFiltro = new StringBuilder();
        String recuoAtual = recuoAnterior + "\t";

        MindMapNode folder_magnify = nodeInterface.childByIcon("folder_magnify");
        if (folder_magnify != null) {
            stringFiltro.append(recuoAtual);
            stringFiltro.append("<filtros>\n");

            List<MindMapNode> seletores = folder_magnify.getFilhos().stream().filter(x -> "xmag".equals(x.getAtributoIcon())).collect(Collectors.toList());

            seletores.forEach(mindMapNode -> stringFiltro.append(geraDicionarioFiltroSeletor(recuoAtual, mindMapNode)));

            stringFiltro.append(recuoAtual);
            stringFiltro.append("</filtros>\n");
        }

        return stringFiltro.toString();
    }

    private String geraDicionarioFiltroSeletor(String recuoAnterior, MindMapNode seletorNode) {
        StringBuilder stringSeletor = new StringBuilder();
        String recuoAtual = recuoAnterior + "\t";

        MindMapNode cogNode = seletorNode.childByIcon("cog");

        stringSeletor.append(recuoAtual);
        stringSeletor.append("<seletor");

        stringSeletor.append(" nome=\"");
        stringSeletor.append(seletorNode.getAtributoTEXT());
        stringSeletor.append("\"");

        stringSeletor.append(" default=\"");
        stringSeletor.append(cogNode != null && cogNode.getFilhos().stream().anyMatch(x -> "bookmark".equals(x.getAtributoIcon())));
        stringSeletor.append("\"");

        stringSeletor.append(">\n");

        stringSeletor.append(geraDicionarioFiltroSeletorConfig(recuoAtual, seletorNode));

        stringSeletor.append(recuoAtual);
        stringSeletor.append("</seletor>\n");

        return stringSeletor.toString();
    }

    private String geraDicionarioFiltroSeletorConfig(String recuoAnterior, MindMapNode seletorNode) {
        StringBuilder stringConfig = new StringBuilder();
        String recuoAtual = recuoAnterior + "\t";

        stringConfig.append(recuoAtual);
        stringConfig.append("<configSeletor>\n");

        stringConfig.append(geraDicionarioFiltroSeletorConfigFiltro(recuoAtual, seletorNode));
        stringConfig.append(geraDicionarioFiltroSeletorConfigLista(recuoAtual, seletorNode));
        stringConfig.append(geraDicionarioFiltroSeletorConfigFiltroOrdenacao(recuoAtual, seletorNode));

        stringConfig.append(recuoAtual);
        stringConfig.append("</configSeletor>\n");

        return stringConfig.toString();
    }

    private String geraDicionarioFiltroSeletorConfigLista(String recuoAnterior, MindMapNode seletorNode) {
        StringBuilder stringLista = new StringBuilder();
        String recuoAtual = recuoAnterior + "\t";

        MindMapNode listaNode = seletorNode.childByIcon("list");
        if (listaNode != null) {
            stringLista.append(recuoAtual);
            stringLista.append("<lista>\n");

            listaNode.getFilhos().stream().filter(x -> !"icon".equals(x.getNodeName())).forEach(mindMapNode -> {
                stringLista.append(geraDicionarioFiltroSeletorConfigListaCampo(recuoAtual, mindMapNode));
            });

            stringLista.append(recuoAtual);
            stringLista.append("</lista>\n");
        }

        return stringLista.toString();
    }

    private String geraDicionarioFiltroSeletorConfigListaCampo(String recuoAnterior, MindMapNode nodeCampo) {
        StringBuilder stringCampo = new StringBuilder();
        String recuoAtual = recuoAnterior + "\t";

        stringCampo.append(recuoAtual);
        stringCampo.append("<campo");

        stringCampo.append(" ref=\"");
        stringCampo.append(nodeCampo.getAtributoTEXT());
        stringCampo.append("\"");

        if ("text_heading_1".equals(nodeCampo.getAtributoIcon()))
            stringCampo.append(" h1=\"true\"");

        MindMapNode nodeTitulo = nodeCampo.childByIcon("text_heading_2");
        if (nodeTitulo != null) {
            stringCampo.append(">\n");
            stringCampo.append(recuoAtual);
            stringCampo.append("\t<titulo>");
            stringCampo.append(nodeTitulo.getAtributoTEXT());
            stringCampo.append("</titulo>\n");

            stringCampo.append(recuoAtual);
            stringCampo.append("</campo>\n");
        } else {
            stringCampo.append(" />\n");
        }

        return stringCampo.toString();
    }

    private String geraDicionarioFiltroSeletorConfigFiltro(String recuoAnterior, MindMapNode seletorNode) {
        StringBuilder stringFiltro = new StringBuilder();

        MindMapNode nodeFilterFixo = seletorNode.childByIcon("filterfixo");
        if (nodeFilterFixo != null) {
            stringFiltro.append(geraDicionarioFiltroSeletorConfigFiltroFixo(recuoAnterior, nodeFilterFixo));
        } else {
            MindMapNode nodeFilter = seletorNode.childByIcon("filter");
            if (nodeFilter != null) {
                stringFiltro.append(geraDicionarioFiltroSeletorConfigFiltroServico(recuoAnterior, nodeFilter));
            }
        }

        return stringFiltro.toString();
    }

    private String geraDicionarioFiltroSeletorConfigFiltroOrdenacao(String recuoAnterior, MindMapNode seletorNode) {
        StringBuilder stringOrdenacao = new StringBuilder();
        String recuoAtual = recuoAnterior + "\t";

        MindMapNode nodeOrdenacao = seletorNode.childByIcon("up");
        if (nodeOrdenacao != null) {
            stringOrdenacao.append(recuoAtual);
            stringOrdenacao.append("<ordenarPor ordem=\"ASC\">");
            stringOrdenacao.append(nodeOrdenacao.getAtributoTEXT());
            stringOrdenacao.append("</ordenarPor>\n");
        } else {
            nodeOrdenacao = seletorNode.childByIcon("down");
            if (nodeOrdenacao != null) {
                stringOrdenacao.append(recuoAtual);
                stringOrdenacao.append("<ordenarPor ordem=\"DESC\">");
                stringOrdenacao.append(nodeOrdenacao.getAtributoTEXT());
                stringOrdenacao.append("</ordenarPor>\n");
            }
        }

        return stringOrdenacao.toString();
    }

    private String geraDicionarioFiltroSeletorConfigFiltroServico(String recuoAnterior, MindMapNode nodeFilter) {
        StringBuilder filterServico = new StringBuilder();
        String recuoAtual = recuoAnterior + "\t";

        filterServico.append(recuoAtual);
        filterServico.append("<filtro>\n");

        filterServico.append(recuoAtual);
        filterServico.append("\t<servico>\n");

        filterServico.append(recuoAtual);
        filterServico.append("\t\t<instruction>");
        filterServico.append("{{auto.list}} = ");

        if (nodeFilter.getFilhos().stream().anyMatch(x -> !"icon".equals(x.getNodeName()))) {
            MindMapNode nodeChamadaServico = nodeFilter.getFilhos().stream().filter(x -> !"icon".equals(x.getNodeName())).findAny().get();
            if (nodeChamadaServico.getFilhos().isEmpty()) {
                filterServico.append(nodeChamadaServico.getAtributoTEXT());
            } else {
                filterServico.append(nodeChamadaServico.getAtributoTEXT().replace("()", "("));
                for(int i = 0; i < nodeChamadaServico.getFilhos().size(); i++) {
                    if (i > 0)
                        filterServico.append(",");
                    filterServico.append("{{");
                    filterServico.append(i + 1);
                    filterServico.append("}}");
                }
                filterServico.append(")");
            }
        }

        filterServico.append("</instruction>\n");

        filterServico.append(recuoAtual);
        filterServico.append("\t</servico>\n");

        filterServico.append(recuoAtual);
        filterServico.append("</filtro>\n");

        return filterServico.toString();
    }

    private String geraDicionarioFiltroSeletorConfigFiltroFixo(String recuoAnterior, MindMapNode nodeFilterFixo) {
        StringBuilder filterFixo = new StringBuilder();
        String recuoAtual = recuoAnterior + "\t";

        filterFixo.append(recuoAtual);
        filterFixo.append("<filtro>\n");

        List<MindMapNode> listaNodesCondicoes = nodeFilterFixo.getFilhos().stream()
                .filter(predicado -> !"icon".equals(predicado.getNodeName()))
                .collect(Collectors.toList());
        int countParameterSemCondicao = 0;
        for (MindMapNode nodeCondicao : listaNodesCondicoes) {

            filterFixo.append(recuoAtual);
            filterFixo.append("\t<instruction>");
            filterFixo.append(nodeCondicao.getAtributoTEXT());

            if (!nodeCondicao.getFilhos().isEmpty()) {
                if ("pencil_go".equals(nodeCondicao.getFilhos().get(0).getAtributoIcon())) {
                    filterFixo.append(" = ");
                    filterFixo.append(nodeCondicao.getFilhos().get(0).getAtributoTEXT());
                } else {
                    countParameterSemCondicao ++;
                    filterFixo.append(" = ");
                    filterFixo.append("{{");
                    filterFixo.append(countParameterSemCondicao);
                    filterFixo.append("}}");
                }
            }

            filterFixo.append("</instruction>\n");
        }

        filterFixo.append(recuoAtual);
        filterFixo.append("</filtro>\n");

        return filterFixo.toString();
    }
}
