package com.datacoper.gerador.dictionary;

import com.datacoper.bean.ClasseAtributoTipo;
import com.datacoper.bean.MindMapNode;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class GenClassDictionaryXMLClassIndexes {

    List<ClasseAtributoTipo> listaClasseAtributoTipoCompleta = new ArrayList<>();

    public GenClassDictionaryXMLClassIndexes(List<ClasseAtributoTipo> listaClasseAtributoTipoCompleta) {
        this.listaClasseAtributoTipoCompleta = listaClasseAtributoTipoCompleta;
    }

    public String geraDicionarioIndices(String recuoAnterior, MindMapNode nodeObjeto) {
        StringBuilder stringIndices = new StringBuilder();
        String recuoAtual = recuoAnterior + "\t";

        MindMapNode nodeIndice = nodeObjeto.childByTextEquals("indice");
        if (nodeIndice != null) {
            stringIndices.append(recuoAtual);
            stringIndices.append("<indices root=\"sim\">\n");

            List<MindMapNode> nodesIndice = nodeIndice.getFilhos().stream()
                    .filter(x -> Arrays.asList("tag_key-unique", "tag_key-duplicate").contains(x.getAtributoIcon()))
                    .collect(Collectors.toList());
            nodesIndice.forEach(mindMapNode -> stringIndices.append(geraDicionarioIndice(recuoAtual, mindMapNode)));

            stringIndices.append(recuoAtual);
            stringIndices.append("</indices>\n");
        }

        return stringIndices.toString();
    }

    private String geraDicionarioIndice(String recuoAnterior, MindMapNode nodeIndice) {
        StringBuilder stringIndice = new StringBuilder();
        String recuoAtual = recuoAnterior + "\t";

        stringIndice.append(recuoAtual);
        stringIndice.append("<indice");

        stringIndice.append(" unico=\"");
        stringIndice.append("tag_key-unique".equals(nodeIndice.getAtributoIcon()) ? "S" : "N");
        stringIndice.append("\"");

        stringIndice.append(" nome=\"");
        stringIndice.append(nodeIndice.getAtributoTEXT());
        stringIndice.append("\"");

        if (nodeIndice.getFilhos().stream().anyMatch(x -> "intersecao-bloqueado".equals(x.getAtributoIcon()))) {
            stringIndice.append(" isintersecao=\"");
            stringIndice.append("S");
            stringIndice.append("\"");
        }

        stringIndice.append(">\n");

        MindMapNode nodeIf = nodeIndice.childByTextEquals("if");
        if (nodeIf != null)
            stringIndice.append(GenClassDictionaryXMLUtil.geraXmlInstrucao(recuoAtual, Arrays.asList(nodeIf), listaClasseAtributoTipoCompleta));

        nodeIndice.getFilhos().stream()
                .filter(x -> !"icon".equals(x.getNodeName()) && !"if".equals(x.getAtributoTEXT()))
                .forEach(mindMapNode -> {
            stringIndice.append(geraDicionarioIndiceCampo(recuoAtual, mindMapNode));
        });

        stringIndice.append(recuoAtual);
        stringIndice.append("</indice>\n");

        return stringIndice.toString();
    }

    private String geraDicionarioIndiceCampo(String recuoAnterior, MindMapNode nodeCampo) {
        StringBuilder stringCampo = new StringBuilder();
        String recuoAtual = recuoAnterior + "\t";

        if ("intersecao-bloqueado".equals(nodeCampo.getAtributoIcon())) {
            stringCampo.append(recuoAtual);
            stringCampo.append("<intersecao>\n");

            nodeCampo.getFilhos().stream().filter(x -> !"icon".equals(x.getNodeName())).forEach(mindMapNode -> {
                stringCampo.append(geraDicionarioIndiceCampo(recuoAtual, mindMapNode));
            });

            stringCampo.append(recuoAtual);
            stringCampo.append("</intersecao>\n");

        } else {
            stringCampo.append(recuoAtual);
            stringCampo.append("<campo");

            stringCampo.append(" ref=\"");
            stringCampo.append(nodeCampo.getAtributoTEXT());
            stringCampo.append("\"");

            stringCampo.append(" />\n");
        }

        return stringCampo.toString();
    }
}
