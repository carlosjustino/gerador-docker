package com.datacoper.gerador.backend;

import com.datacoper.gerador.Processor;
import com.datacoper.gerador.Transformation;

import static com.datacoper.gerador.GenUtility.HOME_GEN;
import static com.datacoper.gerador.GenUtility.XML_CLASSES;

public class GenBackEndValidationCode implements Transformation {

    String target = "ND";

    public GenBackEndValidationCode(String target){
        if (target != null) this.target = target;
    }


    @Override
    public void doTransformation() throws Exception {
        doTransformationBackEndValidationCode();
    }

    private void doTransformationBackEndValidationCode() throws Exception{

        String xsltFile = HOME_GEN + "/src/main/java/v2/dicionario2validateCode.xsl";
        String xmlFile=XML_CLASSES;
        String outFile=HOME_GEN + "/validaCodigo.txt";

        StringBuilder sbParam = new StringBuilder();
        sbParam.append("classeAlvo=");
        sbParam.append(target);
        new Processor().run(xsltFile,xmlFile,outFile,sbParam.toString());

    }

}
