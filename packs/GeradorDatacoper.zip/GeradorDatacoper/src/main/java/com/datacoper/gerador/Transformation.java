package com.datacoper.gerador;

public interface Transformation {

    void doTransformation() throws Exception;
}
