package com.datacoper.gerador.frontend.unittest;

import com.datacoper.gerador.Processor;
import com.datacoper.gerador.Transformation;

import static com.datacoper.gerador.GenUtility.HOME_GEN;

public class GenTestMenuPrincipalSistema implements Transformation {


    public GenTestMenuPrincipalSistema(){
    }

    @Override
    public void doTransformation() throws Exception {
        doTransformationTestMenuPrincipalSistemaXmlRotinas();
    }

    private void doTransformationTestMenuPrincipalSistemaXmlRotinas() throws Exception{
        String xsltFile = HOME_GEN + "/src/main/java/v2/menuPrincipalSistema2XmlRotinas.xsl";
        String xmlFile=HOME_GEN + "/target/menuPrincipalSistema.xml";
        String outFile=HOME_GEN + "/target/xmlRotinas.xml";

        new Processor().run(xsltFile,xmlFile,outFile,null);

    }


}
