package com.datacoper.gerador.dictionary;

import com.datacoper.bean.ClasseAtributoTipo;
import com.datacoper.bean.MindMapNode;
import com.datacoper.bean.Pacote;
import com.datacoper.gerador.GenUtility;
import com.datacoper.parser.MindMapParserUtil;

import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

public class GenClassAttributeDictionary {

    private List<Pacote> listaPacote = new ArrayList<>();
    private List<MindMapNode> listaClassesCompleta = new ArrayList<>();
    private List<ClasseAtributoTipo> listaClasseAtributoTipo = new ArrayList<>();
    private final List<String> listaIconesAtributosValidos = Arrays.asList("tag_green", "tag_red", "tag_yellow", "link", "link_add", "link_ciclico", "link_delete", "folder_table", "folder_table_dependent");
    private final List<String> listaIconesColecao = Arrays.asList("folder_table", "folder_table_dependent");
    private List<MindMapNode> listaNodeReferenciaClasseConcreta = new ArrayList<>();

    public GenClassAttributeDictionary(List<Pacote> listaPacote) {
        this.listaPacote = listaPacote;
        listaPacote.forEach(pacote -> {
            for(AbstractMap.SimpleEntry classeEntry : pacote.getClasses())
                listaClassesCompleta.add((MindMapNode) classeEntry.getValue());
        });
        this.listaNodeReferenciaClasseConcreta = MindMapParserUtil.findNodesDownByIcon(listaClassesCompleta, "sitemap_color");
    }

    public List<ClasseAtributoTipo> geraDicionarioTipoDadosCompleto() throws IOException {
        extraiTodosOsAtributosDeTodasAsClasses();

        ajustaAtributosComReferenciaAOutroAtributo();

        return listaClasseAtributoTipo;
    }

    private void ajustaAtributosComReferenciaAOutroAtributo() {
        for (int i = 0; i < listaClasseAtributoTipo.size(); i++) {
            ClasseAtributoTipo cat = listaClasseAtributoTipo.get(i);
            String tipoAtributo = cat.getTipoAtributo();
            while (tipoAtributo.contains(".")) {
                String classe = tipoAtributo.split("\\.")[0].replace("()", "");
                String nomeAtributo = tipoAtributo.split("\\.")[1];

                Optional<ClasseAtributoTipo> referenciado = listaClasseAtributoTipo.stream().filter(x -> x.getNomeClasse().equals(classe) && x.getNomeAtributo().equals(nomeAtributo)).findAny();
                if (referenciado.isPresent())
                    tipoAtributo = referenciado.get().getTipoAtributo();
                else {
                    break;
                }
            }
            cat.setTipoAtributo(tipoAtributo);
        }
    }

    private void extraiTodosOsAtributosDeTodasAsClasses() {
        for (Pacote pacote : listaPacote) {
            for (AbstractMap.SimpleEntry classeEntry : pacote.getClasses()) {
                extraiTodosOsAtributosDaClasse(pacote.getCompoundName(), (MindMapNode) classeEntry.getValue());
            }
        }
    }

    private void extraiTodosOsAtributosDaClasse(String packageName, MindMapNode classe) {
        String className = classe.getAtributoTEXT();
        List<MindMapNode> classesFilhas = geraListaClassesFilhas(classe);

        MindMapNode nodeObjeto = classe.childByTextEquals("objeto");
        MindMapNode nodeAtributo = nodeObjeto != null ? nodeObjeto.childByTextEquals("atributo") : null;

        if (nodeObjeto == null)
            GenUtility.printErro("Classe " + className + " sem ramo objeto");
        else if (nodeAtributo == null)
            GenUtility.printErro("Classe " + className + " sem ramo atributo");

        if (nodeAtributo != null && !nodeAtributo.getFilhos().isEmpty()) {

            List<MindMapNode> listaAtributos = nodeAtributo.getFilhos().stream()
                    .filter(x -> listaIconesAtributosValidos.contains(x.getAtributoIcon()))
                    .collect(Collectors.toList());
            for (MindMapNode atributo : listaAtributos) {
                String packagePrefix = "";
                if (Arrays.asList("table", "table_abstract").contains(classe.getAtributoIcon()))
                    packagePrefix = "com.datacoper.domain.";
                else
                    packagePrefix = "com.datacoper.container.";
                extraiAtributoDaClasse(packagePrefix, packageName, className, classesFilhas, atributo);
            }
        }
    }

    private void extraiAtributoDaClasse(String packagePrefix, String packageName, String className, List<MindMapNode> classesFilhas, MindMapNode atributo) {
        String nomeAtributo = atributo.getAtributoTEXT().split(":")[0];
        if (atributo.getAtributoTEXT().contains(":")) {
            String tipoAtributo = atributo.getAtributoTEXT().split(":")[1];
            ClasseAtributoTipo classeAtributoTipo = new ClasseAtributoTipo();
            classeAtributoTipo.setNomeClasse(className);
            classeAtributoTipo.setNomePacote(packagePrefix + packageName);
            classeAtributoTipo.setNomeAtributo(nomeAtributo);
            classeAtributoTipo.setCiclico("link_ciclico".equals(atributo.getAtributoIcon()));
            classeAtributoTipo.setTipoAtributo(listaIconesColecao.contains(atributo.getAtributoIcon()) ? tipoAtributo.replace("()", "[]") : tipoAtributo);
            listaClasseAtributoTipo.add(classeAtributoTipo);

            for (MindMapNode classeFilha : classesFilhas) {

                Optional<Pacote> packageClasseFilha = listaPacote.stream()
                        .filter(x -> x.getClasses().stream()
                                .filter(y -> y.getKey().equals(classeFilha.getAtributoTEXT())).findAny().isPresent())
                        .findFirst();
                if (packageClasseFilha.isPresent()) {
                    classeAtributoTipo = new ClasseAtributoTipo();
                    classeAtributoTipo.setNomeClasse(classeFilha.getAtributoTEXT());
                    classeAtributoTipo.setNomePacote(packagePrefix + packageClasseFilha.get().getCompoundName());
                    classeAtributoTipo.setNomeAtributo(nomeAtributo);
                    classeAtributoTipo.setCiclico("link_ciclico".equals(atributo.getAtributoIcon()));
                    classeAtributoTipo.setTipoAtributo(listaIconesColecao.contains(atributo.getAtributoIcon()) ? tipoAtributo.replace("()", "[]") : tipoAtributo);
                    listaClasseAtributoTipo.add(classeAtributoTipo);
                }
            }

        }
    }

    private List<MindMapNode> geraListaClassesFilhas(MindMapNode classe) {
        List<MindMapNode> classesFilhas = new ArrayList<>();
        if ("table_abstract".equals(classe.getAtributoIcon())) {
            List<MindMapNode> listaAux = listaNodeReferenciaClasseConcreta.stream()
                    .filter(x -> classe.getAtributoTEXT().equals(x.getAtributoTEXT()))
                    .collect(Collectors.toList());
            for(MindMapNode abstractReferenceNode : listaAux) {
                MindMapNode nodeClasseEspecifica = MindMapParserUtil.findNodeUpByNodeIcon(abstractReferenceNode, "table");
                if (nodeClasseEspecifica != null)
                    classesFilhas.add(nodeClasseEspecifica);
            }
        }
        return classesFilhas;
    }
}
