package com.datacoper.gerador.dictionary;

import com.datacoper.bean.ClasseAtributoTipo;
import com.datacoper.bean.MindMapNode;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class GenClassDictionaryXMLClassAttributeValidations {

    private List<ClasseAtributoTipo> listaClasseAtributoTipoCompleta = new ArrayList<>();

    public GenClassDictionaryXMLClassAttributeValidations(List<ClasseAtributoTipo> listaClasseAtributoTipoCompleta) {
        this.listaClasseAtributoTipoCompleta = listaClasseAtributoTipoCompleta;
    }

    public String geraDicionarioAtributosAtributoValidacao(MindMapNode nodeTick) {
        StringBuilder stringValidacoes = new StringBuilder();
        stringValidacoes.append("\t\t\t<validacoes>\n");

        if (nodeTick.childByIcon("asterisk_yellow") != null)
            stringValidacoes.append("\t\t\t\t<requerido />\n");

        MindMapNode valorPadrao = nodeTick.childByIcon("pencil_go");
        if (valorPadrao != null) {
            stringValidacoes.append("\t\t\t\t<valorPadrao>\n");
            stringValidacoes.append("\t\t\t\t\t<instruction>");
            stringValidacoes.append(valorPadrao.getAtributoTEXT());
            stringValidacoes.append("</instruction>\n");
            stringValidacoes.append("\t\t\t\t</valorPadrao>\n");
        }

        MindMapNode edicaoCondicional = nodeTick.childByIcon("pencil_conditional");
        if (edicaoCondicional != null) {
            if (edicaoCondicional.getFilhos().isEmpty() || !edicaoCondicional.getFilhos().stream().anyMatch(x -> !"icon".equals(x.getNodeName()))) {
                stringValidacoes.append("\t\t\t\t<edicaoCondicional />\n");
            } else {
                stringValidacoes.append("\t\t\t\t<edicaoCondicional>\n");
                stringValidacoes.append("\t\t\t\t\t<body>\n");
                stringValidacoes.append(GenClassDictionaryXMLUtil.geraXmlInstrucao("\t\t\t\t\t", edicaoCondicional.getFilhos().stream().filter(x -> !"icon".equals(x.getNodeName())).collect(Collectors.toList()), listaClasseAtributoTipoCompleta));
                stringValidacoes.append("\t\t\t\t\t</body>\n");
                stringValidacoes.append("\t\t\t\t</edicaoCondicional>\n");
            }
        }

        MindMapNode nodeValues = nodeTick.childByTextEquals("values");
        if (nodeValues != null) {
            stringValidacoes.append("\t\t\t\t<valores>\n");
            nodeValues.getFilhos().forEach(mindMapNode -> {
                stringValidacoes.append("\t\t\t\t\t<item>\n");
                stringValidacoes.append("\t\t\t\t\t\t<valor>");
                stringValidacoes.append(mindMapNode.getAtributoTEXT());
                stringValidacoes.append("</valor>\n");
                stringValidacoes.append("\t\t\t\t\t</item>\n");
            });
            stringValidacoes.append("\t\t\t\t</valores>\n");
        }

        MindMapNode nodeSize = nodeTick.childByTextEquals("size");
        if (nodeSize != null) {
            stringValidacoes.append("\t\t\t\t<size>\n");
            MindMapNode nodeSizeMin = nodeSize.childByTextStartsWith("min:");
            if (nodeSizeMin != null) {
                stringValidacoes.append("\t\t\t\t\t<min>");
                stringValidacoes.append(nodeSizeMin.getAtributoTEXT().substring(nodeSizeMin.getAtributoTEXT().indexOf(":") + 1));
                stringValidacoes.append("</min>\n");
            }
            MindMapNode nodeSizeMax = nodeSize.childByTextStartsWith("max:");
            if (nodeSizeMax != null) {
                stringValidacoes.append("\t\t\t\t\t<max>");
                stringValidacoes.append(nodeSizeMax.getAtributoTEXT().substring(nodeSizeMax.getAtributoTEXT().indexOf(":") + 1));
                stringValidacoes.append("</max>\n");
            }
            stringValidacoes.append("\t\t\t\t</size>\n");
        }

        MindMapNode calculator = nodeTick.childByIcon("calculator");
        if (calculator != null) {
            stringValidacoes.append("\t\t\t\t<calculo>\n");
            stringValidacoes.append("\t\t\t\t\t<instruction>");
            if (calculator.getFilhos().stream().anyMatch(x -> !"icon".equals(x.getNodeName())))
                stringValidacoes.append(calculator.getFilhos().stream().filter(x -> !"icon".equals(x.getNodeName())).findAny().get().getAtributoTEXT());
            stringValidacoes.append("</instruction>\n");
            stringValidacoes.append("\t\t\t\t</calculo>\n");
        }


        stringValidacoes.append("\t\t\t</validacoes>\n");

        return stringValidacoes.toString();
    }
}
