package com.datacoper.gerador.dictionary;

import com.datacoper.gerador.GenUtility;
import com.datacoper.gerador.Processor;
import com.datacoper.gerador.Transformation;
import org.apache.commons.io.FileUtils;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.concurrent.Callable;

public class GenClassDictionaryValidator implements Transformation, Callable<Transformation> {

   private String target = "ND" ;
   private boolean mountGraph = false;

    public GenClassDictionaryValidator(String target){
        if (target != null) this.target = target;
    }

    public String getTarget() {
        return target;
    }

    public void setTarget(String target) {
        this.target = target;
    }

    public boolean isMountGraph() {
        return mountGraph;
    }

    @Override
    public void doTransformation() throws Exception {
        doTransformationValidaDicionario();
    }

    @Override
    public Transformation call() throws Exception {
        doTransformation();
        return this;
    }

    private void doTransformationValidaDicionario() throws Exception{

        String xsltFile = GenUtility.HOME_GEN + "/src/main/java/v2/validaDicionario.xsl";
        String xmlFile= GenUtility.XML_CLASSES;
        String outFile= GenUtility.HOME_GEN + "/target/resultValidaDicionario.xml";

        StringBuilder sbParam = new StringBuilder();
        sbParam.append("classeAlvo=");
        sbParam.append(target);
        new Processor().run(xsltFile,xmlFile,outFile,sbParam.toString());

    }

}
