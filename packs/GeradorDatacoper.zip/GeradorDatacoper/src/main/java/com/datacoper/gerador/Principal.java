package com.datacoper.gerador;

/*
 @autor Carlos Justino
 @date 06/09/2017
 */
public class Principal {

    public static void main(String[] args){

        if (args == null || args.length < 3){
            try {
                Manager.getInstance().choices();
            } catch (Exception e) {
                e.printStackTrace();
                System.exit(1);
            }
        }else {
            String arquivoXsl = args[0];
            String arquivoEntrada = args[1];
            String arquivoSaida = args[2];
            StringBuilder sbParans = new StringBuilder();

            if (args.length > 3) {
                for (int x = 3; x < args.length; x++) {
                    sbParans.append(args[x]);
                    sbParans.append(" ");
                }
            }

            try {
                new Processor().run(arquivoXsl, arquivoEntrada, arquivoSaida, sbParans.toString());
            } catch (Exception e) {
                e.printStackTrace();
                System.exit(1);
            }
        }
        System.exit(0);

    }

}
