package com.datacoper.gerador;

import org.apache.commons.io.FileUtils;
import org.apache.maven.shared.invoker.*;
import org.gradle.tooling.BuildLauncher;
import org.gradle.tooling.GradleConnector;
import org.gradle.tooling.ProjectConnection;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.time.LocalDateTime;
import java.time.chrono.IsoChronology;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.format.ResolverStyle;
import java.util.ArrayList;
import java.util.List;

public class GenUtility {

    public static final String ANSI_BLACK_BACKGROUND = "\u001B[40m";
    public static final String ANSI_RED_BACKGROUND = "\u001B[41m";
    public static final String ANSI_GREEN_BACKGROUND = "\u001B[42m";
    public static final String ANSI_YELLOW_BACKGROUND = "\u001B[43m";
    public static final String ANSI_BLUE_BACKGROUND = "\u001B[44m";
    public static final String ANSI_PURPLE_BACKGROUND = "\u001B[45m";
    public static final String ANSI_CYAN_BACKGROUND = "\u001B[46m";
    public static final String ANSI_WHITE_BACKGROUND = "\u001B[47m";
    public static final String ANSI_RESET = "\u001B[0m";
    public static final String ANSI_BLACK = "\u001B[30m";
    public static final String ANSI_RED = "\u001B[31m";
    public static final String ANSI_GREEN = "\u001B[32m";
    public static final String ANSI_YELLOW = "\u001B[33m";
    public static final String ANSI_BLUE = "\u001B[34m";
    public static final String ANSI_PURPLE = "\u001B[35m";
    public static final String ANSI_CYAN = "\u001B[36m";
    public static final String ANSI_WHITE = "\u001B[37m";
    public static final String HOME_GERADORSQL = System.getenv("HOME_GERADORSQL");
    public static final String HOME_GEN = System.getenv("HOME_GEN");
    public static final String HOME_JNG = System.getenv("HOME_JNG");
    public static final String HOME_CORE = System.getenv("HOME_CORE");
    public static final String PROJECT_NAME = System.getenv("PROJECT_NAME");
    public static final String HOME_GEN_TARGET = System.getenv("HOME_GEN") + "/target";
    public static final String USER_TMP = System.getenv("HOME_TEMP");
    public static final String XML_TIPODADOS = HOME_GEN_TARGET + "/tipoDados" + PROJECT_NAME + ".xml";
    public static final String XML_PADROES = HOME_GEN_TARGET + "/padroes" + PROJECT_NAME + ".xml";
    public static final String XML_CLASSES = HOME_GEN_TARGET + "/classes" + PROJECT_NAME + ".xml";
    public static final String XML_CLASSEATRIBUTOS = HOME_GEN_TARGET + "/dicionarioClasseAtributo" + PROJECT_NAME + ".xml";

    public static boolean getVariable(String var){
        String retorno =System.getenv(var);
        if (retorno == null || retorno.equals("")){
            return false;
        } else return retorno.trim().equals("true");
    }

    public static void printInfo(String s) {
        if (getVariable("apresentaCoresTerminal")) {
            System.out.println(ANSI_CYAN_BACKGROUND + ANSI_BLUE + "[INFO] --- " + s + ANSI_RESET);
        } else {
            System.out.println("[INFO] --- " + s );
        }
    }

    public static void printInfoColorless(String s) {
        System.out.println("[INFO] --- " + s );
    }

    public static void printErro(String s) {
        if (getVariable("apresentaCoresTerminal")) {
            System.out.println(ANSI_CYAN_BACKGROUND + ANSI_RED + "[ERRO] --- " + s + ANSI_RESET);
        } else {
            System.out.println("[ERRO] --- " + s );
        }
    }

    public static void invokeMaven(File pom, String options, String... goals) throws Exception{
        List<String> listGoals = new ArrayList<>();
        for (String g : goals){
            listGoals.add(g);
        }
        InvocationRequest request = new DefaultInvocationRequest();
        request.setBatchMode(true);
        request.setShowErrors(true);
        request.setThreads("1C");
        request.setPomFile( pom );
        request.setGoals( listGoals );
        if (options != null) request.setMavenOpts(options);
        Invoker invoker = new DefaultInvoker();
        InvocationResult result =invoker.execute( request );

        if ( result.getExitCode() != 0 )
        {
            throw new IllegalStateException( "Build failed." );
        }
    }

    public static void invokeGradle(String projectFolder, String options, String... tasks) throws Exception{
        com.datacoper.gerador.GradleConnector gradleConnector = new com.datacoper.gerador.GradleConnector(System.getenv("GRADLE_HOME"), projectFolder);
        gradleConnector.buildProject(tasks);
    }

    public static boolean deleteFile(File file) throws Exception {
        if (Files.exists(file.toPath(), LinkOption.NOFOLLOW_LINKS)){
            FileUtils.forceDelete(file);
            return true;
        } else{
            return false;
        }
    }

    public static String getNomeArquivoXslt(String arquivoXsl) {
        if (arquivoXsl == null || arquivoXsl.isEmpty()) return "ARQUIVO NAO ENCONTRADO";
        String[] split = arquivoXsl.split("/");
        return split[split.length - 1];
    }

    public static String currentDateTime() {
        return LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"));
    }


    public static boolean moveFile(String nameold, String namenew) throws Exception {
        File file = new File(nameold);
        File filenew = new File(namenew);
        if (Files.exists(file.toPath(), LinkOption.NOFOLLOW_LINKS)) {
            deleteFile(filenew);
            FileUtils.moveFile(file, filenew);
            return true;
        } else {
            return false;
        }
    }
}
