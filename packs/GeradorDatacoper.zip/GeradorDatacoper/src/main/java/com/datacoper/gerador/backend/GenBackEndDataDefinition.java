package com.datacoper.gerador.backend;

import com.datacoper.gerador.GenUtility;
import com.datacoper.gerador.Manager;
import com.datacoper.gerador.Processor;
import com.datacoper.gerador.Transformation;

import java.awt.*;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.SQLOutput;
import java.util.concurrent.Callable;
import java.util.stream.Stream;

import static com.datacoper.gerador.GenUtility.HOME_GEN;
import static com.datacoper.gerador.GenUtility.HOME_GERADORSQL;
import static com.datacoper.gerador.GenUtility.XML_CLASSES;

public class GenBackEndDataDefinition implements Transformation , Callable<Transformation> {
    String target = "ND";
    String atributos = null;
    String tipoGeracao = null;
    String query = null;
    public GenBackEndDataDefinition(String target){
        if (target != null) this.target = target;
        atributos = System.getenv("atributosDDL");
        tipoGeracao = System.getenv("tipoGeracaoDDL");
        query = System.getenv("queryDDL");
    }

    @Override
    public void doTransformation() throws Exception {
        doTransformationBackEndDataDefinition();
        if (isQuery()) {
            new GenPersistenceXML(true).doTransformation();
            doTransformationBackEndPomGeradorSQL();
            //Compila projeto GeradorSQL
            Manager.getInstance().compileGeradorSQL();
            //Executa projeto GeradorSQL
            geraSql();
        }
    }

    private void geraSql() throws Exception{
        File sql = new File(HOME_GERADORSQL + "/target/sql.sql");

        if (sql.exists()){
            sql.delete();
        }

        Process p  =Runtime.getRuntime().exec("java -jar " + HOME_GERADORSQL + "/target/GeradorSQL-1.0.0-jar-with-dependencies.jar");
        //Process p  =Runtime.getRuntime().exec("java -jar " + HOME_GERADORSQL + "/target/GeradorSQL-1.0.0.jar");
        p.waitFor();
        File saida = new File(HOME_GERADORSQL + "/target/saida.txt");
        if (saida.exists()){
            saida.delete();
        }

        FileWriter fw = new FileWriter(saida);
        BufferedReader in = new BufferedReader(new InputStreamReader(p.getInputStream()));
        String line;
        while ((line = in.readLine()) != null) {
            fw.append(line);
            fw.append("\n");
        }
        in.close();
        in = new BufferedReader(new InputStreamReader(p.getErrorStream()));
        while ((line = in.readLine()) != null) {
            fw.append(line);
            fw.append("\n");
        }
        in.close();
        fw.append("\n");
        fw.flush();
        fw.close();

        if (Manager.getInstance().isFreemindAction()){

        }else{
            saida = new File(HOME_GERADORSQL + "/target/saida.txt");
            if (saida.exists()){
                try (Stream<String> stream = Files.lines(Paths.get(saida.getAbsolutePath()))) {
                    stream.forEach(System.out::println);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            sql = new File(HOME_GERADORSQL + "/target/sql.sql");
            if (sql.exists()){
                try (Stream<String> stream = Files.lines(Paths.get(sql.getAbsolutePath()))) {
                    stream.forEach(System.out::println);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }


    private void doTransformationBackEndDataDefinition() throws Exception{
        String xsltFile = HOME_GEN + "/src/main/java/v2/dicionario2ddl.xsl";
        String xmlFile=XML_CLASSES;
        String outFile = null;
        if (isQuery()) {
            outFile = HOME_GERADORSQL + "/src/main/java/com/datacoper/arquitetura/gerador/sql/GeradorSQL.java";
        } else {
            outFile=HOME_GEN + "/target/ddl"+target+".sql";
        }
        StringBuilder sbParam = new StringBuilder();
        File arquivoParam = new File(GenUtility.HOME_GEN + "/target/param"+ target + query +".xml");


        sbParam.append("classeAlvo=");
        sbParam.append(target);
        sbParam.append(" ");
        sbParam.append("atributosDDL=");
        sbParam.append(atributos);
        sbParam.append(" ");
        sbParam.append("tipoGeracaoDDL=");
        sbParam.append(tipoGeracao);
        sbParam.append(" ");
        sbParam.append("queryDDL=");
        sbParam.append(query);
        sbParam.append(" ");
        sbParam.append("queryParamDDL=");
        if (!arquivoParam.exists()){
            sbParam.append("ND");
        }else{
            sbParam.append(arquivoParam.getAbsolutePath().replaceAll("\\\\", "/"));
        }

        new Processor().run(xsltFile,xmlFile,outFile,sbParam.toString());
    }
    private void doTransformationBackEndPomGeradorSQL() throws Exception{
        String xsltFile = HOME_GEN + "/src/main/java/v2/dicionario2pomGeradorSQL.xsl";
        String xmlFile=XML_CLASSES;
        String outFile=HOME_GERADORSQL + "/pom.xml";
        String projeto = "agrorevenda";

        if ("Patrimonial".equals(System.getenv("PROJECT_NAME"))){
            projeto = "patrimonial";
        }

        StringBuilder sbParam = new StringBuilder();
        sbParam.append("projeto=");
        sbParam.append(projeto);

        new Processor().run(xsltFile,xmlFile,outFile,sbParam.toString());
    }

    @Override
    public Transformation call() throws Exception {
        doTransformation();
        return this;
    }

    private boolean isQuery(){
        return (query != null && !query.equals("") && !query.equals("ND"));
    }


}
