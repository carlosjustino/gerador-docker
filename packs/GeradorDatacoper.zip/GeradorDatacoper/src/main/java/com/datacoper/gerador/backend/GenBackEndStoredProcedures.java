package com.datacoper.gerador.backend;

import com.datacoper.gerador.Processor;
import com.datacoper.gerador.Transformation;

import java.util.concurrent.Callable;

import static com.datacoper.gerador.GenUtility.HOME_GEN;
import static com.datacoper.gerador.GenUtility.XML_CLASSES;

public class GenBackEndStoredProcedures implements Transformation, Callable<Transformation> {

    public GenBackEndStoredProcedures(){

    }

    @Override
    public void doTransformation() throws Exception {
        doTransformationBackEndStoredProceudres();
    }

    private void doTransformationBackEndStoredProceudres() throws Exception{

        String javaSourcePath=System.getenv("HOME_BUSINESS_URL") + "/src/main/java";

        String xsltFile = HOME_GEN + "/src/main/java/v2/dicionario2storedProcedure.xsl";
        String xmlFile=XML_CLASSES;
        String outFile=System.getenv("HOME_TEMP") + "/utilitySource.lst";

        StringBuilder sbParam = new StringBuilder();
        sbParam.append("javaSourcePath=");
        sbParam.append(javaSourcePath);
        sbParam.append(" ");
        sbParam.append("sistemaOperacional=");
        sbParam.append(System.getenv("OS"));

        new Processor().run(xsltFile,xmlFile,outFile,sbParam.toString());

    }


    @Override
    public GenBackEndStoredProcedures call() throws Exception {
        doTransformation();
        return this;
    }
}
