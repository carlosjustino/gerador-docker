package com.datacoper.gerador.report;

import com.datacoper.gerador.Processor;
import com.datacoper.gerador.Transformation;

import static com.datacoper.gerador.GenUtility.HOME_GEN;
import static com.datacoper.gerador.GenUtility.XML_CLASSES;

public class GenReportsValidators implements Transformation {


    public GenReportsValidators(){

    }

    @Override
    public void doTransformation() throws Exception {
        doTransformationReportValidators();
    }

    private void doTransformationReportValidators() throws Exception{
        String xslFile= HOME_GEN + "/src/main/java/v2/telaComplexa2Validators.xsl";
        String xmlFile= HOME_GEN + "/target/xmlListRelatorio_sync.xml";
        String outFile= HOME_GEN + "/target/vltRelatorio";
        String validatorsSourcePath=System.getenv("HOME_JNG_URL") + "/app/validators";

        StringBuilder sbParam = new StringBuilder();
        sbParam.append("validatorsSourcePath=");
        sbParam.append(validatorsSourcePath);
        sbParam.append(" ");
        sbParam.append("xmlClasses=");
        sbParam.append(XML_CLASSES);
        sbParam.append(" ");
        sbParam.append("sistemaOperacional=");
        sbParam.append(System.getenv("OS"));
        sbParam.append(" ");
        sbParam.append("ativarBlockUI=");
        sbParam.append(System.getenv("ACTIVATE_BLOCKUI"));

        new Processor().run(xslFile,xmlFile,outFile,sbParam.toString());

    }

}
