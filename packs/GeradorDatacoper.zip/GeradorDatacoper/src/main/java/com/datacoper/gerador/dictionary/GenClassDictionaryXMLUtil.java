package com.datacoper.gerador.dictionary;

import com.datacoper.bean.ClasseAtributoTipo;
import com.datacoper.bean.MindMapNode;
import com.datacoper.gerador.GenUtility;

import java.util.*;
import java.util.stream.Collectors;

public class GenClassDictionaryXMLUtil {

    private static List<String> funcoesEspeciais = Arrays.asList("filtrarLista()", "mapList()", "mapFirst()", "getFirstElement()");

    public static AbstractMap.SimpleEntry<String, String> getNomeTipoAtributo(List<ClasseAtributoTipo> listaClasseAtributoTipoCompleta, String declaracaoMapaMental) {

        if (declaracaoMapaMental == null)
            return new AbstractMap.SimpleEntry("", "");

        if (!declaracaoMapaMental.contains(":"))
            return new AbstractMap.SimpleEntry(declaracaoMapaMental, "");

        String nome = declaracaoMapaMental.substring(0, declaracaoMapaMental.indexOf(":"));
        String tipo = declaracaoMapaMental.substring(declaracaoMapaMental.indexOf(":") + 1);

        if (!tipo.contains("."))
            return new AbstractMap.SimpleEntry(nome, tipo);

        if (tipo.equals("com.datacoper.helper.task.TaskSummary[]"))
            return new AbstractMap.SimpleEntry(nome, tipo);

        String classeTipo = tipo.substring(0, tipo.indexOf("()."));
        String atributoClasseTipo = tipo.substring(tipo.indexOf("().") + 3);

        if (atributoClasseTipo.contains(".")) {
            String atributoClasseTipoBefore = atributoClasseTipo.substring(0, atributoClasseTipo.indexOf("."));

            Optional<ClasseAtributoTipo> classeTipoAtributo = listaClasseAtributoTipoCompleta.stream()
                    .filter(x -> x.getNomeClasse().equals(classeTipo) && x.getNomeAtributo().equals(atributoClasseTipoBefore))
                    .findAny();
            if (classeTipoAtributo.isPresent()) {
                String atributoClasseTipoAfter = atributoClasseTipo.substring(atributoClasseTipo.indexOf(".") + 1);
                String novaDeclaracaoMapaMental = nome + ":" + classeTipoAtributo.get().getTipoAtributo() + "." + atributoClasseTipoAfter;
                return getNomeTipoAtributo(listaClasseAtributoTipoCompleta, novaDeclaracaoMapaMental);
            }
            else
                GenUtility.printErro("Nao foi encontrado tipo de dados para : " + tipo);

        } else {

            Optional<ClasseAtributoTipo> classeTipoAtributo = listaClasseAtributoTipoCompleta.stream()
                    .filter(x -> x.getNomeClasse().equals(classeTipo) && x.getNomeAtributo().equals(atributoClasseTipo))
                    .findAny();
            if (classeTipoAtributo.isPresent())
                return new AbstractMap.SimpleEntry<>(nome, classeTipoAtributo.get().getTipoAtributo());
            else
                GenUtility.printErro("Nao foi encontrado tipo de dados para : " + tipo);
        }

        return new AbstractMap.SimpleEntry<>(nome, tipo);
    }

    public static List<MindMapNode> getListaMetodosFromNode(MindMapNode nodeRaiz) {
        List<MindMapNode> nodesMetodos = nodeRaiz.getFilhos().stream().filter(x -> "script".equals(x.getAtributoIcon())).collect(Collectors.toList());

        MindMapNode nodePrivate = nodeRaiz.childByTextEquals("private");
        if (nodePrivate != null)
            nodesMetodos.addAll(nodePrivate.getFilhos().stream().filter(x -> "script".equals(x.getAtributoIcon())).collect(Collectors.toList()));

        MindMapNode nodePublic = nodeRaiz.childByTextEquals("public");
        if (nodePublic != null)
            nodesMetodos.addAll(nodePublic.getFilhos().stream().filter(x -> "script".equals(x.getAtributoIcon())).collect(Collectors.toList()));

        MindMapNode nodeProtected = nodeRaiz.childByTextEquals("public");
        if (nodeProtected != null)
            nodesMetodos.addAll(nodeProtected.getFilhos().stream().filter(x -> "script".equals(x.getAtributoIcon())).collect(Collectors.toList()));
        return nodesMetodos;
    }

    public static List<String> getTiposBasicos() {
        return Arrays.asList("Inteiro",
                "Decimal",
                "Monetario",
                "InteiroPositivo",
                "DecimalPositivo",
                "Longo",
                "Sequencial",
                "AutoIncremento",
                "Data",
                "DataHora",
                "DataContexto",
                "DataHoraServidor",
                "Arquivo",
                "Email");
    }

    public static String geraXmlInstrucao(String recuoAnterior, List<MindMapNode> listaNodes, List<ClasseAtributoTipo> listaClasseAtributoTipoCompleta) {
        listaNodes = listaNodes.stream().filter(x -> !"icon".equals(x.getNodeName())).collect(Collectors.toList());

        StringBuilder stringInstrucao = new StringBuilder();
        Map<String, String> mapInstrucoesSomenteTrocaNome = new HashMap<>();
        mapInstrucoesSomenteTrocaNome.put("if", "if");
        mapInstrucoesSomenteTrocaNome.put("condition", "condition");
        mapInstrucoesSomenteTrocaNome.put("then", "then");
        mapInstrucoesSomenteTrocaNome.put("else", "else");
        mapInstrucoesSomenteTrocaNome.put("or", "or");
        mapInstrucoesSomenteTrocaNome.put("body", "body");
        mapInstrucoesSomenteTrocaNome.put("error()", "error");
        mapInstrucoesSomenteTrocaNome.put("parameter", "parameters");
        mapInstrucoesSomenteTrocaNome.put("vars", "vars");
        mapInstrucoesSomenteTrocaNome.put("for-each", "for-each");
        mapInstrucoesSomenteTrocaNome.put("where", "where");
        mapInstrucoesSomenteTrocaNome.put("case", "case");
        mapInstrucoesSomenteTrocaNome.put("when", "when");
        mapInstrucoesSomenteTrocaNome.put("()", "parentheses");

        String recuoAtual = recuoAnterior + "\t";

        for(MindMapNode node : listaNodes) {
            if (mapInstrucoesSomenteTrocaNome.get(node.getAtributoTEXT()) != null) {
                appendInstrucaoDeMesmoNome(listaClasseAtributoTipoCompleta, stringInstrucao, mapInstrucoesSomenteTrocaNome, recuoAtual, node);

            } else if ("message".equals(node.getAtributoTEXT()) && "error()".equals(node.getPai().getAtributoTEXT())) {
                appendInstrucaoErrorMessage(stringInstrucao, recuoAtual, node);

            } else if ("vars".equals(node.getPai().getAtributoTEXT())) {
                appendInstrucaoVar(listaClasseAtributoTipoCompleta, stringInstrucao, recuoAtual, node);

            } else if ("parameter".equals(node.getPai().getAtributoTEXT())) {
                appendInstrucaoParameter(listaClasseAtributoTipoCompleta, stringInstrucao, recuoAtual, node);

            } else if ("return".equals(node.getAtributoTEXT())) {
                appendInstrucaoGenerica(listaClasseAtributoTipoCompleta, stringInstrucao, recuoAtual, node);

            } else if (node.ascendantByTextEquals("return") != null || node.ascendantByTextStartsWith("return ") != null) {
                appendInstrucaoDescendenteDeReturn(stringInstrucao, node);

            } else if ("filtrarLista()".equals(node.getLastFunctionCallFromAtributoTEXT())) {
                appendInstrucaoFiltrarLista(listaClasseAtributoTipoCompleta, stringInstrucao, recuoAtual, node);

            } else if ("getFirstElement()".equals(node.getLastFunctionCallFromAtributoTEXT())
                    && node.childByTextEquals("where") != null) {

                appendInstrucaoGetFirstElementComWhere(listaClasseAtributoTipoCompleta, stringInstrucao, recuoAtual, node);

            } else if ("getFirstElement()".equals(node.getLastFunctionCallFromAtributoTEXT())
                    && node.childByTextEquals("where") == null) {

                appendInstrucaoGetFirstElementSemWhere(listaClasseAtributoTipoCompleta, stringInstrucao, recuoAtual, node);

            } else if (node.getAtributoTEXT().endsWith("()")
                    && node.getPai().getAtributoTEXT().endsWith("()")
                    && !"vars".equals(node.getPai().getPai().getAtributoTEXT())
                    && !funcoesEspeciais.contains(node.getPai().getLastFunctionCallFromAtributoTEXT())) {

                if (!node.equals(node.getPai().getFilhos().get(0)))
                stringInstrucao.append(", ");

                stringInstrucao.append(node.getAtributoTEXT().replace("()", "("));

                stringInstrucao.append(geraXmlInstrucao(recuoAtual, node.getFilhos(), listaClasseAtributoTipoCompleta));

                stringInstrucao.append(")");

            } else if (node.getAtributoTEXT().endsWith("()")) {
                appendInstrucaoTerminandoComParentesesDuplos(listaClasseAtributoTipoCompleta, stringInstrucao, recuoAtual, node);

            } else if (node.getPai().getAtributoTEXT().endsWith("()")
                    && !"vars".equals(node.getPai().getPai().getAtributoTEXT())
                    && (node.nodePaiEhGetFirstElementSemWhere() || !funcoesEspeciais.contains(node.getPai().getLastFunctionCallFromAtributoTEXT()))) {

                if (!node.equals(node.getPai().getFilhos().get(0)))
                    stringInstrucao.append(", ");
                stringInstrucao.append(node.getAtributoTEXT());

                stringInstrucao.append(geraXmlInstrucao(recuoAtual, node.getFilhos(), listaClasseAtributoTipoCompleta));

            } else if ("for-each".equals(node.getPai().getAtributoTEXT()) && !"body".equals(node.getAtributoTEXT())) {

                appendInstrucaoExprForeach(stringInstrucao, recuoAtual, node);

            } else {
                appendInstrucaoGenerica(listaClasseAtributoTipoCompleta, stringInstrucao, recuoAtual, node);
            }
        }

        return stringInstrucao.toString();
    }

    private static void appendInstrucaoDeMesmoNome(List<ClasseAtributoTipo> listaClasseAtributoTipoCompleta, StringBuilder stringInstrucao, Map<String, String> mapInstrucoesSomenteTrocaNome, String recuoAtual, MindMapNode node) {
        stringInstrucao.append(recuoAtual);
        stringInstrucao.append("<");
        stringInstrucao.append(mapInstrucoesSomenteTrocaNome.get(node.getAtributoTEXT()));
        stringInstrucao.append(">\n");

        stringInstrucao.append(geraXmlInstrucao(recuoAtual, node.getFilhos(), listaClasseAtributoTipoCompleta));

        stringInstrucao.append(recuoAtual);
        stringInstrucao.append("</");
        stringInstrucao.append(mapInstrucoesSomenteTrocaNome.get(node.getAtributoTEXT()));
        stringInstrucao.append(">\n");
    }

    private static void appendInstrucaoErrorMessage(StringBuilder stringInstrucao, String recuoAtual, MindMapNode node) {
        node.getFilhos().forEach(x -> {
            stringInstrucao.append(recuoAtual);
            stringInstrucao.append("<message>");
            stringInstrucao.append(x.getAtributoTEXT());
            stringInstrucao.append("</message>\n");
        });
    }

    private static void appendInstrucaoVar(List<ClasseAtributoTipo> listaClasseAtributoTipoCompleta, StringBuilder stringInstrucao, String recuoAtual, MindMapNode node) {
        stringInstrucao.append(recuoAtual);
        stringInstrucao.append("<var");

        AbstractMap.SimpleEntry<String, String> nomeTipo = getNomeTipoAtributo(listaClasseAtributoTipoCompleta, node.getAtributoTEXT());

        stringInstrucao.append(" nome=\"");
        stringInstrucao.append(nomeTipo.getKey());
        stringInstrucao.append("\"");

        stringInstrucao.append(" tipo=\"");
        stringInstrucao.append(nomeTipo.getValue());
        stringInstrucao.append("\"");

        if (node.getFilhos().isEmpty()) {
            stringInstrucao.append(" />\n");
        } else {
            stringInstrucao.append(">\n");

            stringInstrucao.append(geraXmlInstrucao(recuoAtual, node.getFilhos(), listaClasseAtributoTipoCompleta));

            stringInstrucao.append(recuoAtual);
            stringInstrucao.append("</var>\n");
        }


    }

    private static void appendInstrucaoParameter(List<ClasseAtributoTipo> listaClasseAtributoTipoCompleta, StringBuilder stringInstrucao, String recuoAtual, MindMapNode node) {
        stringInstrucao.append(recuoAtual);
        stringInstrucao.append("<parameter");

        AbstractMap.SimpleEntry<String, String> nomeTipo = getNomeTipoAtributo(listaClasseAtributoTipoCompleta, node.getAtributoTEXT());

        stringInstrucao.append(" nome=\"");
        stringInstrucao.append(nomeTipo.getKey());
        stringInstrucao.append("\"");

        stringInstrucao.append(" tipo=\"");
        stringInstrucao.append(nomeTipo.getValue());
        stringInstrucao.append("\"");

        stringInstrucao.append(" isBasic=\"");
        String tipo = nomeTipo.getValue();
        if (tipo.contains("(")) tipo = tipo.substring(0, tipo.indexOf("("));
        else if (tipo.contains("[")) tipo = tipo.substring(0, tipo.indexOf("["));
        else GenUtility.printErro("Escrita Incorreta de Parametro: " + node.getAtributoTEXT());
        stringInstrucao.append(getTiposBasicos().contains(tipo) ? "S" : "N");
        stringInstrucao.append("\"");

        stringInstrucao.append(" />\n");
    }

    private static void appendInstrucaoDescendenteDeReturn(StringBuilder stringInstrucao, MindMapNode node) {
        stringInstrucao.append(" ");
        stringInstrucao.append(node.getAtributoTEXT());
    }

    private static void appendInstrucaoFiltrarLista(List<ClasseAtributoTipo> listaClasseAtributoTipoCompleta, StringBuilder stringInstrucao, String recuoAtual, MindMapNode node) {
        stringInstrucao.append(recuoAtual);
        stringInstrucao.append("<listFilter");

        stringInstrucao.append(" resultAssign=\"");
        if (node.getAtributoTEXT().contains("="))
            stringInstrucao.append(node.getAtributoTEXT().split("=")[0].trim());
        stringInstrucao.append("\"");

        stringInstrucao.append(">\n");

        stringInstrucao.append(geraXmlInstrucao(recuoAtual, node.getFilhos(), listaClasseAtributoTipoCompleta));

        stringInstrucao.append(recuoAtual);
        stringInstrucao.append("</listFilter>\n");
    }

    private static void appendInstrucaoGetFirstElementComWhere(List<ClasseAtributoTipo> listaClasseAtributoTipoCompleta, StringBuilder stringInstrucao, String recuoAtual, MindMapNode node) {
        stringInstrucao.append(recuoAtual);
        stringInstrucao.append("<firstElementList");

        stringInstrucao.append(" resultAssign=\"");
        if (node.getAtributoTEXT().contains("="))
            stringInstrucao.append(node.getAtributoTEXT().split("=")[0].trim());
        stringInstrucao.append("\"");

        stringInstrucao.append(">\n");

        stringInstrucao.append(geraXmlInstrucao(recuoAtual, node.getFilhos(), listaClasseAtributoTipoCompleta));

        stringInstrucao.append(recuoAtual);
        stringInstrucao.append("</firstElementList>\n");
    }

    private static void appendInstrucaoGetFirstElementSemWhere(List<ClasseAtributoTipo> listaClasseAtributoTipoCompleta, StringBuilder stringInstrucao, String recuoAtual, MindMapNode node) {
        boolean hasDoubleBrackets = node.getAtributoTEXT().contains("()");

        if (!node.getPai().getAtributoTEXT().endsWith("()")) {
            stringInstrucao.append(recuoAtual);
            stringInstrucao.append("<instruction>");
        }

        stringInstrucao.append(node.getAtributoTEXT().replace("()", "("));
        stringInstrucao.append(geraXmlInstrucao(recuoAtual, node.getFilhos(), listaClasseAtributoTipoCompleta));
        if (hasDoubleBrackets)
            stringInstrucao.append(")");

        if (!node.getPai().getAtributoTEXT().endsWith("()")) {
            stringInstrucao.append("</instruction>\n");
        }
    }

    private static void appendInstrucaoTerminandoComParentesesDuplos(List<ClasseAtributoTipo> listaClasseAtributoTipoCompleta, StringBuilder stringInstrucao, String recuoAtual, MindMapNode node) {
        stringInstrucao.append(recuoAtual);
        stringInstrucao.append("<instruction>");

        stringInstrucao.append(node.getAtributoTEXT().replace("()", "("));

        stringInstrucao.append(geraXmlInstrucao(recuoAtual, node.getFilhos(), listaClasseAtributoTipoCompleta));

        stringInstrucao.append(")</instruction>\n");
    }

    private static void appendInstrucaoExprForeach(StringBuilder stringInstrucao, String recuoAtual, MindMapNode node) {
        stringInstrucao.append(recuoAtual);
        stringInstrucao.append("<expr>\n");

        stringInstrucao.append(recuoAtual + "\t");
        stringInstrucao.append("<instruction>");
        stringInstrucao.append(node.getAtributoTEXT());
        stringInstrucao.append("</instruction>\n");

        stringInstrucao.append(recuoAtual);
        stringInstrucao.append("</expr>\n");
    }

    private static void appendInstrucaoGenerica(List<ClasseAtributoTipo> listaClasseAtributoTipoCompleta, StringBuilder stringInstrucao, String recuoAtual, MindMapNode node) {
        stringInstrucao.append(recuoAtual);
        stringInstrucao.append("<instruction>");

        stringInstrucao.append(node.getAtributoTEXT());

        stringInstrucao.append(geraXmlInstrucao(recuoAtual, node.getFilhos(), listaClasseAtributoTipoCompleta));

        stringInstrucao.append("</instruction>\n");
    }
}
