package com.datacoper.gerador.backend.unittest;

import com.datacoper.gerador.Processor;
import com.datacoper.gerador.Transformation;

import static com.datacoper.gerador.GenUtility.HOME_GEN;

public class GenUnitTestsProperties implements Transformation {


    public GenUnitTestsProperties(){
    }


    @Override
    public void doTransformation() throws Exception {
        doTransformationUnitTestsProperties();
    }


    private void doTransformationUnitTestsProperties() throws Exception{
        String xsltFile = HOME_GEN + "/src/main/java/v2/testeUnitario2properties.xsl";
        String xmlFile=HOME_GEN + "/target/testeUnitario.xml";
        String outFile=HOME_GEN + "/target/var.properties";

        new Processor().run(xsltFile,xmlFile,outFile,null);

    }


}
