package com.datacoper.gerador.dictionary;

import com.datacoper.bean.ClasseAtributoTipo;
import com.datacoper.bean.MindMapNode;

import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.List;

public class GenClassDictionaryXMLClassConstructors {

    private List<ClasseAtributoTipo> listaClasseAtributoTipoCompleta = new ArrayList<>();

    public GenClassDictionaryXMLClassConstructors(List<ClasseAtributoTipo> listaClasseAtributoTipoCompleta) {
        this.listaClasseAtributoTipoCompleta = listaClasseAtributoTipoCompleta;
    }

    public String geraDicionarioConstrutores(String recuoAnterior, MindMapNode nodeClasse) {
        StringBuilder stringConstrutores = new StringBuilder();
        String recuoAtual = recuoAnterior + "\t";

        MindMapNode nodeConstrutor = nodeClasse.childByTextEquals("construtor");
        if (nodeConstrutor != null) {
            stringConstrutores.append(recuoAtual);
            stringConstrutores.append("<construtores root=\"sim\">\n");

            List<MindMapNode> nodesConstrutores = GenClassDictionaryXMLUtil.getListaMetodosFromNode(nodeConstrutor);

            nodesConstrutores.forEach(mindMapNode -> {
                stringConstrutores.append(geraDicionarioConstrutor(recuoAtual, mindMapNode));
            });

            stringConstrutores.append(recuoAtual);
            stringConstrutores.append("</construtores>\n");
        }

        return stringConstrutores.toString();
    }

    private String geraDicionarioConstrutor(String recuoAnterior, MindMapNode nodeConstrutor) {
        StringBuilder stringConstrutor = new StringBuilder();
        String recuoAtual = recuoAnterior + "\t";

        AbstractMap.SimpleEntry<String, String> construtorNomeRetorno = GenClassDictionaryXMLUtil.getNomeTipoAtributo(listaClasseAtributoTipoCompleta, nodeConstrutor.getAtributoTEXT());


        stringConstrutor.append(recuoAtual);
        stringConstrutor.append("<construtor");

        stringConstrutor.append(" nome=\"");
        stringConstrutor.append(construtorNomeRetorno.getKey());
        stringConstrutor.append("\"");

        if (!"".equals(construtorNomeRetorno.getValue())) {
            stringConstrutor.append(" tipoRetorno=\"");
            stringConstrutor.append(construtorNomeRetorno.getValue());
            stringConstrutor.append("\"");
        }

        stringConstrutor.append(" revisado=\"");
        stringConstrutor.append("S");
        stringConstrutor.append("\"");

        stringConstrutor.append(" acesso=\"");
        stringConstrutor.append("private".equals(nodeConstrutor.getPai().getAtributoTEXT()) ? "private" : "public");
        stringConstrutor.append("\"");

        stringConstrutor.append(">\n");

        stringConstrutor.append(GenClassDictionaryXMLUtil.geraXmlInstrucao(recuoAtual, nodeConstrutor.getFilhos(), listaClasseAtributoTipoCompleta));

        stringConstrutor.append(recuoAtual);
        stringConstrutor.append("</construtor>\n");

        return stringConstrutor.toString();
    }
}
