package com.datacoper.gerador.test;

import com.datacoper.gerador.Processor;
import com.datacoper.gerador.Transformation;

import java.util.concurrent.Callable;

import static com.datacoper.gerador.GenUtility.HOME_GEN;
import static com.datacoper.gerador.GenUtility.XML_CLASSES;

public class GenRunCucumberTest implements Transformation {

    public GenRunCucumberTest(){
    }

    @Override
    public void doTransformation() throws Exception {
        doTransformationRunCucumberTest();
    }

    private void doTransformationRunCucumberTest() throws Exception {

        String javaSourcePath=System.getenv("HOME_TEST_PROJECT_URL");

        String xsltFile = HOME_GEN + "/src/main/java/v2/xml2runCucumberTest.xsl";
        String xmlFile=HOME_GEN + "/target/teste"+System.getenv("PROJECT_NAME").toLowerCase()+ ".xml";
        String outFile=System.getenv("HOME_TEMP") + "/runCucumberOutput.lst";

        StringBuilder sbParam = new StringBuilder();
        sbParam.append("javaSourcePath=");
        sbParam.append(javaSourcePath);
        sbParam.append(" ");
        sbParam.append("sistemaOperacional=");
        sbParam.append(System.getenv("OS"));
        sbParam.append(" ");
        new Processor().run(xsltFile,xmlFile,outFile,sbParam.toString());

    }

}
