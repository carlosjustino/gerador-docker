package com.datacoper.gerador;

/*
@author Justino
*/

import org.apache.commons.lang3.StringUtils;

import java.io.*;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

public class ZipUtils {

    public static void unzip(File zipfile, File directory) throws IOException {
        System.out.println("--> Descompactando arquivo: " + zipfile.getAbsolutePath());
        ZipFile zfile = new ZipFile(zipfile);
        Enumeration<? extends ZipEntry> entries = zfile.entries();
        Enumeration<? extends ZipEntry> entries2 = zfile.entries();
        double qtd=0,count = 0;
        double percentual = 0;

        int anterior = 0;
        while (entries2.hasMoreElements()){
            qtd++;
            entries2.nextElement();
        }

        System.out.println("Quantidade arquivos: " + qtd);
        System.out.println("Progresso: ");
        /*long tempo = System.currentTimeMillis();*/
        while (entries.hasMoreElements()) {
            count++;
            percentual = ( count / qtd) * 100;
            /*if (System.currentTimeMillis() - tempo  > 3000){
                tempo = System.currentTimeMillis();
                System.out.println("Per: " + percentual);
            }*/
            if (Double.valueOf(percentual).intValue() > anterior) {
                System.out.print(StringUtils.leftPad("", Double.valueOf(percentual).intValue(), "#") + " : " + Double.valueOf(percentual).intValue() + "%\r");
                anterior = Double.valueOf(percentual).intValue();
            }
            ZipEntry entry = entries.nextElement();
            File file = new File(directory, entry.getName());
            if (entry.isDirectory()) {
                file.mkdirs();
            } else {
                file.getParentFile().mkdirs();
                InputStream in = zfile.getInputStream(entry);
                try {
                    copy(in, file);
                } finally {
                    in.close();
                }
            }
        }
        zfile.close();
        System.out.println("");
    }
    public static void copy(InputStream in, OutputStream out) throws IOException {
        byte[] buffer = new byte[1024];
        while (true) {
            int readCount = in.read(buffer);
            if (readCount < 0) {
                break;
            }
            out.write(buffer, 0, readCount);
        }
    }

    public static void copy(File file, OutputStream out) throws IOException {
        InputStream in = new FileInputStream(file);
        try {
            copy(in, out);
        } finally {
            in.close();
        }
    }

    public static void copy(InputStream in, File file) throws IOException {
        OutputStream out = new FileOutputStream(file);
        try {
            copy(in, out);
        } finally {
            out.close();
        }
    }
}
