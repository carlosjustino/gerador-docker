package com.datacoper.gerador.dictionary;

import com.datacoper.bean.ClasseAtributoTipo;
import com.datacoper.bean.MindMapNode;

import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.List;

public class GenClassDictionaryXMLClassServices {

    private List<ClasseAtributoTipo> listaClasseAtributoTipoCompleta = new ArrayList<>();

    public GenClassDictionaryXMLClassServices(List<ClasseAtributoTipo> listaClasseAtributoTipoCompleta) {
        this.listaClasseAtributoTipoCompleta = listaClasseAtributoTipoCompleta;
    }

    public String geraDicionarioServicos(String recuoAnterior, MindMapNode nodeClasse) {
        StringBuilder stringServicos = new StringBuilder();
        String recuoAtual = recuoAnterior + "\t";

        MindMapNode nodeServico = nodeClasse.childByTextEquals("servico");
        if (nodeServico != null) {
            stringServicos.append(recuoAtual);
            stringServicos.append("<servicos root=\"sim\">\n");

            List<MindMapNode> nodesServicos = GenClassDictionaryXMLUtil.getListaMetodosFromNode(nodeServico);

            nodesServicos.forEach(mindMapNode -> {
                stringServicos.append(geraDicionarioServico(recuoAtual, mindMapNode));
            });

            stringServicos.append(recuoAtual);
            stringServicos.append("</servicos>\n");
        }

        return stringServicos.toString();
    }

    private String geraDicionarioServico(String recuoAnterior, MindMapNode nodeServico) {
        StringBuilder stringServico = new StringBuilder();
        String recuoAtual = recuoAnterior + "\t";

        AbstractMap.SimpleEntry<String, String> servicoNomeRetorno = GenClassDictionaryXMLUtil.getNomeTipoAtributo(listaClasseAtributoTipoCompleta, nodeServico.getAtributoTEXT());


        stringServico.append(recuoAtual);
        stringServico.append("<servico");

        stringServico.append(" nome=\"");
        stringServico.append(servicoNomeRetorno.getKey());
        stringServico.append("\"");

        if (!"".equals(servicoNomeRetorno.getValue())) {
            stringServico.append(" tipoRetorno=\"");
            stringServico.append(servicoNomeRetorno.getValue());
            stringServico.append("\"");
        }

        stringServico.append(" revisado=\"");
        stringServico.append("S");
        stringServico.append("\"");

        stringServico.append(" acesso=\"");
        stringServico.append("private".equals(nodeServico.getPai().getAtributoTEXT()) ? "private" : "public");
        stringServico.append("\"");

        stringServico.append(">\n");

        stringServico.append(GenClassDictionaryXMLUtil.geraXmlInstrucao(recuoAtual, nodeServico.getFilhos(), listaClasseAtributoTipoCompleta));

        stringServico.append(recuoAtual);
        stringServico.append("</servico>\n");

        return stringServico.toString();
    }
}
