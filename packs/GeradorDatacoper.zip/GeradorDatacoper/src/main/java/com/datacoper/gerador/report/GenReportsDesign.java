package com.datacoper.gerador.report;

import com.datacoper.gerador.Processor;
import com.datacoper.gerador.Transformation;

import static com.datacoper.gerador.GenUtility.HOME_GEN;
import static com.datacoper.gerador.GenUtility.XML_CLASSES;

public class GenReportsDesign implements Transformation {

    public GenReportsDesign(){

    }

    @Override
    public void doTransformation() throws Exception {
        doTransformationReportDesign();
    }

    private void doTransformationReportDesign() throws Exception{
        String xslFile= HOME_GEN + "/src/main/java/v2/relatorio2Design.xsl";
        String xmlFile= HOME_GEN + "/target/xmlListRelatorio.xml";
        String outFile= HOME_GEN + "/target/designRelatorio.lst";

        String rptdesignSourcePath= System.getenv("SVN_RPTDESIGN_URL");

        StringBuilder sbParam = new StringBuilder();
        sbParam.append("rptdesignSourcePath=");
        sbParam.append(rptdesignSourcePath);
        sbParam.append(" ");
        sbParam.append("xmlClasses=");
        sbParam.append(XML_CLASSES);
        sbParam.append(" ");
        sbParam.append("sistemaOperacional=");
        sbParam.append(System.getenv("OS"));

        new Processor().run(xslFile,xmlFile,outFile,sbParam.toString());

    }

}
