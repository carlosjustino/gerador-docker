package com.datacoper.gerador.dictionary;

import com.datacoper.gerador.GenUtility;
import com.datacoper.gerador.Processor;
import com.datacoper.gerador.Transformation;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;

public class GenFrontEndDictionary implements Transformation {

   private String target = "ND" ;
   private boolean deleteXmlFiles = false;
   private String empty1="<arquivos/>";
   private String empty2="<lista/>";

    public GenFrontEndDictionary(){
        String target = System.getenv("interfaceName");

        if (target != null) this.target = target;

        this.deleteXmlFiles = GenUtility.getVariable("deleteXmlFiles");
    }

    @Override
    public void doTransformation() throws Exception {
       doEraseListInterfaceFiles();
       doCreateEmptyFiles();
       doTransformationTelaSimplesCustomizada();
       String fileList= new String(Files.readAllBytes(Paths.get(GenUtility.HOME_GEN + "/target/xmlListTelaSimplesCustomizada.xml")));

        //if (!target.equals("ND") || empty1.equals(fileList)){
            doTransformationListaTelaComplexa();
            doTransformationTelaComplexa();
            doTransformationTelaComplexaSync();
        //}
    }

    private void doEraseListInterfaceFiles() throws Exception{
        GenUtility.deleteFile(new File(GenUtility.HOME_GEN+"/target/listaTelaComplexa.xml"));
        GenUtility.deleteFile(new File(GenUtility.HOME_GEN+"/target/xmlListTelaComplexa.xml"));
        GenUtility.deleteFile(new File(GenUtility.HOME_GEN+"/target/xmlListTelaComplexa_sync.xml"));
        GenUtility.deleteFile(new File(GenUtility.HOME_GEN+"/target/xmlListTelaSimplesCustomizada.xml"));
        GenUtility.deleteFile(new File(GenUtility.HOME_GEN+"/target/listaRelatorio.xml"));
        GenUtility.deleteFile(new File(GenUtility.HOME_GEN+"/target/xmlListRelatorio.xml"));
        GenUtility.deleteFile(new File(GenUtility.HOME_GEN+"/target/xmlListRelatorio_sync.xml"));

        if (deleteXmlFiles){
            GenUtility.deleteFile(new File(GenUtility.HOME_GEN+"/target/telas"));
            new File(GenUtility.HOME_GEN+"/target/telas").mkdir();
        }

    }

    private void doCreateEmptyFiles() throws Exception {
        Files.write(Paths.get(GenUtility.HOME_GEN + "/target/listaTelaComplexa.xml"), empty1.getBytes());
        Files.write(Paths.get(GenUtility.HOME_GEN + "/target/xmlListTelaComplexa_sync.xml" ), empty1.getBytes());
        Files.write(Paths.get(GenUtility.HOME_GEN + "/target/xmlListTelaSimplesCustomizada.xml" ), empty1.getBytes());
        Files.write(Paths.get(GenUtility.HOME_GEN + "/target/listaTelaComplexa.xml"), empty2.getBytes());
        Files.write(Paths.get(GenUtility.HOME_GEN + "/target/xmlListRelatorio.xml"), empty1.getBytes());
        Files.write(Paths.get(GenUtility.HOME_GEN + "/target/xmlListRelatorio_sync.xml"), empty1.getBytes());
        Files.write(Paths.get(GenUtility.HOME_GEN + "/target/listaRelatorio.xml"), empty2.getBytes());

    }

    private void doTransformationTelaSimplesCustomizada() throws Exception{
        String xslt = GenUtility.HOME_GEN + "/src/main/java/v2/mm2telaSimplesCustomizada.xsl";
        String xmlFile=System.getenv("HOME_MINDMAPS") + "/"+ System.getenv("PROJECT_NAME") +".mm";
        String outFile= GenUtility.HOME_GEN + "/target/xmlListTelaSimplesCustomizada.xml";

        String telaSimplesCustomizadaSourcePath=System.getenv("HOME_GEN_URL") + "/target/telas";

        StringBuilder sbParam = new StringBuilder();
        sbParam.append("padroesFileName=");
        sbParam.append(GenUtility.XML_PADROES);
        sbParam.append(" ");
        sbParam.append("tiposFileName=");
        sbParam.append(GenUtility.XML_TIPODADOS);
        sbParam.append(" ");
        sbParam.append("tipoFullFileName=");
        sbParam.append(GenUtility.XML_CLASSEATRIBUTOS);
        sbParam.append(" ");
        sbParam.append("telaSimplesCustomizadaSourcePath=");
        sbParam.append(telaSimplesCustomizadaSourcePath);
        sbParam.append(" ");
        sbParam.append("xmlClasses=");
        sbParam.append(GenUtility.XML_CLASSES);
        sbParam.append(" ");
        sbParam.append("sistemaOperacional=");
        sbParam.append(System.getenv("OS"));
        sbParam.append(" ");
        sbParam.append("unity=");
        sbParam.append(target);

        new Processor().run(xslt,xmlFile,outFile,sbParam.toString());

    }

    public void doTransformationListaTelaComplexa() throws Exception {

        String xslt = GenUtility.HOME_GEN + "/src/main/java/v2/mm2listaTelaComplexa.xsl";
        String xmlFile=System.getenv("HOME_MINDMAPS") + "/"+ GenUtility.PROJECT_NAME +".mm";
        String outFile= GenUtility.HOME_GEN + "/target/listaTelaComplexa.xml";

        StringBuilder sbParam = new StringBuilder();

        sbParam.append("unity=");
        sbParam.append(target);

        new Processor().run(xslt,xmlFile,outFile,sbParam.toString());

    }


    public void doTransformationTelaComplexa() throws Exception {
        String xslFile = GenUtility.HOME_GEN + "/src/main/java/v2/mm2telaComplexa.xsl";
        String xmlFile = GenUtility.HOME_GEN + "/target/listaTelaComplexa.xml";
        String outFile = GenUtility.HOME_GEN + "/target/xmlListTelaComplexa.xml";

        String telaComplexaSourcePath= System.getenv("HOME_GEN_URL") + "/target/telas";

        StringBuilder sbParam = new StringBuilder();
        sbParam.append("telaComplexaSourcePath=");
        sbParam.append(telaComplexaSourcePath);
        sbParam.append(" ");
        sbParam.append("xmlClasses=");
        sbParam.append(GenUtility.XML_CLASSES);
        sbParam.append(" ");
        sbParam.append("mapasSourcePath=");
        sbParam.append(System.getenv("HOME_MINDMAPS"));
        sbParam.append(" ");
        sbParam.append("padroesFileName=");
        sbParam.append(GenUtility.XML_PADROES);
        sbParam.append(" ");
        sbParam.append("tiposFileName=");
        sbParam.append(GenUtility.XML_TIPODADOS);
        sbParam.append(" ");
        sbParam.append("tipoFullFileName=");
        sbParam.append(GenUtility.XML_CLASSEATRIBUTOS);
        sbParam.append(" ");
        sbParam.append("unity=");
        sbParam.append(target);

        new Processor().run(xslFile,xmlFile,outFile,sbParam.toString());

    }


    public void doTransformationTelaComplexaSync() throws Exception {

        String xslFile = GenUtility.HOME_GEN + "/src/main/java/v2/telaComplexa2Sync.xsl";
        String xmlFile = GenUtility.HOME_GEN + "/target/xmlListTelaComplexa.xml";
        String outFile = GenUtility.HOME_GEN + "/target/xmlListTelaComplexa_sync.xml";

        String syncTelaComplexaPath = System.getenv("HOME_GEN_URL") + "/target/sync";

        String xmlListTelaSimplesCustomizada = GenUtility.HOME_GEN + "/target/xmlListTelaSimplesCustomizada.xml";

        StringBuilder sbParam = new StringBuilder();
        sbParam.append("syncTelaComplexaPath=");
        sbParam.append(syncTelaComplexaPath);
        sbParam.append(" ");
        sbParam.append("xmlClasses=");
        sbParam.append(GenUtility.XML_CLASSES);
        sbParam.append(" ");
        sbParam.append("xmlListTelaSimplesCustomizada=");
        sbParam.append(xmlListTelaSimplesCustomizada);


        new Processor().run(xslFile, xmlFile, outFile, sbParam.toString());


    }

}
