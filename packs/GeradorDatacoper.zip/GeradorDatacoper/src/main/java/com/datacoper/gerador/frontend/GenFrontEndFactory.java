package com.datacoper.gerador.frontend;

import com.datacoper.gerador.Processor;
import com.datacoper.gerador.Transformation;

import java.util.concurrent.Callable;

import static com.datacoper.gerador.GenUtility.HOME_GEN;
import static com.datacoper.gerador.GenUtility.XML_CLASSES;

public class GenFrontEndFactory implements Transformation, Callable<Transformation> {
    String target = "ND";

    public GenFrontEndFactory(String target) {
        if (target != null) this.target = target;
    }

    @Override
    public void doTransformation() throws Exception {
        doTransformationTelaComplexaFactory();
    }

    @Override
    public Transformation call() throws Exception {
        doTransformation();
        return this;
    }

    private void doTransformationTelaComplexaFactory() throws Exception {
        String xslFile = HOME_GEN + "/src/main/java/v2/dicionario2ngFactory.xsl";
        String xmlFile = XML_CLASSES;
        String outFile = System.getenv("HOME_TEMP") + "/factorySource.lst";

        String factorySourcePath = System.getenv("HOME_JNG_URL") + "/app/factory";

        StringBuilder sbParam = new StringBuilder();
        sbParam.append("factorySourcePath=");
        sbParam.append(factorySourcePath);
        sbParam.append(" ");
        sbParam.append("unity=");
        sbParam.append(target);
        sbParam.append(" ");
        sbParam.append("ativarBlockUI=");
        sbParam.append(System.getenv("ACTIVATE_BLOCKUI"));

        new Processor().run(xslFile, xmlFile, outFile, sbParam.toString());

    }

}
