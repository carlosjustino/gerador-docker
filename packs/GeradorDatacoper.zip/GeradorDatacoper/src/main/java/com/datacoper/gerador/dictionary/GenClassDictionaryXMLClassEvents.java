package com.datacoper.gerador.dictionary;

import com.datacoper.bean.ClasseAtributoTipo;
import com.datacoper.bean.MindMapNode;

import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.List;

public class GenClassDictionaryXMLClassEvents {

    private List<ClasseAtributoTipo> listaClasseAtributoTipoCompleta = new ArrayList<>();

    public GenClassDictionaryXMLClassEvents(List<ClasseAtributoTipo> listaClasseAtributoTipoCompleta) {
        this.listaClasseAtributoTipoCompleta = listaClasseAtributoTipoCompleta;
    }

    public String geraDicionarioEventos(String recuoAnterior, MindMapNode nodeObjeto) {
        StringBuilder stringEventos = new StringBuilder();
        String recuoAtual = recuoAnterior + "\t";

        MindMapNode nodeEvento = nodeObjeto.childByIcon("event_class");
        if (nodeEvento != null) {
            stringEventos.append(recuoAtual);
            stringEventos.append("<eventos root=\"sim\">\n");

            List<MindMapNode> nodesEventos = GenClassDictionaryXMLUtil.getListaMetodosFromNode(nodeEvento);

            nodesEventos.forEach(mindMapNode -> {
                stringEventos.append(geraDicionarioEvento(recuoAtual, mindMapNode));
            });

            stringEventos.append(recuoAtual);
            stringEventos.append("</eventos>\n");
        }

        return stringEventos.toString();
    }

    private String geraDicionarioEvento(String recuoAnterior, MindMapNode nodeEvento) {
        StringBuilder stringEvento = new StringBuilder();
        String recuoAtual = recuoAnterior + "\t";

        AbstractMap.SimpleEntry<String, String> eventoNomeRetorno = GenClassDictionaryXMLUtil.getNomeTipoAtributo(listaClasseAtributoTipoCompleta, nodeEvento.getAtributoTEXT());


        stringEvento.append(recuoAtual);
        stringEvento.append("<evento");

        stringEvento.append(" nome=\"");
        stringEvento.append(eventoNomeRetorno.getKey());
        stringEvento.append("\"");

        stringEvento.append(" revisado=\"");
        stringEvento.append("S");
        stringEvento.append("\"");

        stringEvento.append(">\n");

        stringEvento.append(geraDicionarioEventoBody(recuoAtual, nodeEvento));

        stringEvento.append(recuoAtual);
        stringEvento.append("</evento>\n");

        return stringEvento.toString();
    }

    private String geraDicionarioEventoBody(String recuoAnterior, MindMapNode nodeEvento) {
        StringBuilder stringBody = new StringBuilder();
        String recuoAtual = recuoAnterior + "\t";

        stringBody.append(recuoAtual);
        stringBody.append("<body>\n");

        stringBody.append(GenClassDictionaryXMLUtil.geraXmlInstrucao(recuoAtual, nodeEvento.getFilhos(), listaClasseAtributoTipoCompleta));

        stringBody.append(recuoAtual);
        stringBody.append("</body>\n");

        return stringBody.toString();
    }
}
