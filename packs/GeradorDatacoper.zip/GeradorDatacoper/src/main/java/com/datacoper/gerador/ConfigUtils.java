package com.datacoper.gerador;

import java.io.*;
import java.util.Properties;

public class ConfigUtils {

    private static ConfigUtils instance = null;

    private ConfigUtils(){

    }

    public static ConfigUtils getInstance() {
        if (instance == null) instance = new ConfigUtils();
        return instance;
    }

    private Properties getProperties(){
        Properties props = new Properties();
        try {
            InputStream in = this.getClass().getClassLoader().getResourceAsStream("config.properties");
            props.load(in);
            in.close();
        } catch (Exception e) {
            System.err.println("Erro ao Ler arquivo de configuracao: ");
            e.printStackTrace();
            System.err.println(" ");
            System.err.println("Codigo continuara executando.");
            System.err.println(" ");
        }
        return props;
    }

    public boolean isShowInfoTimeCompileXLST(){
        boolean retorno = false;
        String ret = getProperties().getProperty("apresentaTempoCompilacaoXSLT", "false");
        if (ret != null && !ret.equals("") ){
            retorno = ret.equals("true");
        }
        return retorno;
    }

    public boolean isShowInfoXLSTFile(){
        boolean retorno = false;
        String ret = getProperties().getProperty("apresentaNomeXSLT", "false");
        if (ret != null && !ret.equals("") ){
            retorno = ret.equals("true");
        }
        return retorno;
    }

    public String getNormalizedPath(String path) {
        path = path.replace("\\", File.separator);
        path = path.replace("/", File.separator);
        path = path.replace("//", File.separator);

        return path;
    }

    public void writeStringToDisk(String xml, String absolutePath) throws IOException {
        BufferedWriter writer = new BufferedWriter(new FileWriter(ConfigUtils.getInstance().getNormalizedPath(absolutePath)));
        writer.write(xml);
        writer.close();
    }
}
