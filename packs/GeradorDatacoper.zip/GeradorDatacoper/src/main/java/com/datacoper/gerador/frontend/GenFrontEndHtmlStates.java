package com.datacoper.gerador.frontend;

import com.datacoper.gerador.GenUtility;
import com.datacoper.gerador.Processor;
import com.datacoper.gerador.Transformation;

import java.util.concurrent.Callable;

public class GenFrontEndHtmlStates implements Transformation, Callable<Transformation> {

    public GenFrontEndHtmlStates() {

    }

    @Override
    public void doTransformation() throws Exception {
        doTransformationMenuClassesReferenciadas();
        doTransformationMenuPrincipalSistemaState();
    }

    @Override
    public Transformation call() throws Exception {
        doTransformation();
        return this;
    }

    private void doTransformationMenuClassesReferenciadas() throws Exception {
        String xslFile = GenUtility.HOME_GEN + "/src/main/java/v2/menu2classesReferenciadas.xsl";
        String xmlFile = GenUtility.HOME_GEN + "/target/menuPrincipalSistema.xml";
        String outFile = GenUtility.HOME_GEN + "/target/classesReferenciadas.xml";

        String stateSourcePath = System.getenv("HOME_JNG_URL") + "/app/states";
        String bigXmlClasses = GenUtility.HOME_GEN + "/target/bigClasses" + GenUtility.PROJECT_NAME + ".xml";
        String xmlSourcePath = System.getenv("HOME_GEN_URL") + "/target/";
        String xmlGrafo = GenUtility.HOME_GEN + "/target/classes" + GenUtility.PROJECT_NAME + "Grafo.xml";

        StringBuilder sbParam = new StringBuilder();
        sbParam.append("stateSourcePath=");
        sbParam.append(stateSourcePath);
        sbParam.append(" ");
        sbParam.append("bigXmlClasses=");
        sbParam.append(bigXmlClasses);
        sbParam.append(" ");
        sbParam.append("xmlClasses=");
        sbParam.append(GenUtility.XML_CLASSES);
        sbParam.append(" ");
        sbParam.append("xmlSourcePath=");
        sbParam.append(xmlSourcePath);
        sbParam.append(" ");
        sbParam.append("xmlGrafo=");
        sbParam.append(xmlGrafo);

        new Processor().run(xslFile, xmlFile, outFile, sbParam.toString());

    }


    private void doTransformationMenuPrincipalSistemaState() throws Exception {

        String xslFile = GenUtility.HOME_GEN + "/src/main/java/v2/menuPrincipalSistemaMM2State.xsl";
        String xmlFile = GenUtility.HOME_GEN + "/target/menuPrincipalSistema.xml";
        String outFile = GenUtility.HOME_JNG + "/states.jag";

        String stateSourcePath = System.getenv("HOME_JNG_URL") + "/app/states";
        String xmlSourcePath = System.getenv("HOME_GEN_URL") + "/target/";
        String xmlRefs = GenUtility.HOME_GEN + "/target/classesReferenciadas.xml";

        StringBuilder sbParam = new StringBuilder();
        sbParam.append("stateSourcePath=");
        sbParam.append(stateSourcePath);
        sbParam.append(" ");
        sbParam.append("xmlClasses=");
        sbParam.append(GenUtility.XML_CLASSES);
        sbParam.append(" ");
        sbParam.append("xmlSourcePath=");
        sbParam.append(xmlSourcePath);
        sbParam.append(" ");
        sbParam.append("xmlRefs=");
        sbParam.append(xmlRefs);

        new Processor().run(xslFile, xmlFile, outFile, sbParam.toString());

    }

}
