package com.datacoper.gerador.frontend.unittest;

import com.datacoper.gerador.Processor;
import com.datacoper.gerador.Transformation;

import static com.datacoper.gerador.GenUtility.HOME_GEN;
import static com.datacoper.gerador.GenUtility.XML_CLASSES;

public class GenTestPageObjectsManter implements Transformation {


    public GenTestPageObjectsManter(){
    }

    @Override
    public void doTransformation() throws Exception {
        doTransformationTestPageObjectsManter();
    }

    private void doTransformationTestPageObjectsManter() throws Exception{
        String xsltFile = HOME_GEN + "/src/main/java/v2/telaComplexa2ManterPageObjects.xsl";
        String xmlFile=HOME_GEN + "/target/xmlListTelaComplexa.xml";
        String outFile=HOME_GEN + "/target/manterPageObjects.lst";
        String pageObjectsSourcePath=System.getenv("HOME_PAGE_OBJECTS_URL");
        String xmlRotinas=HOME_GEN + "/target/xmlRotinas.xml";
        String xmlListTelaSimplesCustomizada=HOME_GEN + "/target/xmlListTelaSimplesCustomizada.xml";

        StringBuilder sbParam = new StringBuilder();
        sbParam.append("pageObjectsSourcePath=");
        sbParam.append(pageObjectsSourcePath);
        sbParam.append(" ");
        sbParam.append("xmlClasses=");
        sbParam.append(XML_CLASSES);
        sbParam.append(" ");
        sbParam.append("xmlRotinas=");
        sbParam.append(xmlRotinas);
        sbParam.append(" ");
        sbParam.append("xmlListTelaSimplesCustomizada=");
        sbParam.append(xmlListTelaSimplesCustomizada);
        sbParam.append(" ");
        sbParam.append("sistemaOperacional=");
        sbParam.append(System.getenv("OS"));

        new Processor().run(xsltFile,xmlFile,outFile,sbParam.toString());

    }


}
