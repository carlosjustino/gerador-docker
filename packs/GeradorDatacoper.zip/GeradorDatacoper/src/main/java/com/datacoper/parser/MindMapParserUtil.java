package com.datacoper.parser;

import com.datacoper.bean.MindMapNode;
import com.datacoper.bean.MindMapNodeAttribute;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class MindMapParserUtil {

    private static List<String> listValidNodeNames = Arrays.asList("map", "node", "icon");

    public static String getPackagePrefix(MindMapNode classe) {

        String packagePrefix;

        if (Arrays.asList("table", "table_abstract").contains(classe.getAtributoIcon()))
            packagePrefix = "com.datacoper.domain.";
        else
            packagePrefix = "com.datacoper.container.";

        return packagePrefix;
    }

    public static List<MindMapNode> findNodesDownByText(List<MindMapNode> lista, String nodeTEXT) {
        return findNodesDownByText(lista, Arrays.asList(nodeTEXT));
    }

    public static List<MindMapNode> findNodesDownByText(List<MindMapNode> lista, List<String> nodesTEXT) {
        List<MindMapNode> listaRetorno = new ArrayList<>();
        if (lista != null && !lista.isEmpty()) {
            for(MindMapNode cont : lista) {
                if (nodesTEXT.contains(cont.getAtributoTEXT()))
                    listaRetorno.add(cont);

                listaRetorno.addAll(findNodesDownByText(cont.getFilhos(), nodesTEXT));
            }
        }

        return listaRetorno;
    }

    public static MindMapNode findNodeUpByNodeName(MindMapNode node, String nodeName) {
        MindMapNode retorno = null;
        if (node != null) {
            if (nodeName.equals(node.getNodeName()))
                retorno = node;
            else if (node.getPai() != null)
                retorno = findNodeUpByNodeName(node.getPai(), nodeName);
        }

        return retorno;
    }

    public static MindMapNode findNodeUpByNodeIcon(MindMapNode node, String nodeIcon) {
        return findNodeUpByNodeIcon(node, nodeIcon, false);
    }

    public static MindMapNode findNodeUpByNodeIcon(MindMapNode node, String nodeIcon, boolean excludeRootNode) {
        MindMapNode retorno = null;
        if (node != null) {
            if (nodeIcon.equals(node.getAtributoIcon())
                    && (!excludeRootNode
                    || (node.getPai() == null || !"map".equals(node.getPai().getNodeName()))))
                retorno = node;
            else if (node.getPai() != null)
                retorno = findNodeUpByNodeIcon(node.getPai(), nodeIcon, excludeRootNode);
        }

        return retorno;
    }

    public static List<MindMapNode> findNodesDownByIcon(List<MindMapNode> lista, String nodeICON) {
        return findNodesDownByIcon(lista, nodeICON, false);
    }

    public static List<MindMapNode> findNodesDownByIcon(List<MindMapNode> lista, String nodeICON, boolean excludeRootNode) {
        return findNodesDownByIcon(lista, Arrays.asList(nodeICON), excludeRootNode);
    }

    public static List<MindMapNode> findNodesDownByIcon(List<MindMapNode> lista, List<String> nodesICON, boolean excludeRootNode) {
        List<MindMapNode> listaRetorno = new ArrayList<>();
        if (lista != null && !lista.isEmpty()) {
            for(MindMapNode cont : lista) {
                if (nodesICON.contains(cont.getAtributoIcon())
                        && (!excludeRootNode
                        || (cont.getPai() == null || !"map".equals(cont.getPai().getNodeName()))))
                    listaRetorno.add(cont);

                listaRetorno.addAll(findNodesDownByIcon(cont.getFilhos(), nodesICON, excludeRootNode));
            }
        }

        return listaRetorno;
    }

    public static List<MindMapNode> fromXMLDocumentToListMindMapNode(Document xmlDocument) {
        List<MindMapNode> listaRetorno = new ArrayList<>();

        if (xmlDocument.hasChildNodes()) {
            listaRetorno = fromXMLDocumentToListMindMapNodeChildren(null, xmlDocument.getChildNodes());
        }

        return listaRetorno;
    }

    private static List<MindMapNode> fromXMLDocumentToListMindMapNodeChildren(MindMapNode pai, NodeList childNodes) {
        List<MindMapNode> listaRetorno = new ArrayList<>();

        for (int i = 0; i < childNodes.getLength(); i++) {
            Node node = childNodes.item(i);

            if (listValidNodeNames.contains(node.getNodeName())) {

                MindMapNode mindMapNode = criaMindMapNode(pai, node);
                if (mindMapNode == null) continue;

                listaRetorno.add(mindMapNode);
            }
        }

        return listaRetorno;
    }

    private static MindMapNode criaMindMapNode(MindMapNode pai, Node node) {
        MindMapNode mindMapNode = new MindMapNode();
        mindMapNode.setNodeName(node.getNodeName());
        mindMapNode.setPai(pai);
        mindMapNode.setNodeValue(node.getNodeValue() != null ? node.getNodeValue() : "");
        mindMapNode.setAtributes(new ArrayList<>());
        mindMapNode.setFilhos(new ArrayList<>());

        addAttributes(node, mindMapNode);

        Optional<MindMapNodeAttribute> textAttribute = mindMapNode.getAtributes().stream().filter(x -> "TEXT".equals(x.getName())).findAny();
        if (textAttribute.isPresent() && "//".equals(textAttribute.get().getValue()))
            return null;
        if (textAttribute.isPresent())
            mindMapNode.setAtributoTEXT(textAttribute.get().getValue());

        if (node.hasChildNodes()) {
            mindMapNode.setFilhos(fromXMLDocumentToListMindMapNodeChildren(mindMapNode, node.getChildNodes()));

            setIconAttribute(mindMapNode);
        }

        removeAndRealocateNodeIdeaComments(mindMapNode);
        return mindMapNode;
    }

    private static void removeAndRealocateNodeIdeaComments(MindMapNode mindMapNode) {
        List<MindMapNode> filhosToDeserdar = mindMapNode.getFilhos().stream().filter(filho -> "idea".equals(filho.getAtributoIcon())).collect(Collectors.toList());
        for(MindMapNode filho : filhosToDeserdar) {
            for(MindMapNode neto : filho.getFilhos()) {
                neto.setPai(mindMapNode);
            }
            mindMapNode.getFilhos().addAll(filho.getFilhos());
        }
        mindMapNode.getFilhos().removeAll(filhosToDeserdar);
    }

    private static void setIconAttribute(MindMapNode mindMapNode) {
        Optional<MindMapNode> iconChild = mindMapNode.getFilhos().stream().filter(x -> "icon".equals(x.getNodeName())).findAny();
        if (iconChild.isPresent()){
            Optional<MindMapNodeAttribute> builtinChild = iconChild.get().getAtributes().stream().filter(x -> "BUILTIN".equals(x.getName())).findAny();
            if (builtinChild.isPresent())
                mindMapNode.setAtributoIcon(builtinChild.get().getValue());
        }
    }

    private static void addAttributes(Node node, MindMapNode mindMapNode) {
        for (int j = 0; j < node.getAttributes().getLength(); j++) {
            Node atribute = node.getAttributes().item(j);

            MindMapNodeAttribute mindMapNodeAttribute = new MindMapNodeAttribute();
            mindMapNodeAttribute.setName(atribute.getNodeName());
            mindMapNodeAttribute.setValue(atribute.getNodeValue() != null ? atribute.getNodeValue() : "");
            mindMapNode.addToAtributes(mindMapNodeAttribute);
        }
    }
}
