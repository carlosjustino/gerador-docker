package com.datacoper.gerador.dictionary;

import com.datacoper.bean.ClasseAtributoTipo;
import com.datacoper.bean.MindMapNode;

import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class GenClassDictionaryXMLClassFunctions {

    private List<ClasseAtributoTipo> listaClasseAtributoTipoCompleta = new ArrayList<>();

    public GenClassDictionaryXMLClassFunctions(List<ClasseAtributoTipo> listaClasseAtributoTipoCompleta) {
        this.listaClasseAtributoTipoCompleta = listaClasseAtributoTipoCompleta;
    }

    public String geraDicionarioFuncoes(String recuoAnterior, MindMapNode nodeObjeto) {
        StringBuilder stringFuncoes = new StringBuilder();
        String recuoAtual = recuoAnterior + "\t";

        MindMapNode nodeFuncao = nodeObjeto.childByTextEquals("funcao");
        if (nodeFuncao != null) {
            stringFuncoes.append(recuoAtual);
            stringFuncoes.append("<funcoes>\n");

            List<MindMapNode> nodesFuncoes = GenClassDictionaryXMLUtil.getListaMetodosFromNode(nodeFuncao);

            nodesFuncoes.forEach(mindMapNode -> {
                stringFuncoes.append(geraDicionarioFuncao(recuoAtual, mindMapNode));
            });

            stringFuncoes.append(recuoAtual);
            stringFuncoes.append("</funcoes>\n");
        }

        return stringFuncoes.toString();
    }

    private String geraDicionarioFuncao(String recuoAnterior, MindMapNode nodeFuncao) {
        StringBuilder stringFuncao = new StringBuilder();
        String recuoAtual = recuoAnterior + "\t";

        AbstractMap.SimpleEntry<String, String> funcaoNomeRetorno = GenClassDictionaryXMLUtil.getNomeTipoAtributo(listaClasseAtributoTipoCompleta, nodeFuncao.getAtributoTEXT());


        stringFuncao.append(recuoAtual);
        stringFuncao.append("<funcao");

        stringFuncao.append(" nome=\"");
        stringFuncao.append(funcaoNomeRetorno.getKey());
        stringFuncao.append("\"");

        if (!"".equals(funcaoNomeRetorno.getValue())) {
            stringFuncao.append(" tipo=\"");
            stringFuncao.append(funcaoNomeRetorno.getValue());
            stringFuncao.append("\"");
        }

        stringFuncao.append(" revisado=\"");
        stringFuncao.append("S");
        stringFuncao.append("\"");

        stringFuncao.append(" acesso=\"");
        stringFuncao.append("private".equals(nodeFuncao.getPai().getAtributoTEXT()) ? "private" : "public");
        stringFuncao.append("\"");

        stringFuncao.append(">\n");

        stringFuncao.append(GenClassDictionaryXMLUtil.geraXmlInstrucao(recuoAtual, nodeFuncao.getFilhos(), listaClasseAtributoTipoCompleta));

        stringFuncao.append(recuoAtual);
        stringFuncao.append("</funcao>\n");

        return stringFuncao.toString();
    }
}
