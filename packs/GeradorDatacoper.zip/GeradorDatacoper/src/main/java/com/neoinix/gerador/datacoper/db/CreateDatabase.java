/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.neoinix.gerador.datacoper.db;



/**
 * import org.apache.ddlutils.io.DatabaseIO; import
 * org.apache.ddlutils.Platform; import org.apache.ddlutils.PlatformFactory;
 * import org.apache.ddlutils.model.Database; *
 */



/**
 *
 * @author clovis
 */
public class CreateDatabase {

	public static void main(String[] args) {
		// System.out.println(System.getProperty("user.name"));
		// System.out.println(System.getProperties());
/*
		try {

			System.out.println(
					"------------------------------ INICIO RECONSTRUCAO BANCO DE DADOS -----------------------------------------------");
			//Connection c = null;

			//PGSimpleDataSource pgds = new PGSimpleDataSource();
			String database = null;
			if (args == null || args.length == 0) {
				database = "erpdatacoper";
			} else {
				database = args[0];
			}

			//pgds.setUrl("jdbc:postgresql://localhost:5432/" + database);
			//pgds.setUser("useragrorevenda");
			//pgds.setPassword("1032data#14");
			//c = pgds.getConnection();
			//Statement stmt = c.createStatement();
			String sql = "drop schema public cascade;create schema public;";
			try {
				stmt.executeUpdate(sql);
			} catch (Exception ex) {
				System.out
						.println("------------------------------ ERRO -----------------------------------------------");
				System.out.println("Nao foi possivel executar a SQL:");
				System.out.println("---> " + sql);
				System.out.println(ex.toString());
				System.out
						.println("-----------------------------------------------------------------------------------");
				System.exit(1);
			}

			Platform platform = PlatformFactory.createNewPlatformInstance(pgds);
			
			if (pgds.toString().contains("postgresql")) { // postgreSql
				
				platform.getPlatformInfo().setMaxConstraintNameLength(63);
				platform.getPlatformInfo().setMaxColumnNameLength(63);
				platform.getPlatformInfo().setMaxForeignKeyNameLength(63);
				platform.getPlatformInfo().setMaxTableNameLength(63);
				
			}
			
			Database targetModel = readDatabaseFromXML("target/ddlAgroRevenda.xml");

			changeDatabase(platform, targetModel, false);
		} catch (SQLException ex) {
			Logger.getLogger(CreateDatabase.class.getName()).log(Level.SEVERE, null, ex);
		}
		System.out.println(
				"------------------------------ FIM RECONSTRUCAO BANCO DE DADOS -----------------------------------------------");
	*/
	}
/*
	public static void changeDatabase(Platform platform , Database targetModel, boolean alterDb)
			throws SQLException {
		System.out.println("  ------------- configurações ------------- ");
		System.out.println("MaxColumnNameLength : " + platform.getPlatformInfo().getMaxColumnNameLength());
		System.out.println("MaxConstraintNameLength: " + platform.getPlatformInfo().getMaxConstraintNameLength());
		System.out.println("MaxForeignKeyNameLength: " + platform.getPlatformInfo().getMaxForeignKeyNameLength());
		System.out.println("MaxTableNameLength: " + platform.getPlatformInfo().getMaxTableNameLength());
		System.out.println("  ----------------------------------------- ");
		if (alterDb) {
			platform.alterTables(targetModel, false);
		} else {
			platform.createModel(targetModel, false, true); // createTables(targetModel,
															// true, true);
		}
	}

	public static Database readDatabaseFromXML(String fileName) {
		return new DatabaseIO().read(fileName);
	}*/

}
